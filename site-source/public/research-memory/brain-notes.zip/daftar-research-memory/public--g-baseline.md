---
id: "g-baseline"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Retrieval baselines

Compare lexical-only, graph-only, and fused retrieval on fixed questions and relevance labels before claiming a gain.

## Connections

- prerequisite_of (outgoing): [[public--g-recall]]
- prerequisite_of (outgoing): [[public--g-leakage]]
- prerequisite_of (outgoing): [[public--gf-novelty-loop]]

## Sources

- [LongMemEval: Benchmarking Chat Assistants on Long-Term Interactive Memory](https://arxiv.org/abs/2410.10813) — abstract

Evidence links and mathematical analogies do not grant tool permissions.
