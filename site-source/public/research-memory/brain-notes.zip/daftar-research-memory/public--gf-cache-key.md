---
id: "gf-cache-key"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Complete cache dependency key

Treat the result as a function of declared inputs. Equal keys justify reuse only insofar as the serialization captures every relevant input.

$$
K=\operatorname{SHA256}(\operatorname{canon}(q,V,A,S,P,T,\theta))
$$

## Assumptions

- Canonical serialization is deterministic.
- All output-relevant dependencies are included.
- Cryptographic hash collisions are assumed negligible.

## Worked check

A source URL correction changes V and therefore the key even when the node summary text is unchanged.

## Limits

- A digest does not validate the source, authenticate a caller, or prove semantic equivalence.

## Connections

- prerequisite_of (incoming): [[public--g-hash]]
- prerequisite_of (incoming): [[public--g-invalidate]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
