---
id: "g-repos"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Repository knowledge graph

Connect repo, commit, code path, test, source claim, and artifact with exact typed edges and distinct publication states.

## Connections

- prerequisite_of (incoming): [[public--g-provenance]]
- prerequisite_of (outgoing): [[public--g-skills]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
