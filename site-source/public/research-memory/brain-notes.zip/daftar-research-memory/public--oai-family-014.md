---
id: "oai-family-014"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# Restricted geometric Langlands, global Arthur enhancements, and generic Ramanujan

Publisher catalogue family with 8 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0026]]
- member_of (incoming): [[public--oai-paper-0027]]
- member_of (incoming): [[public--oai-paper-0028]]
- member_of (incoming): [[public--oai-paper-0029]]
- member_of (incoming): [[public--oai-paper-0030]]
- member_of (incoming): [[public--oai-paper-0031]]
- member_of (incoming): [[public--oai-paper-0032]]
- member_of (incoming): [[public--oai-paper-0033]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
