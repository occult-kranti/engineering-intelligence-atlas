---
id: "mf-difference"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Centered second derivative

Add the Taylor series at x+h and x−h. Odd powers cancel; the leading remaining difference is h²f″(x), with h⁴f⁽⁴⁾/12 as the next term. Division by h² gives second-order truncation error.

$$
f''(x)=\frac{f(x+h)-2f(x)+f(x-h)}{h^2}+O(h^2)
$$

## Assumptions

- Four derivatives exist and are bounded locally.

## Worked check

For f(x)=x² the stencil returns exactly 2 at every nonzero h in exact arithmetic.

## Limits

- Very small h amplifies rounding and measurement noise by h⁻²; smaller spacing is not automatically more accurate.

## Connections

- prerequisite_of (incoming): [[public--m-taylor]]
- prerequisite_of (incoming): [[public--m-finitedifference]]

## Sources

- [Finite Difference Methods for PDEs, Per-Olof Persson](https://persson.berkeley.edu/math228b/html/finite_difference_methods_for_PDEs.html) — finite differences and FTCS stability sections inspected

Evidence links and mathematical analogies do not grant tool permissions.
