---
id: "g-path"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Explanation paths

Show why a node was retrieved and the typed relations linking it to direct matches. A path explains selection, not causation.

## Connections


## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
