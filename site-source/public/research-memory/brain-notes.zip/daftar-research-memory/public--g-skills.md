---
id: "g-skills"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Skill memory workflow

Before revisiting a problem, inspect relevant source-linked concepts, past decisions, unresolved objections, and versioned artifacts.

## Connections

- prerequisite_of (incoming): [[public--g-repos]]
- prerequisite_of (outgoing): [[public--g-donna]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
