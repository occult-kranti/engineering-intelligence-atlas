---
id: "g-pagerank"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Personalized PageRank

Restart toward query seeds while traversing the eligible graph. The stationary mass is a retrieval affinity, not truth probability.

## Connections

- prerequisite_of (incoming): [[public--g-walk]]
- prerequisite_of (outgoing): [[public--g-convergence]]
- prerequisite_of (outgoing): [[public--g-hipporag]]
- prerequisite_of (outgoing): [[public--gf-ppr-error]]
- prerequisite_of (outgoing): [[public--gf-rrf]]
- prerequisite_of (incoming): [[public--m-fixedpoint]]

## Sources

- [HippoRAG: Neurobiologically Inspired Long-Term Memory for Large Language Models](https://arxiv.org/abs/2405.14831) — abstract-and-project-description

Evidence links and mathematical analogies do not grant tool permissions.
