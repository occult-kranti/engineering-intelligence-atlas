---
id: "gf-topological"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# DAG topological condition

A finite acyclic directed graph has a zero-indegree vertex. A cycle leaves each of its vertices with an incoming edge, preventing complete elimination.

$$
|\operatorname{Kahn}(G)|=|V|\iff G\text{ is a DAG}
$$

## Assumptions

- Remove vertices of zero indegree and their outgoing edges.

## Worked check

A requires B and B requires A gives no valid topological order; C depending on A can also remain blocked.

## Limits

- Remaining blocked vertices are not necessarily all members of a cycle.

## Connections

- prerequisite_of (incoming): [[public--g-dag]]
- prerequisite_of (incoming): [[public--g-cycle]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
