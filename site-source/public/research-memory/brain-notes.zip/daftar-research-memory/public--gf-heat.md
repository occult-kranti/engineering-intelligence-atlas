---
id: "gf-heat"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Graph heat flow

Diagonalize L=UΛUᵀ; each mode obeys a scalar decay equation with solution exp(-κλt).

$$
\frac{dx}{dt}=-\kappa Lx,\qquad x(t)=e^{-\kappa Lt}x(0)
$$

## Assumptions

- Fixed symmetric nonnegative graph.
- Linear dynamics.

## Worked check

A mode with λ=2 and κ=1 s^-1 decays to exp(-2)≈0.1353 of its initial amplitude after 1 s.

## Limits

- Smoothing can remove a rare but essential distinction. A diffusion parameter is not automatically a biological timescale.

## Connections

- prerequisite_of (incoming): [[public--g-laplacian]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
