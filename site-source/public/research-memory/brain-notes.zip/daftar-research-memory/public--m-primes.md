---
id: "m-primes"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Primes and unique factorization

Prime factorization translates multiplication into exponents, while computation can remain hard.

## Connections

- prerequisite_of (incoming): [[public--m-fields]]
- prerequisite_of (outgoing): [[public--m-elliptic]]
- prerequisite_of (outgoing): [[public--m-ai-unitdistance]]
- prerequisite_of (outgoing): [[public--mf-zeta]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [NIST DLMF 25.2: Definition and Expansions of the Riemann zeta function](https://dlmf.nist.gov/25.2) — definition and convergence domain inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
