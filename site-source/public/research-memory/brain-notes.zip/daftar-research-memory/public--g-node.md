---
id: "g-node"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Atomic concept and claim nodes

Keep concepts, claims, formulas, sources, tasks, and artifacts distinguishable. Their identities must survive renaming.

## Connections

- prerequisite_of (incoming): [[public--g-graph]]
- prerequisite_of (outgoing): [[public--g-edge]]
- prerequisite_of (outgoing): [[public--g-identity]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
