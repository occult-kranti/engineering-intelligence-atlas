---
id: "m-ai-vpvnp"
domain: "ai-mathematics"
status: "statement_inspected_independent_acceptance_not_established"
scope: "public"
tags: [daftar, research-memory]
---

# Anthropic VP≠VNP artifact

Claims VP≠VNP over all fields, with Hamiltonian-cycle lower bounds and permanent bounds outside characteristic two.

## Connections

- prerequisite_of (incoming): [[public--m-fields]]
- prerequisite_of (incoming): [[public--m-determinant]]
- prerequisite_of (incoming): [[public--m-complexity]]

## Sources

- [VP ≠ VNP over every field: statement and research artifact](https://github.com/anthropics/formal-math/tree/11b6c7e3c927df2658f513b6b68ea7f8929c62c5/vp-vnp) — README and Statement.lean inspected

Evidence links and mathematical analogies do not grant tool permissions.
