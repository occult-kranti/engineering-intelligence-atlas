---
id: "m-pca"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# PCA and low-rank compression

PCA captures variance directions, which need not be semantic or causal directions.

## Connections

- prerequisite_of (incoming): [[public--m-svd]]
- prerequisite_of (outgoing): [[public--m-embedding]]
- prerequisite_of (outgoing): [[public--mf-lowrank]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
