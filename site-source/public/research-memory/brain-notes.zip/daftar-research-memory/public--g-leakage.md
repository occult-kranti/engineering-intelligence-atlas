---
id: "g-leakage"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Evaluation leakage

Separate corpus preparation, answer labels, parameter tuning, and final evaluation. Duplicated sources are not independent confirmation.

## Connections

- prerequisite_of (incoming): [[public--g-baseline]]
- prerequisite_of (outgoing): [[public--g-reviews]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
