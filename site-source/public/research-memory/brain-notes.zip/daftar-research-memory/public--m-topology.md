---
id: "m-topology"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Topological spaces and continuity

Topology records neighborhoods and continuity without requiring lengths.

## Connections

- prerequisite_of (outgoing): [[public--m-homotopy]]
- prerequisite_of (outgoing): [[public--mf-stokes]]
- prerequisite_of (outgoing): [[public--mf-homology]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
