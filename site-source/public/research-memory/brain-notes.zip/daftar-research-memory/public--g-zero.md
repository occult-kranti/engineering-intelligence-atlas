---
id: "g-zero"
domain: "memory"
status: "representative-frontier"
scope: "public"
tags: [daftar, research-memory]
---

# GraphRAG Zero

A November 2026 provider research announcement describes retrieval built from embedding geometry with optional reasoning extensions.

## Connections

- prerequisite_of (incoming): [[public--g-graphrag]]

## Sources

- [The evolution of GraphRAG: Advancing systems and evaluation together](https://www.microsoft.com/en-us/research/story/the-evolution-of-graphrag-advancing-systems-and-evaluation-together/) — official-research-announcement-selected-sections

Evidence links and mathematical analogies do not grant tool permissions.
