---
id: "g-graph"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Typed knowledge graph

Represent objects as stable vertices and relationships as named, directed edges. A graph stores assertions, not automatic truth.

## Connections

- prerequisite_of (outgoing): [[public--g-node]]
- prerequisite_of (outgoing): [[public--g-bfs]]
- prerequisite_of (outgoing): [[public--gf-adjacency]]

## Sources

- [Obsidian Help: Graph view](https://obsidian.md/help/plugins/graph) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
