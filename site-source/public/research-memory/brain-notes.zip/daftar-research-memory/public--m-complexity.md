---
id: "m-complexity"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Computational complexity and reductions

A theorem about Turing machines, word RAM or arithmetic circuits must retain that model.

## Connections

- prerequisite_of (incoming): [[public--m-tensor]]
- prerequisite_of (outgoing): [[public--m-ai-ten]]
- prerequisite_of (outgoing): [[public--m-ai-3sum]]
- prerequisite_of (outgoing): [[public--m-ai-claudeeth]]
- prerequisite_of (outgoing): [[public--m-ai-oaieth]]
- prerequisite_of (outgoing): [[public--m-ai-vpvnp]]
- prerequisite_of (outgoing): [[public--m-ai-oai-newnine]]
- prerequisite_of (outgoing): [[public--mf-permanent]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
