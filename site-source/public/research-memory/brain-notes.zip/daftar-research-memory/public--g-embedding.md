---
id: "g-embedding"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Embedding similarity

A learned vector can place semantically similar passages near each other; closeness alone does not certify a claim or authorization.

## Connections

- prerequisite_of (outgoing): [[public--g-cosine]]
- prerequisite_of (outgoing): [[public--gf-cosine]]

## Sources

- [From RAG to Memory: Non-Parametric Continual Learning for Large Language Models](https://arxiv.org/html/2502.14802v2) — selected-methods-and-limitations

Evidence links and mathematical analogies do not grant tool permissions.
