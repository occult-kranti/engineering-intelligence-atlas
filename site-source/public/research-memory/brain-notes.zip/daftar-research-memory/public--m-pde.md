---
id: "m-pde"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Boundary and initial value problems

A differential equation needs data, solution class and a uniqueness/stability question.

## Connections

- prerequisite_of (incoming): [[public--m-variation]]
- prerequisite_of (incoming): [[public--m-sobolev]]
- prerequisite_of (outgoing): [[public--m-ai-nsforced]]
- prerequisite_of (outgoing): [[public--m-ai-euler]]
- prerequisite_of (outgoing): [[public--m-ai-ns-translation]]
- prerequisite_of (outgoing): [[public--m-ai-ymexistence]]
- prerequisite_of (outgoing): [[public--m-ai-ymgap]]
- prerequisite_of (outgoing): [[public--m-ai-unforcedns]]
- prerequisite_of (outgoing): [[public--mf-heatkernel]]
- prerequisite_of (outgoing): [[public--mf-wave]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
