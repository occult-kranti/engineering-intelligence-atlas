---
id: "g-ndcg"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Ranking quality

Discount lower-ranked relevant items and normalize by an ideal order when relevance grades are well defined.

## Connections

- prerequisite_of (incoming): [[public--g-recall]]
- prerequisite_of (outgoing): [[public--g-calibration]]
- prerequisite_of (outgoing): [[public--gf-ndcg]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
