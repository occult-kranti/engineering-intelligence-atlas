---
id: "m-gaussian"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Gaussian models

A covariance matrix must be positive semidefinite; a density needs nonsingular covariance.

## Connections

- prerequisite_of (incoming): [[public--m-covariance]]
- prerequisite_of (outgoing): [[public--m-montecarlo]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
