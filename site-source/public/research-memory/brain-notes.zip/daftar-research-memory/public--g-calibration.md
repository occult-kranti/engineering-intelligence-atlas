---
id: "g-calibration"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Calibration versus confidence

A probability is calibrated only against outcomes with a defined evaluation population. Retrieval scores are not calibrated confidence.

## Connections

- prerequisite_of (incoming): [[public--g-ndcg]]
- prerequisite_of (outgoing): [[public--gf-brier]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
