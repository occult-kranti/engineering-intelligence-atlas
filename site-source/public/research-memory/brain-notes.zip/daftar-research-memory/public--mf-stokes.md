---
id: "mf-stokes"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Generalized Stokes theorem

On coordinate patches the statement reduces to one-variable integration and cancellation of internal faces. A partition of unity patches local identities into a global one. The identity d²=0 expresses that the boundary of a boundary contributes nothing.

$$
\int_M d\omega=\int_{\partial M}\omega
$$

## Assumptions

- M is oriented with compatible boundary orientation; forms are sufficiently smooth and integrals converge.
- Take M compact or ω compactly supported; a noncompact decay variant requires explicitly vanishing boundary contributions at infinity, beyond convergence alone.

## Worked check

For a planar disk with 1-form ω=−y dx/2+x dy/2, dω=dx∧dy and the boundary integral equals the disk's area.

## Limits

- Orientation errors flip signs; local exactness need not extend globally around holes.

## Connections

- prerequisite_of (incoming): [[public--m-tangent]]
- prerequisite_of (incoming): [[public--m-integral]]
- prerequisite_of (incoming): [[public--m-topology]]

## Sources

- [Introducing Differential Geometry, David Tong, section 2.4.5](https://www.davidtong.org/teaching/general-relativity/grhtml/S2) — sections 2.4.4–2.4.5 and equation 2.92 inspected

Evidence links and mathematical analogies do not grant tool permissions.
