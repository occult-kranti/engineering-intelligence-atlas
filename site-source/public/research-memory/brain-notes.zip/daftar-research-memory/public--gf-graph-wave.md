---
id: "gf-graph-wave"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Graph wave modes

Project onto each eigenvector to obtain an independent harmonic-oscillator equation.

$$
\ddot x+\omega_0^2 Lx=0,\qquad \omega_k=\omega_0\sqrt{\lambda_k}
$$

## Assumptions

- A physical or simulated second-order dynamical law is explicitly posited.
- L is positive semidefinite.

## Worked check

For path eigenvalue λ=3 and ω0=2 rad/s, the mode has ω=2√3 rad/s.

## Limits

- A note graph alone has no clock, mass, stiffness, or measured acoustic frequency.

## Connections

- prerequisite_of (incoming): [[public--g-frequency-bridge]]
- prerequisite_of (incoming): [[public--g-laplacian]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
