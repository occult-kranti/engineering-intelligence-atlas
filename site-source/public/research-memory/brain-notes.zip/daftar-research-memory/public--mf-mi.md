---
id: "mf-mi"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Mutual information

Expand log[p(x,y)/(p(x)p(y))] into log p(x|y)−log p(x) and average. This measures reduction in uncertainty about X after observing Y. Zero mutual information is equivalent to independence in the probability model.

$$
I(X;Y)=D_{KL}(p_{XY}\|p_Xp_Y)=H(X)-H(X\mid Y)
$$

## Assumptions

- Finite entropies suffice for the entropy difference; KL form extends more generally.

## Worked check

If Y is an exact copy of a fair bit X, I=1 bit; two independent fair bits give I=0.

## Limits

- Shared information does not establish causal direction; common causes can generate it.

## Connections

- prerequisite_of (incoming): [[public--m-kl]]
- prerequisite_of (incoming): [[public--m-entropy]]
- prerequisite_of (incoming): [[public--m-bayes]]

## Sources

- [Entropy, Relative Entropy, and Mutual Information, Tsachy Weissman](https://web.stanford.edu/class/ee376a/files/lecture_3.pdf) — five-page PDF; definitions and nonnegativity argument inspected

Evidence links and mathematical analogies do not grant tool permissions.
