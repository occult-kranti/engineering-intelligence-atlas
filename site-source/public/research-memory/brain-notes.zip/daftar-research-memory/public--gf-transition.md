---
id: "gf-transition"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Row-stochastic transition

Divide each outgoing weight by the row sum, producing total probability one.

$$
P_{ij}=A_{ij}/d_i\quad(d_i>0)
$$

## Assumptions

- Nonnegative weights.
- A separate redistribution rule is defined for dangling rows.

## Worked check

Weights (2,1) yield outgoing probabilities (2/3,1/3).

## Limits

- Negative relations cannot be inserted as negative probabilities. Keep contradicts as a separate semantic channel.

## Connections

- prerequisite_of (incoming): [[public--g-adjacency]]
- prerequisite_of (incoming): [[public--g-walk]]

## Sources

- [The PageRank Citation Ranking: Bringing Order to the Web](https://ilpubs.stanford.edu/422/) — original-report-discovery

Evidence links and mathematical analogies do not grant tool permissions.
