---
id: "g-bfs"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Bounded breadth-first traversal

Visited identities and depth/node caps let cyclic knowledge graphs be explored without infinite traversal.

## Connections

- prerequisite_of (incoming): [[public--g-graph]]
- prerequisite_of (outgoing): [[public--g-dag]]
- prerequisite_of (outgoing): [[public--gf-bfs]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
