---
id: "g-attention"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Attention-based association

Attention mixes value vectors using query-key compatibility; particular modern Hopfield models establish a precise mathematical connection.

## Connections

- prerequisite_of (incoming): [[public--g-hopfield]]
- prerequisite_of (outgoing): [[public--gf-attention]]

## Sources

- [Hopfield Networks is All You Need](https://arxiv.org/abs/2008.02217) — abstract

Evidence links and mathematical analogies do not grant tool permissions.
