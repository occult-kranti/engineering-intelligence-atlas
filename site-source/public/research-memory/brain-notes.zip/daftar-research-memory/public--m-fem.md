---
id: "m-fem"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Finite elements and weak forms

Basis functions approximate a variational solution while respecting boundary constraints.

## Connections

- prerequisite_of (incoming): [[public--m-weak]]
- prerequisite_of (outgoing): [[public--mf-weakpoisson]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
