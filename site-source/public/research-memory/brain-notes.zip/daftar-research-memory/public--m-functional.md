---
id: "m-functional"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Banach and Hilbert spaces

Completeness permits limits of approximations; Hilbert structure also supplies orthogonal projections.

## Connections

- prerequisite_of (incoming): [[public--m-measure]]
- prerequisite_of (outgoing): [[public--m-operators]]
- prerequisite_of (outgoing): [[public--mf-fourier]]
- prerequisite_of (outgoing): [[public--mf-sobolev]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected
- [NIST DLMF 25.2: Definition and Expansions of the Riemann zeta function](https://dlmf.nist.gov/25.2) — definition and convergence domain inspected
- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
