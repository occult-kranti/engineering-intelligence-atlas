---
id: "mf-walks"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Adjacency powers count walks

For k=1 the claim is the adjacency definition. Multiplying A^k by A sums over the penultimate vertex, appending one edge to each existing walk. Induction proves the result.

$$
(A^k)_{ij}=\#\{\text{length-k walks from }i\text{ to }j\}
$$

## Assumptions

- Unweighted finite graph; matrix orientation is fixed.
- For weighted graphs the entries sum products of edge weights instead.

## Worked check

In a two-vertex graph with one undirected edge, A²=I: each vertex has one two-step return walk.

## Limits

- Walks may repeat vertices and edges. They are not simple paths or independent lines of evidence.

## Connections

- prerequisite_of (incoming): [[public--m-adjacency]]
- prerequisite_of (incoming): [[public--m-induction]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
