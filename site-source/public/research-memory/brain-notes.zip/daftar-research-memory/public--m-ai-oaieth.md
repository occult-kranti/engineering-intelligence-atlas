---
id: "m-ai-oaieth"
domain: "ai-mathematics"
status: "announcement_and_catalogue_locator_read"
scope: "public"
tags: [daftar, research-memory]
---

# OpenAI fixed-width counting-SAT subexponential claim

Reports deterministic subexponential-time, polynomial-space counting of k-CNF assignments for fixed k.

## Connections

- prerequisite_of (incoming): [[public--m-complexity]]

## Sources

- [Working with academic communities to build scientific understanding](https://openai.com/index/building-scientific-understanding-with-academic-communities/) — dated page inspected
- [OpenAI mathematics manuscript catalogue, pinned snapshot](https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/CONTENTS.md) — entire catalogue parsed for metadata

Evidence links and mathematical analogies do not grant tool permissions.
