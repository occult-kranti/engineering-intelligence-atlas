---
id: "g-abstain"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Abstention

Return a gap when the available evidence cannot answer the question. A populated graph is not a reason to fabricate a match.

## Connections

- prerequisite_of (incoming): [[public--g-temporal-eval]]

## Sources

- [LongMemEval: Benchmarking Chat Assistants on Long-Term Interactive Memory](https://arxiv.org/abs/2410.10813) — abstract

Evidence links and mathematical analogies do not grant tool permissions.
