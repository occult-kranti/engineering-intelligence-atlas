---
id: "g-loop"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Research improvement loops

Each round changes a model or implementation in response to a specific observed weakness. Repeating a search is not automatically progress.

## Connections

- prerequisite_of (incoming): [[public--g-cycle]]
- prerequisite_of (outgoing): [[public--g-stop]]
- prerequisite_of (incoming): [[public--g-questions]]
- analogy (incoming): [[public--g-replay]]
- prerequisite_of (outgoing): [[public--gf-novelty-loop]]

## Sources

- [The evolution of GraphRAG: Advancing systems and evaluation together](https://www.microsoft.com/en-us/research/story/the-evolution-of-graphrag-advancing-systems-and-evaluation-together/) — official-research-announcement-selected-sections

Evidence links and mathematical analogies do not grant tool permissions.
