---
id: "m-measure"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Measure and integration

A measure assigns consistent sizes; null sets and almost-everywhere statements differ from pointwise claims.

## Connections

- prerequisite_of (incoming): [[public--m-integral]]
- prerequisite_of (outgoing): [[public--m-functional]]
- related (outgoing): [[public--m-probability]]
- prerequisite_of (outgoing): [[public--m-ai-kakeya]]
- prerequisite_of (outgoing): [[public--mf-sobolev]]

## Sources

- [An Introduction to Measure Theory, Terence Tao](https://teorth.github.io/tao-web/an-introduction-to-measure-theory.html) — current author page and scope inspected

Evidence links and mathematical analogies do not grant tool permissions.
