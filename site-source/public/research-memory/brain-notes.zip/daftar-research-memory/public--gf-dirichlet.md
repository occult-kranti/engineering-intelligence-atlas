---
id: "gf-dirichlet"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Dirichlet quadratic form

Expand the square and collect the two degree terms; symmetry turns both into x^TDx, while cross terms give twice x^TAx.

$$
x^TLx=\frac12\sum_{i,j}w_{ij}(x_i-x_j)^2
$$

## Assumptions

- Symmetric nonnegative weights.
- The double sum counts both orientations.

## Worked check

For path values (1,0,-1), the two undirected edge differences both equal 1, hence x^TLx=2.

## Limits

- Units are weight times signal squared. Calling this physical energy requires an additional physical model.

## Connections

- prerequisite_of (incoming): [[public--g-laplacian]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
