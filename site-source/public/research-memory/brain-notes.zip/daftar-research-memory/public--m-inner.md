---
id: "m-inner"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Inner products and norms

An inner product defines lengths and angles, with a conjugate transpose over complex scalars.

## Connections

- prerequisite_of (incoming): [[public--m-vectors]]
- prerequisite_of (outgoing): [[public--m-spectral]]
- prerequisite_of (outgoing): [[public--m-leastsquares]]
- related (outgoing): [[public--m-resistance]]
- prerequisite_of (outgoing): [[public--mf-inner]]
- prerequisite_of (outgoing): [[public--mf-spectral]]
- prerequisite_of (outgoing): [[public--mf-lap]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
