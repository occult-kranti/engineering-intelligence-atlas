---
id: "mf-cfl"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Explicit heat-scheme stability

Insert a discrete Fourier mode e^(ijθ). Its amplification factor is 1−4r sin²(θ/2). Requiring its magnitude not exceed one for every θ gives 0≤r≤1/2. This connects time-step restrictions directly to the highest resolved frequency.

$$
u_j^{n+1}=u_j^n+r(u_{j+1}^n-2u_j^n+u_{j-1}^n),\qquad 0\le r=\kappa\Delta t/\Delta x^2\le\tfrac12
$$

## Assumptions

- One-dimensional constant-coefficient heat equation on a uniform mesh with compatible boundary handling; κ≥0, Δt>0 and Δx>0.
- The stability statement is for this explicit Euler-centered scheme.

## Worked check

With κ=1 and Δx=0.1, take Δt≤0.005 for the stated scheme.

## Limits

- Other dimensions and discretizations have different restrictions; implicit stability does not remove accuracy requirements.

## Connections

- prerequisite_of (incoming): [[public--m-fourier]]
- prerequisite_of (incoming): [[public--m-finitedifference]]
- prerequisite_of (incoming): [[public--m-heat]]

## Sources

- [Finite Difference Methods for PDEs, Per-Olof Persson](https://persson.berkeley.edu/math228b/html/finite_difference_methods_for_PDEs.html) — finite differences and FTCS stability sections inspected

Evidence links and mathematical analogies do not grant tool permissions.
