---
id: "mf-resistance"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Effective electrical resistance

Inject unit current at i and remove it at j. Solve Lv=e_i−e_j in the zero-mean gauge. The potential drop v_i−v_j equals resistance by Ohm's law, giving the pseudoinverse quadratic form.

$$
R_{ij}=(e_i-e_j)^TL^+(e_i-e_j)
$$

## Assumptions

- Connected undirected network with positive conductances; or restrict to one connected component.

## Worked check

Two unit resistors in series have resistance 2; two parallel unit resistors have resistance 1/2.

## Limits

- A semantic graph only borrows this geometry; edge weights are not electrical conductances unless physically defined.

## Connections

- prerequisite_of (incoming): [[public--m-laplacian]]
- prerequisite_of (incoming): [[public--m-pseudoinverse]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
