---
id: "g-graphiti"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Graphiti temporal graph

A candidate external implementation for evolving relational memories, requiring its own deployment, licenses, and benchmark checks.

## Connections

- prerequisite_of (incoming): [[public--g-time]]

## Sources

- [Graphiti project](https://github.com/getzep/graphiti) — repository-overview

Evidence links and mathematical analogies do not grant tool permissions.
