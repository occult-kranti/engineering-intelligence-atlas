---
id: "g-hopfield"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Hopfield associative memory

Under symmetric weights and asynchronous binary updates, a Lyapunov function can decrease toward stable states.

## Connections

- prerequisite_of (incoming): [[public--g-hebb]]
- prerequisite_of (outgoing): [[public--g-attention]]
- analogy (outgoing): [[public--g-magnetism-bridge]]
- prerequisite_of (outgoing): [[public--gf-hopfield-energy]]

## Sources

- [Neural networks and physical systems with emergent collective computational abilities](https://pmc.ncbi.nlm.nih.gov/articles/PMC346238/) — abstract-and-original-paper-discovery

Evidence links and mathematical analogies do not grant tool permissions.
