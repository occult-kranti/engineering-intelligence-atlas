---
id: "m-ai-grh"
domain: "ai-mathematics"
status: "strong_independent_formal_verification_for_dirichlet_scope"
scope: "public"
tags: [daftar, research-memory]
---

# Dirichlet generalized RH: independently checked scope

MIT reports independently checked critical-strip zero statements for Dirichlet L-functions across all positive moduli and all characters, including the primitive-character formulation.

## Connections

- prerequisite_of (incoming): [[public--m-zeta]]
- prerequisite_of (incoming): [[public--m-representations]]

## Sources

- [Alpöge's Riemann Hypothesis announcement](https://alpo.ge/remark.pdf) — four-page PDF inspected
- [RH Lean proof: verification files, Andrew Sutherland](https://math.mit.edu/~drew/grh/) — summary, theorem/axiom checklist and dated checker status inspected

Evidence links and mathematical analogies do not grant tool permissions.
