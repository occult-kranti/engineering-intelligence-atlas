---
id: "m-ai-ymgap"
domain: "ai-mathematics"
status: "no_decisive_mass_gap_proof_identified"
scope: "public"
tags: [daftar, research-memory]
---

# Complete Yang–Mills existence and mass-gap problem

The complete Clay problem remains labelled Unsolved in the retrieved record.

## Connections

- prerequisite_of (incoming): [[public--m-operators]]
- prerequisite_of (incoming): [[public--m-pde]]

## Sources

- [Clay Mathematics Institute: Yang–Mills and the Mass Gap](https://www.claymath.org/millennium/yang-mills-the-maths-gap/) — current label and problem summary inspected
- [Yang–Mills working-group results and verification](https://github.com/yang-mills-group/YM) — assessment scope in README inspected

Evidence links and mathematical analogies do not grant tool permissions.
