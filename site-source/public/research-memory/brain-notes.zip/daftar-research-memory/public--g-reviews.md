---
id: "g-reviews"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Independent criticism

A critic checks original evidence and assumptions, then identifies a concrete falsifier or repair. Agent agreement is not source independence.

## Connections

- prerequisite_of (incoming): [[public--g-leakage]]
- prerequisite_of (outgoing): [[public--g-questions]]
- related (incoming): [[public--g-provenance]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
