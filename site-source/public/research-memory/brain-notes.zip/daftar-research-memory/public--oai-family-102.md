---
id: "oai-family-102"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# The Unique Games Conjecture and optimal approximation thresholds

Publisher catalogue family with 5 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0202]]
- member_of (incoming): [[public--oai-paper-0203]]
- member_of (incoming): [[public--oai-paper-0204]]
- member_of (incoming): [[public--oai-paper-0205]]
- member_of (incoming): [[public--oai-paper-0206]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
