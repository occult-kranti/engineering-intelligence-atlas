---
id: "gf-bm25"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# BM25 retrieval score

The fractional term grows with term frequency but saturates. Length normalization changes the denominator according to relative document length.

$$
S(q,d)=\sum_{t\in q}\operatorname{idf}(t)\frac{f_{t,d}(k_1+1)}{f_{t,d}+k_1(1-b+b|d|/\overline{|d|})}
$$

## Assumptions

- Chosen tokenizer and document construction are fixed.
- Implementation uses k1=1.2 and b=0.75.

## Worked check

If a document has average length and term frequency 1, the fraction equals 1, leaving exactly its IDF contribution.

## Limits

- These constants are a baseline, not optimized for this corpus. Repeated labels receive deliberate extra weight.

## Connections

- prerequisite_of (incoming): [[public--g-idf]]

## Sources

- [The Probabilistic Relevance Framework: BM25 and Beyond](https://doi.org/10.1561/1500000019) — publisher-metadata-and-abstract

Evidence links and mathematical analogies do not grant tool permissions.
