---
id: "mf-yoneda"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Yoneda lemma

Map a natural transformation η to η_A(id_A). Conversely an element x∈F(A) defines η_B(f)=F(f)(x). Functoriality establishes naturality, and evaluating at identity shows these constructions are inverse.

$$
\operatorname{Nat}(\operatorname{Hom}(A,-),F)\cong F(A)
$$

## Assumptions

- Category is locally small and F is covariant for the displayed form.

## Worked check

For vector spaces, natural ways of evaluating maps out of A are determined by the image of a distinguished element under those maps.

## Limits

- The lemma concerns formal morphism structure, not the claim that every object or memory is completely known from finite observed associations.

## Connections

- prerequisite_of (incoming): [[public--m-natural]]
- prerequisite_of (incoming): [[public--m-universal]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected

Evidence links and mathematical analogies do not grant tool permissions.
