---
id: "g-laplacian"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Graph Laplacian

L=D-A encodes local differences for an undirected nonnegative weighted graph. It has a constant-vector nullspace on each component.

## Connections

- prerequisite_of (incoming): [[public--g-degree]]
- prerequisite_of (outgoing): [[public--g-dirichlet]]
- prerequisite_of (outgoing): [[public--g-diffusion]]
- prerequisite_of (outgoing): [[public--gf-dirichlet]]
- prerequisite_of (outgoing): [[public--gf-heat]]
- prerequisite_of (outgoing): [[public--gf-graph-wave]]
- related (outgoing): [[public--p-poisson]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
