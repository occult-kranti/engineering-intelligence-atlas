---
id: "m-commutative"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Commutative algebra

Localization and prime ideals connect polynomial equations with geometric spaces.

## Connections

- prerequisite_of (incoming): [[public--m-rings]]
- prerequisite_of (outgoing): [[public--m-schemes]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
