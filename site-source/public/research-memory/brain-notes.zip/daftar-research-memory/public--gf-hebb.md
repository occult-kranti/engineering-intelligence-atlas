---
id: "gf-hebb"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Simple Hebbian weight construction

Correlated components contribute positive weights and opposite components negative weights; summing patterns superposes their associations.

$$
W_{ij}=\frac1N\sum_{\mu=1}^{P}\xi_i^{(\mu)}\xi_j^{(\mu)},\qquad W_{ii}=0
$$

## Assumptions

- A specified binary-pattern associative model.
- This is a theoretical rule, not a universal synaptic law.

## Worked check

For one pattern (1,-1), the off-diagonal weights are -1/2 under N=2 normalization.

## Limits

- Interference and spurious attractors occur. Coactivation does not imply causal evidence.

## Connections

- prerequisite_of (incoming): [[public--g-hebb]]

## Sources

- [Neural networks and physical systems with emergent collective computational abilities](https://pmc.ncbi.nlm.nih.gov/articles/PMC346238/) — abstract-and-original-paper-discovery

Evidence links and mathematical analogies do not grant tool permissions.
