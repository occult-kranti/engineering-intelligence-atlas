---
id: "m-weak"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Weak solutions and variational formulations

Testing against smooth functions changes the solution class and requires explicit energy and uniqueness conditions.

## Connections

- prerequisite_of (incoming): [[public--m-divergence]]
- prerequisite_of (outgoing): [[public--m-fem]]
- prerequisite_of (outgoing): [[public--m-ai-nsforced]]
- prerequisite_of (outgoing): [[public--mf-sobolev]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
