---
id: "g-backlink"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Backlinks

An incoming link is a reverse lookup of an existing edge, not a second independent source.

## Connections

- prerequisite_of (incoming): [[public--g-edge]]
- prerequisite_of (outgoing): [[public--g-obsidian]]

## Sources

- [Obsidian Help: Backlinks](https://obsidian.md/help/plugins/backlinks) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
