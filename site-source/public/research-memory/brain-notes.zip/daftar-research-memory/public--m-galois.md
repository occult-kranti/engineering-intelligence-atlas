---
id: "m-galois"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Galois correspondence

For finite Galois extensions, subfields and symmetry subgroups correspond in reverse inclusion.

## Connections

- prerequisite_of (incoming): [[public--m-fields]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
