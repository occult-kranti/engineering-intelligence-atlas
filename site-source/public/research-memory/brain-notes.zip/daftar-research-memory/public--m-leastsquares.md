---
id: "m-leastsquares"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Least squares and projection

Projection minimizes squared error under an explicitly chosen norm.

## Connections

- prerequisite_of (incoming): [[public--m-inner]]
- prerequisite_of (outgoing): [[public--m-conditioning]]
- prerequisite_of (outgoing): [[public--mf-least]]
- prerequisite_of (outgoing): [[public--mf-tikhonov]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
