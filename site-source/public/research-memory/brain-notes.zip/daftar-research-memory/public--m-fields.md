---
id: "m-fields"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Fields and extensions

A field permits division by nonzero elements; extensions add algebraic or transcendental elements.

## Connections

- prerequisite_of (incoming): [[public--m-rings]]
- prerequisite_of (outgoing): [[public--m-galois]]
- prerequisite_of (outgoing): [[public--m-primes]]
- prerequisite_of (outgoing): [[public--m-ai-unitdistance]]
- prerequisite_of (outgoing): [[public--m-ai-vpvnp]]
- prerequisite_of (outgoing): [[public--mf-galois]]
- prerequisite_of (outgoing): [[public--mf-elliptic]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
