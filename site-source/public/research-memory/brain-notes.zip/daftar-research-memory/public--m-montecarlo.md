---
id: "m-montecarlo"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Monte Carlo and sampling error

Variance and dependence determine effective precision; more repeated samples need not mean more independent information.

## Connections

- prerequisite_of (incoming): [[public--m-gaussian]]
- prerequisite_of (outgoing): [[public--m-concentration]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
