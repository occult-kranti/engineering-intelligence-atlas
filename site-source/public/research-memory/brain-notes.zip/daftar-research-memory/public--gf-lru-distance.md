---
id: "gf-lru-distance"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Fully associative LRU hit condition

Every distinct intervening item moves the reused entry down one position in the recency stack; capacity C retains the first C positions.

$$
\text{hit at capacity }C\iff d_{\rm reuse}<C
$$

## Assumptions

- Fully associative LRU.
- Uniform-sized entries and no external invalidation.
- First use has infinite reuse distance.

## Worked check

Trace A,B,C,A has reuse distance 2 for the last A: it misses at capacity 2 and hits at capacity 3.

## Limits

- The supplied persisted cache is FIFO and does not claim this LRU guarantee.

## Connections

- prerequisite_of (incoming): [[public--g-lru]]

## Sources

- [Efficient stack distance computation for priority replacement policies](https://research.ibm.com/publications/efficient-stack-distance-computation-for-priority-replacement-policies) — author-institution-abstract

Evidence links and mathematical analogies do not grant tool permissions.
