---
id: "gf-attention"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Scaled dot-product attention

Dot products give compatibility logits; scaling moderates their growth with dimension, softmax normalizes, and the resulting weights mix values.

$$
\operatorname{Attention}(Q,K,V)=\operatorname{softmax}(QK^T/\sqrt{d_k})V
$$

## Assumptions

- Matrix dimensions are compatible.
- Softmax operates across available keys, with any mask explicitly stated.

## Worked check

For two equal unmasked logits, each value receives weight 1/2.

## Limits

- A KV cache stores intermediate tensors; it is different from external source-linked memory.

## Connections

- prerequisite_of (incoming): [[public--g-attention]]

## Sources

- [Attention Is All You Need](https://papers.neurips.cc/paper_files/paper/2017/hash/3f5ee243547dee91fbd053c1c4a845aa-Abstract.html) — abstract-and-standard-equation
- [Hopfield Networks is All You Need](https://arxiv.org/abs/2008.02217) — abstract

Evidence links and mathematical analogies do not grant tool permissions.
