---
id: "m-rings"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Rings, ideals and quotients

Rings combine addition and multiplication; ideals specify which expressions become equal in a quotient.

## Connections

- prerequisite_of (incoming): [[public--m-groups]]
- prerequisite_of (outgoing): [[public--m-fields]]
- prerequisite_of (outgoing): [[public--m-commutative]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
