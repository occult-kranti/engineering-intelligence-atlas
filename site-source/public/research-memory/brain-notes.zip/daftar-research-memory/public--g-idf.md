---
id: "g-idf"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Inverse document frequency

Rare query terms receive greater discriminating weight in a chosen eligible corpus. Compute counts after scope filtering.

## Connections

- prerequisite_of (incoming): [[public--g-tokens]]
- prerequisite_of (outgoing): [[public--g-bm25]]
- prerequisite_of (outgoing): [[public--gf-idf]]
- prerequisite_of (outgoing): [[public--gf-bm25]]

## Sources

- [The Probabilistic Relevance Framework: BM25 and Beyond](https://doi.org/10.1561/1500000019) — publisher-metadata-and-abstract

Evidence links and mathematical analogies do not grant tool permissions.
