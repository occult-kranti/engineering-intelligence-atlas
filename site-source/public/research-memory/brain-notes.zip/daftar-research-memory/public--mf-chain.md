---
id: "mf-chain"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Multivariable chain rule

Insert the local expansion g(x+h)=g(x)+Dg(x)h+o(||h||) into the local expansion of f. The linear term is Df(g(x))Dg(x)h and the combined remainder stays smaller than ||h||. Reverse-mode differentiation transposes this product when propagating a scalar loss gradient.

$$
D(f\circ g)(x)=Df(g(x))Dg(x)
$$

## Assumptions

- Both functions are differentiable at the relevant points; matrix shapes must compose.

## Worked check

For g(x)=(x,x²), f(u,v)=u+3v, the derivative is [1,3]·[1,2x]ᵀ=1+6x.

## Limits

- Nondifferentiable branches require subgradient or piecewise reasoning; automatic differentiation follows program semantics, which may differ from an intended model.

## Connections

- prerequisite_of (incoming): [[public--m-derivative]]
- prerequisite_of (incoming): [[public--m-vectors]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
