---
id: "m-graphdiffusion"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Graph diffusion and heat kernels

Diffusion smooths a signal across encoded edges and loses high-frequency distinctions.

## Connections

- prerequisite_of (incoming): [[public--m-heat]]
- prerequisite_of (incoming): [[public--m-spectral]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
