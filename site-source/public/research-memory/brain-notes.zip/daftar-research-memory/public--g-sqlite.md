---
id: "g-sqlite"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# SQLite transaction isolation

Serialized writers and read snapshots are a possible next storage backend when filesystem snapshots become insufficient.

## Connections

- prerequisite_of (outgoing): [[public--g-wal]]

## Sources

- [SQLite isolation](https://www.sqlite.org/isolation.html) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
