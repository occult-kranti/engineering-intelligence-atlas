---
id: "m-category"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Categories and composition

Objects, morphisms and their lawful composition give a language for comparisons across subjects.

## Connections

- prerequisite_of (incoming): [[public--m-sets]]
- prerequisite_of (outgoing): [[public--m-functor]]
- related (outgoing): [[public--m-schemes]]
- prerequisite_of (outgoing): [[public--m-ai-langlands]]
- prerequisite_of (outgoing): [[public--mf-naturality]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
