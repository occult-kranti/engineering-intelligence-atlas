---
id: "m-wave"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Wave propagation

Wave equations carry finite-speed propagation under appropriate local coefficients.

## Connections

- prerequisite_of (outgoing): [[public--m-ai-smoothing]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
