---
id: "m-induction"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Induction and recursion

A base case and a justified successor step establish an infinite family without checking every case.

## Connections

- prerequisite_of (incoming): [[public--m-logic]]
- prerequisite_of (outgoing): [[public--m-proof]]
- prerequisite_of (outgoing): [[public--mf-binomial]]
- prerequisite_of (outgoing): [[public--mf-walks]]
- prerequisite_of (outgoing): [[public--mf-bellman]]

## Sources

- [Theorem Proving in Lean 4: Axioms and Computation](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/) — chapter inspected

Evidence links and mathematical analogies do not grant tool permissions.
