---
id: "mf-ftc"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Fundamental theorem of calculus

Changing the upper limit by h adds the integral over a short interval. Dividing by h gives its mean value, which tends to f(x) by continuity. Integrating a derivative then telescopes local changes into the total endpoint difference.

$$
\frac d{dx}\int_a^x f(t)\,dt=f(x),\quad \int_a^b F'(x)\,dx=F(b)-F(a)
$$

## Assumptions

- Continuity suffices for the first identity; suitable absolute continuity suffices for the integral identity.

## Worked check

Integrating 2x from 0 to 3 gives [x²]₀³=9.

## Limits

- Improper endpoints and singular distributions need separate convergence or weak-form arguments.

## Connections

- prerequisite_of (incoming): [[public--m-limits]]
- prerequisite_of (incoming): [[public--m-integral]]
- prerequisite_of (incoming): [[public--m-derivative]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
