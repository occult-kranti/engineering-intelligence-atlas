---
id: "g-cost"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Cost and latency accounting

Separate wall-clock time, local compute, provider tokens, and billable money. Report measured receipts, not inferred savings.

## Connections

- prerequisite_of (incoming): [[public--g-provider-cache]]
- prerequisite_of (outgoing): [[public--gf-latency]]

## Sources

- [OpenAI API documentation: Prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching) — official-indexed-documentation-and-local-sdk-field-inspection

Evidence links and mathematical analogies do not grant tool permissions.
