---
id: "g-rrf"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Reciprocal rank fusion

Combine lexical and graph rankings without pretending their raw scores have the same scale. Report the chosen constants.

## Connections

- prerequisite_of (incoming): [[public--g-bm25]]
- prerequisite_of (outgoing): [[public--g-budget]]
- prerequisite_of (incoming): [[public--g-cosine]]
- prerequisite_of (incoming): [[public--g-convergence]]
- related (outgoing): [[public--g-hindsight]]
- prerequisite_of (outgoing): [[public--gf-mmr]]

## Sources

- [Reciprocal Rank Fusion outperforms Condorcet and individual Rank Learning Methods](https://cormack.uwaterloo.ca/cormack/cormacksigir09-rrf.pdf) — original-paper-selected-sections

Evidence links and mathematical analogies do not grant tool permissions.
