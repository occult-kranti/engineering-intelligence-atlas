---
id: "g-tokens"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Tokenization

Normalize text, choose word boundaries, handle domain symbols, and record stopword policy. These choices change ranking.

## Connections

- prerequisite_of (outgoing): [[public--g-idf]]
- prerequisite_of (outgoing): [[public--gf-idf]]

## Sources

- [The Probabilistic Relevance Framework: BM25 and Beyond](https://doi.org/10.1561/1500000019) — publisher-metadata-and-abstract

Evidence links and mathematical analogies do not grant tool permissions.
