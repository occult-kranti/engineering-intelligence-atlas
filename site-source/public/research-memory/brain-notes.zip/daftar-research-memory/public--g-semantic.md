---
id: "g-semantic"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Semantic memory

Curated concepts compress experience into reusable knowledge. Preserve links back to observations to detect errors introduced by compression.

## Connections

- prerequisite_of (incoming): [[public--g-episodic]]
- prerequisite_of (outgoing): [[public--g-replay]]
- prerequisite_of (outgoing): [[public--g-compression]]

## Sources

- [What Learning Systems do Intelligent Agents Need? Complementary Learning Systems Theory Updated](https://web.stanford.edu/~jlmcc/papers/KumaranHassabisMcClelland16FinalMS.pdf) — abstract-and-author-manuscript-discovery

Evidence links and mathematical analogies do not grant tool permissions.
