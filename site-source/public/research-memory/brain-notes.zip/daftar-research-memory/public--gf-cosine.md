---
id: "gf-cosine"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Cosine similarity

Divide the inner product by magnitudes to isolate the angle between vectors.

$$
\operatorname{sim}(x,y)=\frac{x^Ty}{\lVert x\rVert_2\lVert y\rVert_2}
$$

## Assumptions

- Both vectors have nonzero norm.
- Both come from the same compatible embedding space.

## Worked check

Vectors (1,0) and (1,1) have cosine 1/√2≈0.7071.

## Limits

- High similarity can link incompatible claims. Embeddings are a documented future adapter, not used in the implemented baseline.

## Connections

- prerequisite_of (incoming): [[public--g-embedding]]

## Sources

- [From RAG to Memory: Non-Parametric Continual Learning for Large Language Models](https://arxiv.org/html/2502.14802v2) — selected-methods-and-limitations

Evidence links and mathematical analogies do not grant tool permissions.
