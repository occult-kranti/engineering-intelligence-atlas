---
id: "mf-simpson"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Composite Simpson integration error

Fit a quadratic across each adjacent pair of subintervals and integrate that interpolant. Symmetry makes the rule exact even for cubic polynomials. Summing local remainders yields absolute error at most (b−a)h⁴ max|f⁽⁴⁾|/180.

$$
\int_a^b f(x)dx\approx\frac h3[f_0+f_N+4\!\sum_{j\ odd}f_j+2\!\sum_{j\ even,\ 0<j<N}f_j]
$$

## Assumptions

- N is even; f has bounded fourth derivative for the standard error bound.

## Worked check

On [0,1], f=x², N=2 gives (0.5/3)(0+4·0.25+1)=1/3 exactly.

## Limits

- Discontinuities or unresolved oscillation invalidate the smooth-error estimate; blindly refining without checking the function class is insufficient.

## Connections

- prerequisite_of (incoming): [[public--m-taylor]]
- prerequisite_of (incoming): [[public--m-quadrature]]
- prerequisite_of (incoming): [[public--m-integral]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
