---
id: "m-ai-ns-translation"
domain: "ai-mathematics"
status: "documented_translation_issue_not_refutation_of_final_formal_statement"
scope: "public"
tags: [daftar, research-memory]
---

# Navier–Stokes prose/formal translation criticism

The critique identifies differences between prose and formalized intermediate estimates.

## Connections

- prerequisite_of (incoming): [[public--m-proof]]
- prerequisite_of (incoming): [[public--m-types]]
- prerequisite_of (incoming): [[public--m-pde]]

## Sources

- [Navier-Stokes lost in translation](https://arxiv.org/abs/2610.08144) — abstract and documented comparison scope inspected

Evidence links and mathematical analogies do not grant tool permissions.
