---
id: "m-ai-oai-newnine"
domain: "ai-mathematics"
status: "metadata_only_no_theorem_adjudication"
scope: "public"
tags: [daftar, research-memory]
---

# OpenAI November 24 complexity and polytope additions

Nine new manuscripts in families 379–380 include tensor/circuit claims, multiplication exponents, sunflowers and linear programming.

## Connections

- prerequisite_of (incoming): [[public--m-complexity]]
- prerequisite_of (incoming): [[public--m-linearprogram]]

## Sources

- [OpenAI mathematics manuscript catalogue, pinned snapshot](https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/CONTENTS.md) — entire catalogue parsed for metadata
- [OpenAI mathematics release history, pinned snapshot](https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/history.md) — full history file inspected

Evidence links and mathematical analogies do not grant tool permissions.
