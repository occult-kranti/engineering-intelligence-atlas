---
id: "mf-homology"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Homology: cycles modulo boundaries

A cycle has no boundary, so it lies in ker ∂. Some cycles already bound a higher-dimensional cell and should not count as holes. Since every boundary is a cycle, quotienting by im ∂ is well-defined.

$$
H_k=\ker\partial_k/\operatorname{im}\partial_{k+1},\quad\partial_k\partial_{k+1}=0
$$

## Assumptions

- A chain complex with consecutive boundary maps composing to zero.
- Choose coefficient ring or field explicitly.

## Worked check

A triangular wire graph has one independent 1-cycle. Adding its filled triangular face makes that cycle a boundary, so it vanishes in H₁.

## Limits

- A cycle in a citation graph is not automatically a topological hole in a scientifically meaningful complex.

## Connections

- prerequisite_of (incoming): [[public--m-simplicial]]
- prerequisite_of (incoming): [[public--m-rank]]
- prerequisite_of (incoming): [[public--m-topology]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
