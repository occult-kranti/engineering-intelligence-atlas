---
id: "m-sets"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Sets, relations and functions

Functions require a domain, codomain and unambiguous output; relations need not be functions.

## Connections

- prerequisite_of (incoming): [[public--m-logic]]
- prerequisite_of (outgoing): [[public--m-equations]]
- prerequisite_of (outgoing): [[public--m-groups]]
- prerequisite_of (outgoing): [[public--m-graph]]
- prerequisite_of (outgoing): [[public--m-category]]
- prerequisite_of (outgoing): [[public--m-ai-catalogue]]

## Sources

- [Theorem Proving in Lean 4: Axioms and Computation](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/) — chapter inspected

Evidence links and mathematical analogies do not grant tool permissions.
