---
id: "m-ai-unforcedns"
domain: "ai-mathematics"
status: "conditional_artifact_inspected_unconditional_validation_incomplete"
scope: "public"
tags: [daftar, research-memory]
---

# Alpöge–Buckmaster unforced Navier–Stokes package

The available challenge declarations derive breakdown conditional on a bounded periodic similarity profile/certificate.

## Connections

- prerequisite_of (incoming): [[public--m-pde]]
- prerequisite_of (incoming): [[public--m-sobolev]]
- prerequisite_of (incoming): [[public--m-types]]
- prerequisite_of (incoming): [[public--m-floating]]

## Sources

- [Alpöge–Buckmaster unforced Navier–Stokes release](https://github.com/tristanbuckmaster/navier-stokes/tree/ad53419de079eb8f95f60313473374624a348546) — root and Lean READMEs inspected

Evidence links and mathematical analogies do not grant tool permissions.
