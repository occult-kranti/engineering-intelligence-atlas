---
id: "gf-ttl-probability"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Poisson-update freshness model

The no-update probability is the zero-count Poisson mass exp(-λt); subtract from one.

$$
\Pr(\text{at least one update in }t)=1-e^{-\lambda t}
$$

## Assumptions

- Updates are modeled as a homogeneous Poisson process.

## Worked check

With λ=1 update/hour and age 0.5 hour, probability of an intervening update is about 0.3935.

## Limits

- Real source changes are often bursty or adversarial. Versioned invalidation is stronger than this heuristic.

## Connections

- prerequisite_of (incoming): [[public--g-ttl]]
- prerequisite_of (incoming): [[public--g-time]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
