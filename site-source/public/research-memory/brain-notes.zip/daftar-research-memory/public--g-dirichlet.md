---
id: "g-dirichlet"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Discrete Dirichlet energy

The quadratic form sums weighted differences between linked vertices. Interpreting it as physical energy needs physical units and a calibrated model.

## Connections

- prerequisite_of (incoming): [[public--g-laplacian]]
- prerequisite_of (outgoing): [[public--g-grounding]]
- analogy (outgoing): [[public--g-physics-bridge]]
- prerequisite_of (outgoing): [[public--gf-grounded]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
