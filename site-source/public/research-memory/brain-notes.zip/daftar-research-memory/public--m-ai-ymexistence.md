---
id: "m-ai-ymexistence"
domain: "ai-mathematics"
status: "expert_assessment_read_existence_only"
scope: "public"
tags: [daftar, research-memory]
---

# Four-dimensional Yang–Mills existence assessment

The working group reports a Wilson-lattice scaling-limit construction satisfying Wightman axioms.

## Connections

- prerequisite_of (incoming): [[public--m-lie]]
- prerequisite_of (incoming): [[public--m-operators]]
- prerequisite_of (incoming): [[public--m-pde]]

## Sources

- [Yang–Mills working-group results and verification](https://github.com/yang-mills-group/YM) — assessment scope in README inspected
- [Working with academic communities to build scientific understanding](https://openai.com/index/building-scientific-understanding-with-academic-communities/) — dated page inspected

Evidence links and mathematical analogies do not grant tool permissions.
