---
id: "m-ai-unitdistance"
domain: "ai-mathematics"
status: "theorem_statement_and_external_review_report_read"
scope: "public"
tags: [daftar, research-memory]
---

# Planar unit distances: polynomial construction improvement

There is δ>0 and infinitely many n for which ν(n)≥n^(1+δ).

## Connections

- prerequisite_of (incoming): [[public--m-graph]]
- prerequisite_of (incoming): [[public--m-fields]]
- prerequisite_of (incoming): [[public--m-primes]]

## Sources

- [Planar Point Sets with Many Unit Distances](https://cdn.openai.com/pdf/74c24085-19b0-4534-9c90-465b8e29ad73/unit-distance-proof.pdf) — 18-page PDF; Theorem 1.1 and construction outline inspected
- [An OpenAI model has disproved a central conjecture in discrete geometry](https://openai.com/index/model-disproves-discrete-geometry-conjecture/) — announcement and external-review attribution inspected

Evidence links and mathematical analogies do not grant tool permissions.
