---
id: "m-floating"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Floating-point arithmetic

Finite precision makes operation order important and can destroy naive cancellation.

## Connections

- prerequisite_of (incoming): [[public--m-conditioning]]
- prerequisite_of (outgoing): [[public--m-cg]]
- prerequisite_of (outgoing): [[public--m-ai-unforcedns]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
