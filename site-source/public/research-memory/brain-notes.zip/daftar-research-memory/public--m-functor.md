---
id: "m-functor"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Functors and structure preservation

A functor must preserve identities and composition, not merely pair similar-looking objects.

## Connections

- prerequisite_of (incoming): [[public--m-category]]
- prerequisite_of (outgoing): [[public--m-natural]]
- prerequisite_of (outgoing): [[public--mf-naturality]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
