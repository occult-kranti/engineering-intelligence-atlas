---
id: "m-rank"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Rank and nullspace

The nullspace identifies invisible directions and prevents unjustified inversion.

## Connections

- prerequisite_of (incoming): [[public--m-basis]]
- prerequisite_of (outgoing): [[public--m-pseudoinverse]]
- prerequisite_of (outgoing): [[public--mf-svd]]
- prerequisite_of (outgoing): [[public--mf-homology]]
- prerequisite_of (outgoing): [[public--mf-eulerchar]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
