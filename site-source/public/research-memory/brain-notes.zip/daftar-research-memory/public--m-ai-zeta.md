---
id: "m-ai-zeta"
domain: "ai-mathematics"
status: "primary_abstract_and_provenance_read"
scope: "public"
tags: [daftar, research-memory]
---

# Claude-assisted simple critical-line zeta-zero proportion

The paper gives a simple critical-line zero proportion exceeding two thirds; a window calculation gives 0.6725.

## Connections

- prerequisite_of (incoming): [[public--m-zeta]]
- prerequisite_of (incoming): [[public--m-complexanalysis]]

## Sources

- [More than two thirds of the zeta zeros are simple and on the critical line](https://arxiv.org/abs/2608.13637v2) — abstract, version and provenance note inspected

Evidence links and mathematical analogies do not grant tool permissions.
