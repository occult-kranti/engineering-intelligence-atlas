---
id: "g-replay"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Replay and consolidation

Software can revisit cases and regression tests to consolidate a rule. This is a design analogy, not a demonstration of neural replay.

## Connections

- prerequisite_of (incoming): [[public--g-semantic]]
- analogy (outgoing): [[public--g-loop]]

## Sources

- [What Learning Systems do Intelligent Agents Need? Complementary Learning Systems Theory Updated](https://web.stanford.edu/~jlmcc/papers/KumaranHassabisMcClelland16FinalMS.pdf) — abstract-and-author-manuscript-discovery

Evidence links and mathematical analogies do not grant tool permissions.
