---
id: "m-dag"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# DAGs and topological ordering

A DAG permits prerequisite order; detected cycles need interpretation, not silent truncation.

## Connections

- prerequisite_of (incoming): [[public--m-shortest]]
- prerequisite_of (outgoing): [[public--m-scc]]
- prerequisite_of (outgoing): [[public--mf-dagtime]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
