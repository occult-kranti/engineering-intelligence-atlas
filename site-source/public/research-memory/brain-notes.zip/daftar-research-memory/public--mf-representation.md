---
id: "mf-representation"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Group representations preserve composition

A group action on a vector space is linear when each group element acts by an invertible linear map. Applying h then g must agree with applying gh, so matrix multiplication matches group composition.

$$
\rho(gh)=\rho(g)\rho(h),\quad\rho(e)=I
$$

## Assumptions

- Matrices are invertible and belong to one scalar field and vector space.

## Worked check

Planar rotations R(θ) satisfy R(θ+φ)=R(θ)R(φ). Their generator at zero is [[0,−1],[1,0]].

## Limits

- Different representations can describe the same abstract group; matrix dimension is not group order.

## Connections

- prerequisite_of (incoming): [[public--m-groups]]
- prerequisite_of (incoming): [[public--m-vectors]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected

Evidence links and mathematical analogies do not grant tool permissions.
