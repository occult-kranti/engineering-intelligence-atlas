---
id: "mf-tikhonov"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Ridge/Tikhonov regularization

Differentiate the penalized objective to get (AᵀA+λI)x=Aᵀb. In SVD coordinates each inverse gain becomes σ/(σ²+λ), bounded even for small σ. Stability is obtained by shrinking the recovered components toward the zero-centered prior preference.

$$
x_\lambda=(A^TA+\lambda I)^{-1}A^Tb,\qquad \lambda>0
$$

## Assumptions

- Minimize ||Ax−b||²+λ||x||² with compatible units and finite real A.

## Worked check

For a scalar A=0.001 and λ=0.01, the gain is about 0.1 instead of the unregularized 1000.

## Limits

- Regularization adds bias and requires a scale-dependent λ; it does not create observations of the nullspace.

## Connections

- prerequisite_of (incoming): [[public--m-leastsquares]]
- prerequisite_of (incoming): [[public--m-svd]]
- prerequisite_of (incoming): [[public--m-regularization]]

## Sources

- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out
- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
