---
id: "g-obsidian"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Obsidian-compatible notes

Export stable concept notes with typed link descriptions, sources, status, and formulas. Native links alone carry no theorem-verification status.

## Connections

- prerequisite_of (incoming): [[public--g-backlink]]
- prerequisite_of (outgoing): [[public--g-foam]]
- prerequisite_of (outgoing): [[public--g-logseq]]

## Sources

- [Obsidian Help: Graph view](https://obsidian.md/help/plugins/graph) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
