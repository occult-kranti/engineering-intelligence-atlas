---
id: "m-ai-nsforced"
domain: "ai-mathematics"
status: "formal_theorem_evidence_strong_but_prose_translation_disputed"
scope: "public"
tags: [daftar, research-memory]
---

# Forced three-dimensional Navier–Stokes breakdown

For every ν>0, smooth compact forcing produces zero-initial-data smooth flow on [0,1) with bounded L² energy and unbounded L∞ near time 1.

## Connections

- prerequisite_of (incoming): [[public--m-pde]]
- prerequisite_of (incoming): [[public--m-sobolev]]
- prerequisite_of (incoming): [[public--m-weak]]
- prerequisite_of (incoming): [[public--m-types]]

## Sources

- [Finite time blowup for Navier–Stokes](https://cdn.openai.com/pdf/32d9f210-8b73-45e0-91bc-82a30aef8a9a/navier-stokes.pdf) — Theorem 1.1 and proof-outline introduction inspected
- [OpenAI NavierStokesAndEuler formalization](https://github.com/openai/NavierStokesAndEuler/tree/f9e8bc5b38b6e212696e8a30e3e91517af887bbd) — README and formalization metadata inspected
- [Independent Navier–Stokes formal audit](https://github.com/francescoantoniodeluca/navier-stokes-formal-audit/tree/c2e4f438f7af8bbf222a59801696aca2c3c15b6f) — README, exact upstream revision and scope inspected
- [Clay Mathematics Institute: Navier–Stokes Equation](https://www.claymath.org/millennium/navier-stokes-equation/) — current status label inspected
- [Navier-Stokes lost in translation](https://arxiv.org/abs/2610.08144) — abstract and documented comparison scope inspected

Evidence links and mathematical analogies do not grant tool permissions.
