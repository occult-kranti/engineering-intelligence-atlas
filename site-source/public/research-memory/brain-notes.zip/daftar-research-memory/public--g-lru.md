---
id: "g-lru"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Least recently used eviction

Retain recently accessed entries subject to a capacity. Recency is a policy, not evidence quality or correctness.

## Connections

- prerequisite_of (incoming): [[public--g-cache]]
- prerequisite_of (outgoing): [[public--g-fifo]]
- prerequisite_of (outgoing): [[public--gf-lru-distance]]

## Sources

- [Efficient stack distance computation for priority replacement policies](https://research.ibm.com/publications/efficient-stack-distance-computation-for-priority-replacement-policies) — author-institution-abstract

Evidence links and mathematical analogies do not grant tool permissions.
