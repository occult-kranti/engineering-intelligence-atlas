---
id: "gf-retention"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Exponential retrieval-priority heuristic

Solve dw/dt=−w/τ. This defines a convenient recency prior; it is not fitted biological evidence.

$$
w(t)=w_0e^{-t/\tau}
$$

## Assumptions

- A software prioritization rule is explicitly chosen.

## Worked check

After time τ, weight is w0/e≈0.3679w0.

## Limits

- Never let an arbitrary decay delete provenance or turn an established theorem false.

## Connections

- prerequisite_of (incoming): [[public--g-forgetting]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
