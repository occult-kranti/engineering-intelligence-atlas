---
id: "g-adjacency"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Adjacency matrix

Matrix A encodes weighted vertex relations; its orientation convention must match transition equations.

## Connections

- prerequisite_of (outgoing): [[public--g-degree]]
- prerequisite_of (outgoing): [[public--g-walk]]
- prerequisite_of (outgoing): [[public--gf-laplacian]]
- prerequisite_of (outgoing): [[public--gf-transition]]
- prerequisite_of (incoming): [[public--m-vectors]]

## Sources

- [The PageRank Citation Ranking: Bringing Order to the Web](https://ilpubs.stanford.edu/422/) — original-report-discovery

Evidence links and mathematical analogies do not grant tool permissions.
