---
id: "gf-entropy"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Shannon entropy of a declared distribution

Weight each outcome's self-information by its probability. This measures uncertainty of that distribution, not semantic wisdom.

$$
H(X)=-\sum_x p(x)\log_2 p(x)
$$

## Assumptions

- A normalized distribution and outcome space are specified.
- Use 0 log 0=0 by continuity.

## Worked check

A fair binary variable has entropy 1 bit; a deterministic variable has entropy 0.

## Limits

- Low entropy may reflect unwarranted certainty. It is not evidence quality.

## Connections

- prerequisite_of (incoming): [[public--g-entropy]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
