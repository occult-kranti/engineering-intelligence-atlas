---
id: "mf-markov"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Markov transition and stationary distribution

The probability of arriving at j is the sum over departure states i of p_t(i)P_ij. A stationary vector is unchanged by this linear map. Existence alone does not imply convergence: periodic chains can keep oscillating.

$$
p_{t+1}=P^Tp_t,\quad P\mathbf1=\mathbf1,\quad P^T\pi=\pi
$$

## Assumptions

- P has nonnegative entries and rows sum to one.
- Finite irreducibility and aperiodicity ensure convergence to a unique stationary distribution.

## Worked check

P=[[0,1],[1,0]] has stationary π=(1/2,1/2) but an initial point mass alternates forever.

## Limits

- A memory process is Markov only relative to its chosen state; omitted history can break the assumption.

## Connections

- prerequisite_of (incoming): [[public--m-probability]]
- prerequisite_of (incoming): [[public--m-adjacency]]
- prerequisite_of (incoming): [[public--m-spectral]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected
- [The PageRank Citation Ranking: Bringing Order to the Web](https://cs.brown.edu/courses/csci2531/papers/pagerank.pdf) — 17-page PDF and random-surfer model inspected

Evidence links and mathematical analogies do not grant tool permissions.
