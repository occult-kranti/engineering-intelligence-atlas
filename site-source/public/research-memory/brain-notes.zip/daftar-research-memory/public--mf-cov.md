---
id: "mf-cov"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Covariance and variance propagation

Expand the square of aᵀ(X−EX); linearity of expectation turns pairwise products into covariance entries. Cross terms matter whenever variables are dependent, so adding marginal variances alone is generally wrong.

$$
\operatorname{Cov}(X,Y)=E[(X-EX)(Y-EY)],\quad \operatorname{Var}(a^TX)=a^T\Sigma a
$$

## Assumptions

- Second moments exist.

## Worked check

If X=Y with variance 1, Var(X+Y)=4. Treating the copies as independent would incorrectly give 2.

## Limits

- Correlation zero does not imply independence; for a symmetric nonconstant X, X and X² can be uncorrelated but dependent.

## Connections

- prerequisite_of (incoming): [[public--m-probability]]
- prerequisite_of (incoming): [[public--m-vectors]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected
- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
