---
id: "mf-quadratic"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Quadratic equation by completing the square

Divide by a and move c/a. Adding (b/2a)² makes (x+b/2a)²=(b²−4ac)/(4a²). Taking both square roots and subtracting b/2a gives the formula. The division step excludes a=0, which must instead be treated as a linear or constant equation.

$$
x=\frac{-b\pm\sqrt{b^2-4ac}}{2a}
$$

## Assumptions

- a is nonzero.
- Use real roots only when the discriminant is nonnegative; over complex numbers select both square roots.

## Worked check

For x²−5x+6=0 the discriminant is 1 and the roots are 2 and 3; substitution makes each residual zero.

## Limits

- Direct evaluation can lose precision when b and the square root nearly cancel; compute one root stably and obtain the other from their product c/a.

## Connections

- prerequisite_of (incoming): [[public--m-equations]]
- prerequisite_of (incoming): [[public--m-polynomials]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
