---
id: "gf-brier"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Brier calibration score

Use the squared error of probabilistic predictions and average over evaluated cases.

$$
B=\frac1n\sum_{i=1}^n(p_i-y_i)^2
$$

## Assumptions

- A well-defined population of binary outcomes.
- Predictions precede observed outcomes.

## Worked check

Predictions (0.8,0.2) for outcomes (1,0) have Brier score 0.04.

## Limits

- Graph ranks and RRF scores are not probabilities and must not be inserted directly as calibrated confidence.

## Connections

- prerequisite_of (incoming): [[public--g-calibration]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
