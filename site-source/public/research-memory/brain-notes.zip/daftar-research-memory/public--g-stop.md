---
id: "g-stop"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Stopping criteria

Stop when acceptance is met, a bound is reached, or a decisive missing record blocks further progress; preserve the remaining question.

## Connections

- prerequisite_of (incoming): [[public--g-loop]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
