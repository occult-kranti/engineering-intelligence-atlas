---
id: "oai-family-034"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# Log abundance for compact Kähler spaces under logarithmic Iitaka subadditivity

Publisher catalogue family with 14 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0069]]
- member_of (incoming): [[public--oai-paper-0070]]
- member_of (incoming): [[public--oai-paper-0071]]
- member_of (incoming): [[public--oai-paper-0072]]
- member_of (incoming): [[public--oai-paper-0073]]
- member_of (incoming): [[public--oai-paper-0074]]
- member_of (incoming): [[public--oai-paper-0075]]
- member_of (incoming): [[public--oai-paper-0076]]
- member_of (incoming): [[public--oai-paper-0077]]
- member_of (incoming): [[public--oai-paper-0078]]
- member_of (incoming): [[public--oai-paper-0079]]
- member_of (incoming): [[public--oai-paper-0080]]
- member_of (incoming): [[public--oai-paper-0081]]
- member_of (incoming): [[public--oai-paper-0082]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
