---
id: "mf-pagerank"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Personalized PageRank as a convergent recurrence

The recurrence alternates graph-following with restart. Because αPᵀ contracts the ℓ₁ norm by at most α, the fixed point is unique. Expanding the inverse gives a geometrically damped sum of walk distributions, so long loops cannot add unlimited mass.

$$
r=\alpha P^Tr+(1-\alpha)v=(1-\alpha)(I-\alpha P^T)^{-1}v
$$

## Assumptions

- 0≤α<1; v is nonnegative and sums to one; every row of P sums to one.

## Worked check

For a two-state swap chain, α=0.8, v=(1,0), solve r₁=.8r₂+.2 and r₂=.8r₁: r=(5/9,4/9).

## Limits

- High graph rank is not credibility. Typed relations, permissions and source validity must be filtered before ranking.

## Connections

- prerequisite_of (incoming): [[public--m-markov]]
- prerequisite_of (incoming): [[public--m-fixedpoint]]

## Sources

- [The PageRank Citation Ranking: Bringing Order to the Web](https://cs.brown.edu/courses/csci2531/papers/pagerank.pdf) — 17-page PDF and random-surfer model inspected

Evidence links and mathematical analogies do not grant tool permissions.
