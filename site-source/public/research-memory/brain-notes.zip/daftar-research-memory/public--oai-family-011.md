---
id: "oai-family-011"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# Prime-factor statistics of $`p-1`$

Publisher catalogue family with 3 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0021]]
- member_of (incoming): [[public--oai-paper-0022]]
- member_of (incoming): [[public--oai-paper-0023]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
