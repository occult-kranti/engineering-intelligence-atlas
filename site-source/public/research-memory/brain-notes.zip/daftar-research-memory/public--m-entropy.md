---
id: "m-entropy"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Shannon entropy

Entropy quantifies a distribution's uncertainty in specified log units.

## Connections

- prerequisite_of (incoming): [[public--m-bayes]]
- prerequisite_of (outgoing): [[public--m-kl]]
- prerequisite_of (outgoing): [[public--mf-kl]]
- prerequisite_of (outgoing): [[public--mf-mi]]

## Sources

- [Entropy, Relative Entropy, and Mutual Information, Tsachy Weissman](https://web.stanford.edu/class/ee376a/files/lecture_3.pdf) — five-page PDF; definitions and nonnegativity argument inspected

Evidence links and mathematical analogies do not grant tool permissions.
