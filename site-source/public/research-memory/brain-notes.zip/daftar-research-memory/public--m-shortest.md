---
id: "m-shortest"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Shortest paths and dynamic programming

Shortest cost depends on edge weights and constraints; it is not strongest evidence.

## Connections

- prerequisite_of (incoming): [[public--m-graph]]
- prerequisite_of (outgoing): [[public--m-dag]]
- prerequisite_of (outgoing): [[public--mf-bellman]]
- prerequisite_of (outgoing): [[public--mf-dagtime]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
