---
id: "g-logseq"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Logseq linked blocks

Block-focused navigation provides another authoring granularity; retain explicit IDs during interchange.

## Connections

- prerequisite_of (incoming): [[public--g-obsidian]]

## Sources

- [Logseq project](https://github.com/logseq/logseq) — repository-overview

Evidence links and mathematical analogies do not grant tool permissions.
