---
id: "g-kv"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Attention key-value cache

Cached intermediate key/value tensors reduce repeated attention computation during inference; they are not an editable evidence graph.

## Connections

- related (incoming): [[public--g-cache]]

## Sources

- [Attention Is All You Need](https://papers.neurips.cc/paper_files/paper/2017/hash/3f5ee243547dee91fbd053c1c4a845aa-Abstract.html) — abstract-and-standard-equation

Evidence links and mathematical analogies do not grant tool permissions.
