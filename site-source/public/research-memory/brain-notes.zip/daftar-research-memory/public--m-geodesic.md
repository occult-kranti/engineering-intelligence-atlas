---
id: "m-geodesic"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Geodesics and variational paths

A geodesic is locally stationary for geometric length or energy and need not be globally shortest.

## Connections

- related (incoming): [[public--m-variation]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected
- [Proof of the geometric Langlands conjecture I: construction of the functor](https://arxiv.org/abs/2405.03599v3) — abstract and version history inspected

Evidence links and mathematical analogies do not grant tool permissions.
