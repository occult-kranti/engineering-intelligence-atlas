---
id: "g-identity"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Entity identity and disambiguation

Same label can denote different things; same object can have many labels. Stable IDs and explicit aliases reduce accidental merging.

## Connections

- prerequisite_of (incoming): [[public--g-node]]
- prerequisite_of (outgoing): [[public--g-provenance]]
- related (incoming): [[public--g-mention]]

## Sources

- [Zep: A Temporal Knowledge Graph Architecture for Agent Memory](https://arxiv.org/html/2501.13956v1) — selected-methods

Evidence links and mathematical analogies do not grant tool permissions.
