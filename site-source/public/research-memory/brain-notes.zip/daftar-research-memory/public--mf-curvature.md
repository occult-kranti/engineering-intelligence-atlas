---
id: "mf-curvature"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Curvature as a covariant-derivative commutator

Two successive transports in different directions generally disagree. Subtract the reversed order and remove the discrepancy due merely to the noncommuting coordinate vector fields. The remainder is tensorial, defining curvature independently of the extension of local vectors.

$$
R(X,Y)Z=\nabla_X\nabla_YZ-\nabla_Y\nabla_XZ-\nabla_{[X,Y]}Z
$$

## Assumptions

- Smooth connection and vector fields; this equation declares the sign convention.

## Worked check

The standard flat connection in Cartesian Euclidean space has R=0, even when curvilinear coordinates make connection coefficients nonzero.

## Limits

- Different texts reverse the sign; comparing Ricci or Einstein equations requires a consistent convention throughout.

## Connections

- prerequisite_of (incoming): [[public--m-connection]]
- prerequisite_of (incoming): [[public--m-lie]]
- prerequisite_of (incoming): [[public--m-manifold]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
