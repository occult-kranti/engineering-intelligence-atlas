---
id: "g-publication"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Publication receipts

A local commit, remote tree, workflow result, and live page are separate observations. Record each accurately.

## Connections

- prerequisite_of (incoming): [[public--g-checkpoint]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
