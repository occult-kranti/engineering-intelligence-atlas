---
id: "mf-laplacebeltrami"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Metric Laplacian on a manifold

The gradient raises the derivative index with gⁱʲ. Divergence measures flux using the volume density √|g|. Combining the two gives the coordinate expression, ensuring the result is independent of the chosen chart.

$$
\Delta_gu=\frac1{\sqrt{|g|}}\partial_i\left(\sqrt{|g|}\,g^{ij}\partial_ju\right)
$$

## Assumptions

- For the elliptic Laplace–Beltrami operator use a positive-definite Riemannian metric.
- The analogous Lorentzian expression is a wave operator with sign conventions.

## Worked check

In polar plane coordinates g=diag(1,r²), the formula becomes u_rr+r⁻¹u_r+r⁻²u_θθ.

## Limits

- Coordinate singularities such as r=0 need regularity conditions; they are not automatically curvature singularities.

## Connections

- prerequisite_of (incoming): [[public--m-metric]]
- prerequisite_of (incoming): [[public--m-jacobian]]
- prerequisite_of (incoming): [[public--m-gradient]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
