---
id: "g-foam"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Foam in VS Code

An editor-centered knowledge workflow can reuse portable Markdown notes and backlinks.

## Connections

- prerequisite_of (incoming): [[public--g-obsidian]]

## Sources

- [Foam project](https://github.com/foambubble/foam) — repository-overview

Evidence links and mathematical analogies do not grant tool permissions.
