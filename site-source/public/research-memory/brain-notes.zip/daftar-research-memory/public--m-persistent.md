---
id: "m-persistent"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Persistent homology

Persistence tracks features across a scale parameter, not proof of their physical meaning.

## Connections

- prerequisite_of (incoming): [[public--m-homology]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
