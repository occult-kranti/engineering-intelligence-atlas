---
id: "mf-bayes"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Bayes rule with dependent evidence awareness

The joint probability satisfies P(H∩E)=P(E|H)P(H)=P(H|E)P(E). Dividing by the positive marginal yields Bayes' rule. Sequential updates must use P(E₂|H,E₁), not P(E₂|H), unless conditional independence is justified.

$$
P(H\mid E)=\frac{P(E\mid H)P(H)}{P(E)}
$$

## Assumptions

- P(E)>0.
- Probabilities refer to the same model and experiment.

## Worked check

Prior 0.1, likelihood 0.8 and false-positive likelihood 0.2 give posterior 0.08/(0.08+0.18)=4/13.

## Limits

- Two sites repeating one press release are dependent evidence; counting them as independent inflates confidence.

## Connections

- prerequisite_of (incoming): [[public--m-probability]]
- prerequisite_of (incoming): [[public--m-randomvariable]]

## Sources

- [MIT 18.05 Class 03: Conditional Probability, Independence, Bayes' Theorem](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/mit18_05_s22_lec03.pdf) — 23-page PDF; conditional probability, total probability and Bayes slides inspected

Evidence links and mathematical analogies do not grant tool permissions.
