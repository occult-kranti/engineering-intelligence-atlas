---
id: "g-checkpoint"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Durable checkpoints

Save an artifact and its identity at a meaningful boundary. A claimed checkpoint without a readable artifact is incomplete.

## Connections

- prerequisite_of (incoming): [[public--g-events]]
- prerequisite_of (outgoing): [[public--g-publication]]
- prerequisite_of (incoming): [[public--g-idempotency]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
