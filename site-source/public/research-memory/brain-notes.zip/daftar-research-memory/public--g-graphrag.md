---
id: "g-graphrag"
domain: "memory"
status: "representative-frontier"
scope: "public"
tags: [daftar, research-memory]
---

# GraphRAG and global synthesis

Community-level organization can help corpus-wide questions, but synthesis must remain auditable against original passages.

## Connections

- prerequisite_of (outgoing): [[public--g-zero]]

## Sources

- [From Local to Global: A Graph RAG Approach to Query-Focused Summarization](https://arxiv.org/abs/2404.16130) — abstract-and-official-publication

Evidence links and mathematical analogies do not grant tool permissions.
