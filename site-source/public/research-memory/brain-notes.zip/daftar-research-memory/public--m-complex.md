---
id: "m-complex"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Complex numbers and phase

A complex number combines two real coordinates; multiplication combines scale and angle.

## Connections

- prerequisite_of (incoming): [[public--m-polynomials]]
- prerequisite_of (outgoing): [[public--m-complexanalysis]]
- prerequisite_of (outgoing): [[public--m-fourier]]
- prerequisite_of (outgoing): [[public--mf-euler]]
- prerequisite_of (outgoing): [[public--mf-fourier]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
