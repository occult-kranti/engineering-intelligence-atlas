---
id: "oai-family-140"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# Memory–sample lower bounds for noiseless Gaussian regression

Publisher catalogue family with 6 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0267]]
- member_of (incoming): [[public--oai-paper-0268]]
- member_of (incoming): [[public--oai-paper-0269]]
- member_of (incoming): [[public--oai-paper-0270]]
- member_of (incoming): [[public--oai-paper-0271]]
- member_of (incoming): [[public--oai-paper-0272]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
