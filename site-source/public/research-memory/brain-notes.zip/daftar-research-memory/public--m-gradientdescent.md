---
id: "m-gradientdescent"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Gradient descent and step sizes

Step size and smoothness control descent; a large learning rate can cause oscillation.

## Connections

- prerequisite_of (incoming): [[public--m-optimization]]
- prerequisite_of (outgoing): [[public--m-duality]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
