---
id: "mf-inner"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Cauchy–Schwarz and cosine similarity

For y≠0 minimize ||x−αy||² over α. Nonnegativity at the minimizer gives ||x||²−|〈x,y〉|²/||y||²≥0. In real Euclidean geometry the normalized dot product therefore lies in [−1,1] and can define an angle.

$$
|\langle x,y\rangle|\le\|x\|\|y\|,\qquad \cos\theta=\frac{x^Ty}{\|x\|\|y\|}
$$

## Assumptions

- The angle formula uses real nonzero vectors.
- For complex spaces use the Hermitian inner product for the inequality.

## Worked check

x=(1,0), y=(1,1) have cosine 1/√2. x and 100x have cosine 1 even though their lengths differ by 100.

## Limits

- Similarity is undefined for a zero vector and is not a probability that two claims are true or equivalent.

## Connections

- prerequisite_of (incoming): [[public--m-vectors]]
- prerequisite_of (incoming): [[public--m-inner]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
