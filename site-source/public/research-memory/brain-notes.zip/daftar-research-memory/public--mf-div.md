---
id: "mf-div"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Divergence theorem

For a small box, opposite-face flux differences equal directional derivatives times volume to leading order. Interior faces cancel when boxes are assembled. Only the exterior boundary remains, producing the global conservation identity.

$$
\int_\Omega\nabla\cdot F\,dV=\int_{\partial\Omega}F\cdot n\,dS
$$

## Assumptions

- Ω has an appropriate piecewise smooth or Lipschitz boundary.
- F has sufficient classical or weak regularity.

## Worked check

For F=(x,y,z) on a radius-R ball, divergence is 3. Both sides equal 4πR³.

## Limits

- Point singularities require exclusion and limiting or distributional analysis; setting divergence to zero away from a source does not remove the source.

## Connections

- prerequisite_of (incoming): [[public--m-gradient]]
- prerequisite_of (incoming): [[public--m-integral]]
- prerequisite_of (incoming): [[public--m-jacobian]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
