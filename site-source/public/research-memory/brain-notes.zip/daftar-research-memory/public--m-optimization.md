---
id: "m-optimization"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Convex and nonconvex optimization

The feasible domain and curvature determine whether a stationary point is globally optimal.

## Connections

- prerequisite_of (incoming): [[public--m-gradient]]
- prerequisite_of (outgoing): [[public--m-gradientdescent]]
- prerequisite_of (outgoing): [[public--mf-gradient]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
