---
id: "mf-bellman"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Shortest-path Bellman recurrence

Any nonempty shortest route to v ends with an edge u→v; its prefix must be shortest to u, or replacing the prefix would improve the route. This optimal-substructure argument yields the recurrence and underlies dynamic programming.

$$
d(v)=\min_{(u,v)\in E}[d(u)+w(u,v)],\qquad d(s)=0
$$

## Assumptions

- No reachable negative cycle when seeking finite unconstrained distances.
- An initialization and update scheme consistent with the graph class is needed.

## Worked check

Edges s→a cost 2, a→b cost 3, s→b cost 8 produce d(b)=min(8,2+3)=5.

## Limits

- Dijkstra additionally needs nonnegative edges; the recurrence alone does not authorize it on arbitrary weights.

## Connections

- prerequisite_of (incoming): [[public--m-graph]]
- prerequisite_of (incoming): [[public--m-shortest]]
- prerequisite_of (incoming): [[public--m-induction]]

## Sources

- [Algorithms, chapter 8: Shortest Paths, Jeff Erickson](https://jeffe.cs.illinois.edu/teaching/algorithms/book/08-sssp.pdf) — 36-page chapter; relaxation, negative cycles and Bellman-Ford section inspected

Evidence links and mathematical analogies do not grant tool permissions.
