---
id: "m-tangent"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Tangent spaces and differential forms

Tangents represent velocities; cotangents act on them to give scalar measurements.

## Connections

- prerequisite_of (incoming): [[public--m-manifold]]
- prerequisite_of (outgoing): [[public--m-metric]]
- prerequisite_of (outgoing): [[public--mf-stokes]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
