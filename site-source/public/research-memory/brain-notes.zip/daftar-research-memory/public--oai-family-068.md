---
id: "oai-family-068"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# Anticanonical nonvanishing in every dimension

Publisher catalogue family with 7 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0137]]
- member_of (incoming): [[public--oai-paper-0138]]
- member_of (incoming): [[public--oai-paper-0139]]
- member_of (incoming): [[public--oai-paper-0140]]
- member_of (incoming): [[public--oai-paper-0141]]
- member_of (incoming): [[public--oai-paper-0142]]
- member_of (incoming): [[public--oai-paper-0143]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
