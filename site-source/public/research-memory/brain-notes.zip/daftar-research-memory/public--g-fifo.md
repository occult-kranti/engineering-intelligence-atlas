---
id: "g-fifo"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Bounded FIFO eviction

The supplied persistent result cache removes the oldest-written entries after 128 records. It is explicitly FIFO rather than LRU.

## Connections

- prerequisite_of (incoming): [[public--g-lru]]
- prerequisite_of (outgoing): [[public--g-ttl]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
