---
id: "gf-idf"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Positive inverse document frequency

The smoothed frequency ratio increases as a term becomes rarer; the outer 1 keeps this common BM25 variant positive.

$$
\operatorname{idf}(t)=\log\left(1+\frac{N-n_t+0.5}{n_t+0.5}\right)
$$

## Assumptions

- Compute statistics only over authorized active documents.
- Natural logarithm is used.

## Worked check

With N=100 and n_t=1, idf=ln(1+99.5/1.5)≈4.210.

## Limits

- Changing the corpus changes IDF. It does not measure the truth or novelty of a claim.

## Connections

- prerequisite_of (incoming): [[public--g-tokens]]
- prerequisite_of (incoming): [[public--g-idf]]

## Sources

- [The Probabilistic Relevance Framework: BM25 and Beyond](https://doi.org/10.1561/1500000019) — publisher-metadata-and-abstract

Evidence links and mathematical analogies do not grant tool permissions.
