---
id: "mf-newton"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Newton root iteration

Approximate f(x_k+h) by f(x_k)+f′(x_k)h and choose the linearized residual to vanish. The resulting correction is −f/f′. Near a simple root, the omitted Taylor term is quadratic, explaining the local rate.

$$
x_{k+1}=x_k-\frac{f(x_k)}{f'(x_k)}
$$

## Assumptions

- Derivative exists and is nonzero at iterates.
- Quadratic local convergence needs a simple root and smoothness near it.

## Worked check

For f(x)=x²−2 and x₀=1, iterates are 1.5, 1.41666…, 1.414215….

## Limits

- The iteration can diverge, cycle or cross a domain boundary; damping and bracketing address specific risks.

## Connections

- prerequisite_of (incoming): [[public--m-derivative]]
- prerequisite_of (incoming): [[public--m-taylor]]
- prerequisite_of (incoming): [[public--m-rootfinding]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
