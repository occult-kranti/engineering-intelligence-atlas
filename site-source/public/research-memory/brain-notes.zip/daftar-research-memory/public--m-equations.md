---
id: "m-equations"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Equations and reversible transformations

Division and squaring require domain checks to avoid dropping or adding solutions.

## Connections

- prerequisite_of (incoming): [[public--m-sets]]
- prerequisite_of (outgoing): [[public--m-polynomials]]
- prerequisite_of (outgoing): [[public--m-vectors]]
- prerequisite_of (outgoing): [[public--mf-quadratic]]
- prerequisite_of (outgoing): [[public--mf-derivative]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
