---
id: "m-types"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Dependent types and proof terms

Propositions can be represented as types and proofs as terms checked by a small kernel.

## Connections

- prerequisite_of (incoming): [[public--m-proof]]
- prerequisite_of (outgoing): [[public--m-axioms]]
- prerequisite_of (outgoing): [[public--m-ai-flt]]
- prerequisite_of (outgoing): [[public--m-ai-nsforced]]
- prerequisite_of (outgoing): [[public--m-ai-ns-translation]]
- prerequisite_of (outgoing): [[public--m-ai-rh]]
- prerequisite_of (outgoing): [[public--m-ai-unforcedns]]

## Sources

- [Theorem Proving in Lean 4: Axioms and Computation](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/) — chapter inspected

Evidence links and mathematical analogies do not grant tool permissions.
