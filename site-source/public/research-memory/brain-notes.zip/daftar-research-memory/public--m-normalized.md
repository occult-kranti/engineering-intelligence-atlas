---
id: "m-normalized"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Normalized graph Laplacian

Degree normalization controls the geometry used to compare cuts and random-walk mixing.

## Connections

- prerequisite_of (outgoing): [[public--mf-cheeger]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
