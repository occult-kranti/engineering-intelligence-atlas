---
id: "m-concentration"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Concentration inequalities

Bounds depend on independence or other assumptions and cannot be reused after arbitrary selection.

## Connections

- prerequisite_of (incoming): [[public--m-montecarlo]]
- prerequisite_of (outgoing): [[public--mf-hoeffding]]

## Sources

- [Concentration inequalities, Cosma Shalizi](https://www.stat.cmu.edu/~cshalizi/sml/21/lectures/06/lecture-06.html) — Hoeffding assumptions and bound inspected

Evidence links and mathematical analogies do not grant tool permissions.
