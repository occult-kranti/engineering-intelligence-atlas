---
id: "m-combinatorics"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Counting, extremal sets and Ramsey theory

Existence, constructive algorithms and optimal bounds are distinct questions.

## Connections

- prerequisite_of (outgoing): [[public--m-ai-imo]]
- prerequisite_of (outgoing): [[public--mf-permanent]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
