---
id: "g-budget"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Bounded evidence packets

Limit the evidence sent to a model while preserving source locators and caveats. Track omitted items rather than silently implying full coverage.

## Connections

- prerequisite_of (incoming): [[public--g-rrf]]
- prerequisite_of (outgoing): [[public--gf-budget-knapsack]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
