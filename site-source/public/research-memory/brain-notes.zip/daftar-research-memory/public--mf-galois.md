---
id: "mf-galois"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Finite Galois correspondence

Automorphisms fixing E form a subgroup. Conversely the elements fixed by a subgroup form a field. Normality and separability ensure enough automorphisms for these constructions to be inverse, reversing inclusion.

$$
E\longmapsto\operatorname{Gal}(L/E),\qquad H\longmapsto L^H,\qquad [L:E]=|\operatorname{Gal}(L/E)|
$$

## Assumptions

- L/K is finite, normal and separable.

## Worked check

Q(√2)/Q has two automorphisms, fixing or negating √2, and degree 2.

## Limits

- For a nongalois extension the simple correspondence and cardinality equality need modification.

## Connections

- prerequisite_of (incoming): [[public--m-fields]]
- prerequisite_of (incoming): [[public--m-groups]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected

Evidence links and mathematical analogies do not grant tool permissions.
