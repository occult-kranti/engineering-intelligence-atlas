---
id: "m-determinant"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Determinants and orientation

The determinant measures signed volume scaling of a square linear map.

## Connections

- prerequisite_of (outgoing): [[public--m-ai-vpvnp]]
- prerequisite_of (outgoing): [[public--mf-det]]
- prerequisite_of (outgoing): [[public--mf-jacobian]]
- prerequisite_of (outgoing): [[public--mf-gauss]]
- prerequisite_of (outgoing): [[public--mf-permanent]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
