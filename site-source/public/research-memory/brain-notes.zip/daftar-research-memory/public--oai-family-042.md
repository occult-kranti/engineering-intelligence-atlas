---
id: "oai-family-042"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# Oka classification for minimal compact complex surfaces: Kodaira dimension zero and class VII

Publisher catalogue family with 1 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0099]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
