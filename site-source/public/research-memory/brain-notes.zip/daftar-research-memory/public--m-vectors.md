---
id: "m-vectors"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Vector spaces and linear maps

Linearity means preserving addition and scalar multiplication; coordinates are a choice, not the object.

## Connections

- prerequisite_of (incoming): [[public--m-equations]]
- prerequisite_of (outgoing): [[public--m-basis]]
- prerequisite_of (outgoing): [[public--m-inner]]
- prerequisite_of (outgoing): [[public--mf-rank]]
- prerequisite_of (outgoing): [[public--mf-inner]]
- prerequisite_of (outgoing): [[public--mf-chain]]
- prerequisite_of (outgoing): [[public--mf-cov]]
- prerequisite_of (outgoing): [[public--mf-representation]]
- prerequisite_of (outgoing): [[public--g-adjacency]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
