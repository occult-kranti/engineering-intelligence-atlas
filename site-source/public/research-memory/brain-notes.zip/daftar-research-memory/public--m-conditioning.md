---
id: "m-conditioning"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Condition numbers

A stable algorithm cannot remove poor conditioning inherent in the mathematical problem.

## Connections

- prerequisite_of (incoming): [[public--m-leastsquares]]
- prerequisite_of (outgoing): [[public--m-floating]]
- related (outgoing): [[public--m-regularization]]
- prerequisite_of (outgoing): [[public--mf-cond]]
- prerequisite_of (outgoing): [[public--mf-cg]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
