---
id: "m-kl"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Relative entropy and information gain

KL is directional and can be infinite when support is missing.

## Connections

- prerequisite_of (incoming): [[public--m-entropy]]
- prerequisite_of (outgoing): [[public--m-mutual]]
- prerequisite_of (outgoing): [[public--mf-mi]]

## Sources

- [Entropy, Relative Entropy, and Mutual Information, Tsachy Weissman](https://web.stanford.edu/class/ee376a/files/lecture_3.pdf) — five-page PDF; definitions and nonnegativity argument inspected

Evidence links and mathematical analogies do not grant tool permissions.
