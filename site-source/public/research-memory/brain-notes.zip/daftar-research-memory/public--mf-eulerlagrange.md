---
id: "mf-eulerlagrange"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Euler–Lagrange stationarity

Perturb q by εη. Differentiate the action at ε=0: δS=∫(L_qη+L_qdotηdot)dt. Integration by parts moves the derivative from ηdot, leaving a boundary term that vanishes under fixed endpoints. Arbitrary interior η forces the displayed equation.

$$
\frac d{dt}\frac{\partial L}{\partial\dot q}-\frac{\partial L}{\partial q}=0
$$

## Assumptions

- Variations vanish at fixed endpoints; L and q have required regularity.

## Worked check

L=m qdot²/2−kq²/2 gives mqddot+kq=0.

## Limits

- Stationarity can be a maximum or saddle; constraints and free endpoints generate additional conditions.

## Connections

- prerequisite_of (incoming): [[public--m-variation]]
- prerequisite_of (incoming): [[public--m-chain]]
- prerequisite_of (incoming): [[public--m-integral]]

## Sources

- [The Lagrangian Formalism, David Tong](https://davidtong.org/pdfs/teaching/classical-dynamics/clas2.pdf) — 35-page PDF; fixed-endpoint variation and equations 2.4–2.8 inspected

Evidence links and mathematical analogies do not grant tool permissions.
