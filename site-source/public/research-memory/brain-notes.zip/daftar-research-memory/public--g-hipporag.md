---
id: "g-hipporag"
domain: "memory"
status: "representative-frontier"
scope: "public"
tags: [daftar, research-memory]
---

# HippoRAG associative retrieval

Personalized diffusion retrieves connected passages seeded by the question; the atlas uses a smaller deterministic graph baseline.

## Connections

- prerequisite_of (incoming): [[public--g-pagerank]]

## Sources

- [From RAG to Memory: Non-Parametric Continual Learning for Large Language Models](https://arxiv.org/html/2502.14802v2) — selected-methods-and-limitations

Evidence links and mathematical analogies do not grant tool permissions.
