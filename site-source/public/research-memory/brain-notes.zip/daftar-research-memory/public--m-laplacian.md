---
id: "m-laplacian"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Graph Laplacians

A Laplacian is a positive semidefinite quadratic energy on an undirected weighted graph.

## Connections

- prerequisite_of (incoming): [[public--m-incidence]]
- prerequisite_of (outgoing): [[public--m-resistance]]
- prerequisite_of (outgoing): [[public--m-spectral]]
- related (incoming): [[public--m-spectral]]
- related (outgoing): [[public--m-heat]]
- prerequisite_of (outgoing): [[public--mf-normalized]]
- prerequisite_of (outgoing): [[public--mf-resistance]]
- prerequisite_of (outgoing): [[public--mf-cheeger]]
- prerequisite_of (outgoing): [[public--mf-diffusion]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
