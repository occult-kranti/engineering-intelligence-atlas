---
id: "gf-hopfield-energy"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Binary Hopfield Lyapunov function

If only state i changes, ΔE=-(s_i'−s_i)(Σ_j W_ij s_j−θ_i). Choosing the state aligned with the field makes this nonpositive.

$$
E(s)=-\frac12s^TWs+\theta^Ts
$$

## Assumptions

- W=Wᵀ and diagonal zero.
- Asynchronous single-unit updates align with the local field.

## Worked check

Two positively coupled units lower this function by agreeing rather than disagreeing, for zero thresholds.

## Limits

- Synchronous updates can oscillate. The function is not automatically a joule-valued physical energy.

## Connections

- prerequisite_of (incoming): [[public--g-hebb]]
- prerequisite_of (incoming): [[public--g-hopfield]]

## Sources

- [Neural networks and physical systems with emergent collective computational abilities](https://pmc.ncbi.nlm.nih.gov/articles/PMC346238/) — abstract-and-original-paper-discovery

Evidence links and mathematical analogies do not grant tool permissions.
