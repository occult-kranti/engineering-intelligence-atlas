---
id: "g-questions"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Question-led knowledge growth

Store what would change the conclusion, prerequisites for answering it, and the next decisive source or experiment.

## Connections

- prerequisite_of (incoming): [[public--g-status]]
- prerequisite_of (incoming): [[public--g-reviews]]
- prerequisite_of (outgoing): [[public--g-loop]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
