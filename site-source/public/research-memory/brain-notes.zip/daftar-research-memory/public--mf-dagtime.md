---
id: "mf-dagtime"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Critical path in a dependency DAG

A task cannot start before the slowest predecessor finishes. Add its own duration and compute in topological order. The maximum completion among terminal tasks is a lower bound for schedules with limited workers.

$$
T(v)=c(v)+\max_{u\to v}T(u)
$$

## Assumptions

- Finite DAG; tasks wait for all predecessors; independent tasks can run concurrently without resource contention.
- Use maximum of an empty predecessor set as0.

## Worked check

Two independent tasks lasting 2 and 5 followed by a3-unit merge need 8 units, even though total work is10.

## Limits

- Limited agents, locks, API quotas and shared hardware can make the actual schedule longer; this bound is not a cost or runtime guarantee.

## Connections

- prerequisite_of (incoming): [[public--m-dag]]
- prerequisite_of (incoming): [[public--m-shortest]]

## Sources

- [Algorithms, chapter 8: Shortest Paths, Jeff Erickson](https://jeffe.cs.illinois.edu/teaching/algorithms/book/08-sssp.pdf) — 36-page chapter; relaxation, negative cycles and Bellman-Ford section inspected

Evidence links and mathematical analogies do not grant tool permissions.
