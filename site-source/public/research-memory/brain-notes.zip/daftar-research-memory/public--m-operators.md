---
id: "m-operators"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Bounded and unbounded operators

An unbounded operator is specified by its domain as well as its algebraic expression.

## Connections

- prerequisite_of (incoming): [[public--m-functional]]
- prerequisite_of (outgoing): [[public--m-sobolev]]
- prerequisite_of (outgoing): [[public--m-ai-ymexistence]]
- prerequisite_of (outgoing): [[public--m-ai-ymgap]]
- prerequisite_of (outgoing): [[public--mf-heatkernel]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected
- [NIST DLMF 25.2: Definition and Expansions of the Riemann zeta function](https://dlmf.nist.gov/25.2) — definition and convergence domain inspected
- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
