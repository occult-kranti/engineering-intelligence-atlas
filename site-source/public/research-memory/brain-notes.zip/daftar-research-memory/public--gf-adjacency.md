---
id: "gf-adjacency"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Adjacency and weighted degree

Place each edge weight at its row and column. Summing a row counts outgoing weight; this is bookkeeping, not an inferred relationship.

$$
A_{ij}=w_{ij},\qquad d_i=\sum_j A_{ij},\qquad D=\operatorname{diag}(d_i)
$$

## Assumptions

- Declare whether rows encode outgoing edges.
- Weights are nonnegative for a random-walk interpretation.

## Worked check

A unit-weight path of three vertices has degrees (1,2,1) when represented as an undirected graph.

## Limits

- A directed graph generally has different incoming and outgoing degree.

## Connections

- prerequisite_of (incoming): [[public--g-graph]]
- prerequisite_of (incoming): [[public--g-edge]]

## Sources

- [The PageRank Citation Ranking: Bringing Order to the Web](https://ilpubs.stanford.edu/422/) — original-report-discovery

Evidence links and mathematical analogies do not grant tool permissions.
