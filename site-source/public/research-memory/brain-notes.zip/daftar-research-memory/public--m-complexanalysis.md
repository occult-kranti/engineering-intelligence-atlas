---
id: "m-complexanalysis"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Holomorphic functions

Complex differentiability imposes stronger constraints than real differentiability.

## Connections

- prerequisite_of (incoming): [[public--m-complex]]
- prerequisite_of (outgoing): [[public--m-zeta]]
- prerequisite_of (outgoing): [[public--m-ai-zeta]]
- prerequisite_of (outgoing): [[public--mf-cauchy]]
- prerequisite_of (outgoing): [[public--mf-zeta]]

## Sources

- [Cauchy's Integral Formula and Power and Laurent Series Expansion, Yum-Tong Siu](https://people.math.harvard.edu/~siu/math113/5_cauchy_integral_formula_power_and_laurent_series_expansion.pdf) — nine-page PDF, statement and initial proof inspected

Evidence links and mathematical analogies do not grant tool permissions.
