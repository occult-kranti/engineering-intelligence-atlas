---
id: "gf-bfs"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Traversal complexity

Each vertex enters the queue once and each relevant adjacency is examined a bounded number of times.

$$
T_{\rm BFS}=O(|V_r|+|E_r|),\qquad M=O(|V_r|)
$$

## Assumptions

- Adjacency lists and a visited set.
- Constant-time set operations are an average-case assumption.

## Worked check

In a cycle A→B→C→A, the visited set stops the fourth enqueue of A.

## Limits

- Building the eligible subgraph and adjacency has its own whole-graph cost; report that in end-to-end benchmarks.

## Connections

- prerequisite_of (incoming): [[public--g-bfs]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
