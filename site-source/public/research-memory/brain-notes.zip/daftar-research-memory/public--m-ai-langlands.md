---
id: "m-ai-langlands"
domain: "mathematics"
status: "project_scope_and_part_one_abstract_read"
scope: "public"
tags: [daftar, research-memory]
---

# Categorical unramified geometric Langlands project

A five-paper project proves the categorical unramified geometric Langlands conjecture in its stated setting.

## Connections

- prerequisite_of (incoming): [[public--m-schemes]]
- prerequisite_of (incoming): [[public--m-category]]
- prerequisite_of (incoming): [[public--m-representations]]

## Sources

- [Proof of the geometric Langlands conjecture: five-paper project](https://people.mpim-bonn.mpg.de/gaitsgde/GLC/) — authors' project page inspected
- [Proof of the geometric Langlands conjecture I: construction of the functor](https://arxiv.org/abs/2405.03599v3) — abstract and version history inspected

Evidence links and mathematical analogies do not grant tool permissions.
