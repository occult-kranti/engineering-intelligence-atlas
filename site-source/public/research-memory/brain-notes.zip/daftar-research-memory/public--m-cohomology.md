---
id: "m-cohomology"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Cohomology and dual observables

Cohomology evaluates and combines global information carried by local data.

## Connections

- prerequisite_of (incoming): [[public--m-homology]]
- prerequisite_of (outgoing): [[public--m-hodge]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
