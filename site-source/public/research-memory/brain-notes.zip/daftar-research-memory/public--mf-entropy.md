---
id: "mf-entropy"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Shannon entropy

The information of an outcome with probability p is −log₂p. Averaging this value gives entropy. Concavity implies a uniform distribution on N outcomes has maximal entropy log₂N, while a certain outcome has entropy zero.

$$
H(X)=-\sum_xp(x)\log_2p(x)
$$

## Assumptions

- A discrete probability distribution is specified; define 0 log 0=0 by continuity.

## Worked check

A fair bit has entropy 1 bit. A deterministic duplicated bit adds no conditional entropy once the original is known.

## Limits

- Differential entropy for continuous variables is coordinate-dependent and can be negative; it is not the same object.

## Connections

- prerequisite_of (incoming): [[public--m-probability]]
- prerequisite_of (incoming): [[public--m-logarithms]]

## Sources

- [A Mathematical Theory of Communication, Claude Shannon](https://people.math.harvard.edu/~ctm/home/text/others/shannon/entropy/entropy.pdf) — PDF introduction and information definitions inspected
- [Entropy, Relative Entropy, and Mutual Information, Tsachy Weissman](https://web.stanford.edu/class/ee376a/files/lecture_3.pdf) — five-page PDF; definitions and nonnegativity argument inspected

Evidence links and mathematical analogies do not grant tool permissions.
