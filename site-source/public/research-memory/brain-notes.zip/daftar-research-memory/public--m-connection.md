---
id: "m-connection"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Connections and covariant derivatives

A connection compares vectors at nearby points; coordinate derivatives alone do not transform correctly.

## Connections

- prerequisite_of (incoming): [[public--m-lie]]
- prerequisite_of (outgoing): [[public--m-curvature]]
- prerequisite_of (incoming): [[public--m-metric]]
- prerequisite_of (outgoing): [[public--mf-curvature]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
