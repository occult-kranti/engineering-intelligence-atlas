---
id: "mf-pca"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Centered covariance and PCA

Variance in a unit direction v is ||Xv||²/(N−1)=vᵀCv. Maximizing this under vᵀv=1 yields Cv=λv. Orthogonal subsequent maximizations choose the remaining eigenvectors, giving a rank-k reconstruction with maximum retained variance.

$$
C=\frac{X^TX}{N-1},\quad Cv_i=\lambda_i v_i
$$

## Assumptions

- N>1 and columns are centered.
- Scaling is declared when features have different units.

## Worked check

For centered points (−1,0),(0,0),(1,0), C=diag(1,0). One component preserves all sample variance.

## Limits

- High variance can be noise or confounding. PCA compresses second-order structure, not all task-relevant information.

## Connections

- prerequisite_of (incoming): [[public--m-spectral]]
- prerequisite_of (incoming): [[public--m-svd]]
- prerequisite_of (incoming): [[public--m-covariance]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
