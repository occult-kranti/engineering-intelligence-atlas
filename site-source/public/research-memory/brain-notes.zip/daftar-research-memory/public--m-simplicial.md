---
id: "m-simplicial"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Simplicial and cell complexes

Higher-dimensional cells fill some graph cycles, changing which loops represent holes.

## Connections

- prerequisite_of (incoming): [[public--m-homotopy]]
- prerequisite_of (outgoing): [[public--m-homology]]
- prerequisite_of (outgoing): [[public--mf-homology]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
