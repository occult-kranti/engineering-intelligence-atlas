---
id: "m-jacobian"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Jacobians and changes of variables

The determinant of a coordinate derivative converts local volume elements.

## Connections

- prerequisite_of (incoming): [[public--m-integral]]
- prerequisite_of (outgoing): [[public--m-divergence]]
- prerequisite_of (outgoing): [[public--mf-div]]
- prerequisite_of (outgoing): [[public--mf-gauss]]
- prerequisite_of (outgoing): [[public--mf-laplacebeltrami]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
