---
id: "m-taylor"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Taylor approximation and remainder

A polynomial approximation becomes informative only with a bound on its remainder.

## Connections

- prerequisite_of (incoming): [[public--m-derivative]]
- prerequisite_of (outgoing): [[public--m-rootfinding]]
- prerequisite_of (outgoing): [[public--m-finitedifference]]
- prerequisite_of (outgoing): [[public--mf-newton]]
- prerequisite_of (outgoing): [[public--mf-difference]]
- prerequisite_of (outgoing): [[public--mf-simpson]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
