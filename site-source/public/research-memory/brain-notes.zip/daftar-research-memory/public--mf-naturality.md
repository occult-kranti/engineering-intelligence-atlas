---
id: "mf-naturality"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Naturality square

A family of component maps is coherent only if converting before or after applying any source morphism gives the same result. This equation makes that requirement explicit and prevents arbitrary object-by-object correspondences from masquerading as a structure-preserving transformation.

$$
G(f)\circ\eta_X=\eta_Y\circ F(f)
$$

## Assumptions

- Composition domains and codomains agree for every f.

## Worked check

Double-dual evaluation maps on finite-dimensional vector spaces commute with every linear map, giving a natural transformation to the double-dual functor.

## Limits

- A diagram that merely looks symmetric does not establish naturality; every relevant morphism must satisfy the condition.

## Connections

- prerequisite_of (incoming): [[public--m-category]]
- prerequisite_of (incoming): [[public--m-functor]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected

Evidence links and mathematical analogies do not grant tool permissions.
