---
id: "mf-cg"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Conjugate-gradient condition-number bound

CG minimizes the energy error over a Krylov subspace. Its error is a polynomial in A applied to the initial error, constrained to equal one at zero. A scaled Chebyshev polynomial controls that polynomial over the eigenvalue interval and gives the bound.

$$
\|e_k\|_A\le2\left(\frac{\sqrt\kappa-1}{\sqrt\kappa+1}\right)^k\|e_0\|_A
$$

## Assumptions

- Exact arithmetic and standard CG on SPD A.
- The A-norm is sqrt(eᵀAe).

## Worked check

With κ=9 the ratio is (3−1)/(3+1)=1/2; the bound is 2·2⁻ᵏ times initial A-error.

## Limits

- Finite precision and indefinite or nonsymmetric matrices require separate methods or analysis; preconditioners must preserve the chosen solver's assumptions.

## Connections

- prerequisite_of (incoming): [[public--m-conditioning]]
- prerequisite_of (incoming): [[public--m-spectral]]
- prerequisite_of (incoming): [[public--m-cg]]

## Sources

- [An Introduction to the Conjugate Gradient Method Without the Agonizing Pain, Jonathan Shewchuk](https://www.cs.cmu.edu/afs/cs/Web/People/quake-papers/painless-conjugate-gradient.pdf) — PDF scope and rendered printed page 36, equation 52, inspected

Evidence links and mathematical analogies do not grant tool permissions.
