---
id: "m-fixedpoint"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Contractions and fixed points

A contraction supplies existence, uniqueness and a quantitative stopping certificate.

## Connections

- prerequisite_of (incoming): [[public--m-rootfinding]]
- prerequisite_of (outgoing): [[public--mf-pagerank]]
- prerequisite_of (outgoing): [[public--mf-contraction]]
- prerequisite_of (outgoing): [[public--g-pagerank]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
