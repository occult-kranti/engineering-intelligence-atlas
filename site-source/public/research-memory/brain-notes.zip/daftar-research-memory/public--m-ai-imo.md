---
id: "m-ai-imo"
domain: "ai-mathematics"
status: "benchmark_result_with_bounded_scope"
scope: "public"
tags: [daftar, research-memory]
---

# Gemini Deep Think: IMO 2025 gold-standard performance

Five of six competition problems, 35 points, reported gold-medal standard.

## Connections

- prerequisite_of (incoming): [[public--m-proof]]
- prerequisite_of (incoming): [[public--m-combinatorics]]

## Sources

- [Gemini Deep Think IMO 2025 gold-medal-standard result](https://deepmind.google/blog/advanced-version-of-gemini-with-deep-think-officially-achieves-gold-medal-standard-at-the-international-mathematical-olympiad/) — announcement and score inspected

Evidence links and mathematical analogies do not grant tool permissions.
