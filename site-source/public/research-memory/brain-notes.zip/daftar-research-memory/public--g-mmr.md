---
id: "g-mmr"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Diversity-aware selection

Balance query relevance against repetition; this is an optimization choice whose effects need a task benchmark.

## Connections

- prerequisite_of (outgoing): [[public--gf-mmr]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
