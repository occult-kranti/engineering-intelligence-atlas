---
id: "m-stokes"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Stokes theorem

The differential-form theorem unifies several boundary-to-interior identities.

## Connections

- related (outgoing): [[public--m-curvature]]
- prerequisite_of (outgoing): [[public--mf-cauchy]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
