---
id: "g-donna"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Donna evidence handoff

Give the assistant a bounded public evidence packet alongside separately authorized company knowledge. Do not infer a new access grant.

## Connections

- prerequisite_of (incoming): [[public--g-skills]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
