---
id: "m-yoneda"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Yoneda and representability

An object is characterized, up to isomorphism, by its relationships expressed through hom-functors.

## Connections

- prerequisite_of (incoming): [[public--m-universal]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
