---
id: "m-homology"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Homology and boundary maps

Cycles modulo boundaries distinguish persistent holes from locally filled cycles.

## Connections

- prerequisite_of (incoming): [[public--m-simplicial]]
- prerequisite_of (outgoing): [[public--m-cohomology]]
- prerequisite_of (outgoing): [[public--m-persistent]]
- prerequisite_of (outgoing): [[public--mf-eulerchar]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
