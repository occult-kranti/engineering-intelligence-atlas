---
id: "m-spectral"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Eigenvalues and spectral theorem

Self-adjoint operators have orthogonal modes; arbitrary matrices need not diagonalize.

## Connections

- prerequisite_of (incoming): [[public--m-inner]]
- prerequisite_of (outgoing): [[public--m-svd]]
- prerequisite_of (incoming): [[public--m-laplacian]]
- prerequisite_of (outgoing): [[public--m-graphdiffusion]]
- related (outgoing): [[public--m-laplacian]]
- prerequisite_of (outgoing): [[public--mf-spectral]]
- prerequisite_of (outgoing): [[public--mf-svd]]
- prerequisite_of (outgoing): [[public--mf-pca]]
- prerequisite_of (outgoing): [[public--mf-markov]]
- prerequisite_of (outgoing): [[public--mf-normalized]]
- prerequisite_of (outgoing): [[public--mf-cheeger]]
- prerequisite_of (outgoing): [[public--mf-diffusion]]
- prerequisite_of (outgoing): [[public--mf-cg]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
