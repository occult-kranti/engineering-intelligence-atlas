---
id: "g-compression"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Lossy summary compression

Summaries discard detail; preserve originals by pointer and maintain the ability to reopen source sections.

## Connections

- prerequisite_of (incoming): [[public--g-semantic]]
- prerequisite_of (incoming): [[public--g-entropy]]

## Sources

- [From Local to Global: A Graph RAG Approach to Query-Focused Summarization](https://arxiv.org/abs/2404.16130) — abstract-and-official-publication

Evidence links and mathematical analogies do not grant tool permissions.
