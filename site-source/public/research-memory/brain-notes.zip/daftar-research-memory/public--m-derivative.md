---
id: "m-derivative"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Derivatives and linearization

The derivative is the local best linear approximation where it exists.

## Connections

- prerequisite_of (incoming): [[public--m-limits]]
- prerequisite_of (outgoing): [[public--m-taylor]]
- prerequisite_of (outgoing): [[public--m-chain]]
- prerequisite_of (outgoing): [[public--mf-taylor]]
- prerequisite_of (outgoing): [[public--mf-chain]]
- prerequisite_of (outgoing): [[public--mf-ftc]]
- prerequisite_of (outgoing): [[public--mf-newton]]
- prerequisite_of (outgoing): [[public--mf-wave]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
