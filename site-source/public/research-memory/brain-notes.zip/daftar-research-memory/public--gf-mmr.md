---
id: "gf-mmr"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Relevance and redundancy tradeoff

A greedy step rewards query relevance and penalizes similarity to selected evidence. This defines an engineering policy rather than a general optimum.

$$
d_* =\arg\max_{d\notin S}\left[\lambda\,r(q,d)-(1-\lambda)\max_{s\in S}\operatorname{sim}(d,s)\right]
$$

## Assumptions

- Comparable, bounded relevance and similarity scales.
- 0≤λ≤1.

## Worked check

At λ=0.7, relevance 0.9 and maximum redundancy 0.8 give 0.63-0.24=0.39.

## Limits

- Not implemented in the initial retrieval core; retained as an evaluable extension.

## Connections

- prerequisite_of (incoming): [[public--g-rrf]]
- prerequisite_of (incoming): [[public--g-mmr]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
