---
id: "mf-kl"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Relative entropy

Apply convexity of −log to q/p under p, or use log t≤t−1. Equality holds only when the distributions agree on the relevant support. Its asymmetry follows because changing the averaging distribution changes the expression.

$$
D_{KL}(p\|q)=\sum_xp(x)\log\frac{p(x)}{q(x)}\ge0
$$

## Assumptions

- q(x)>0 wherever p(x)>0 for a finite value.

## Worked check

For p=(1,0), q=(1/2,1/2), divergence is log2; reversing them makes the value infinite.

## Limits

- KL is not a metric: it is asymmetric and does not satisfy a triangle inequality.

## Connections

- prerequisite_of (incoming): [[public--m-entropy]]
- prerequisite_of (incoming): [[public--m-probability]]

## Sources

- [Entropy, Relative Entropy, and Mutual Information, Tsachy Weissman](https://web.stanford.edu/class/ee376a/files/lecture_3.pdf) — five-page PDF; definitions and nonnegativity argument inspected

Evidence links and mathematical analogies do not grant tool permissions.
