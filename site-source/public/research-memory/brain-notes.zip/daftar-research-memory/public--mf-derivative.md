---
id: "mf-derivative"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Derivative as a controlled limit

The finite quotient measures a secant slope. A derivative exists when these slopes approach the same value from all allowed directions. The defining remainder is f(x+h)=f(x)+f′(x)h+o(h), making the linear approximation's error small relative to h.

$$
f'(x)=\lim_{h\to0}\frac{f(x+h)-f(x)}h
$$

## Assumptions

- The two-sided limit exists for an interior real point.

## Worked check

For f(x)=x², the quotient is 2x+h and the limit is 2x. For |x| at zero the one-sided quotients differ, so no derivative exists.

## Limits

- A small finite-difference residual is not a proof of differentiability; numerical subtraction can also destroy small increments.

## Connections

- prerequisite_of (incoming): [[public--m-limits]]
- prerequisite_of (incoming): [[public--m-equations]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
