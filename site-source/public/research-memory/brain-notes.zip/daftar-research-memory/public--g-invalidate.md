---
id: "g-invalidate"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Dependency invalidation

Include every semantically relevant dependency in the key, including source-only changes and policy versions.

## Connections

- prerequisite_of (incoming): [[public--g-interval]]
- prerequisite_of (outgoing): [[public--g-cache]]
- prerequisite_of (outgoing): [[public--gf-cache-key]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
