---
id: "gf-ppr-error"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# PageRank residual bound

The future increments are bounded by a geometric sequence. Sum their norms to bound the distance from the current iterate to the limit.

$$
\lVert p_t-p_*\rVert_1\leq\frac{\lVert p_{t+1}-p_t\rVert_1}{1-\alpha}
$$

## Assumptions

- Stochastic transition with 0≤α<1.

## Worked check

At α=0.85 and residual 10^-10, this bound is at most 6.67×10^-10.

## Limits

- An iteration cap can stop before this bound is small; record residual and iteration count.

## Connections

- prerequisite_of (incoming): [[public--g-pagerank]]
- prerequisite_of (incoming): [[public--g-convergence]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
