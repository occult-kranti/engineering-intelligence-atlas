---
id: "m-sobolev"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Sobolev spaces and weak derivatives

Weak derivatives extend differential equations to functions without classical smoothness.

## Connections

- prerequisite_of (incoming): [[public--m-operators]]
- prerequisite_of (outgoing): [[public--m-pde]]
- prerequisite_of (outgoing): [[public--m-ai-nsforced]]
- prerequisite_of (outgoing): [[public--m-ai-smoothing]]
- prerequisite_of (outgoing): [[public--m-ai-unforcedns]]
- prerequisite_of (outgoing): [[public--mf-weakpoisson]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
