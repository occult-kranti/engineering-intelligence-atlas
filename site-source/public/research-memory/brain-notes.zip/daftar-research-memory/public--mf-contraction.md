---
id: "mf-contraction"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Fixed-point convergence and stopping bound

Successive differences shrink geometrically. The tail distance from x_k to the limiting fixed point is bounded by the geometric sum of future differences, giving q/(1−q) times the last difference. Completeness places the limit inside the space, and contraction proves uniqueness.

$$
\|T(x)-T(y)\|\le q\|x-y\|,\ q<1,\quad \|x_k-x_*\|\le\frac{q}{1-q}\|x_k-x_{k-1}\|
$$

## Assumptions

- T maps a nonempty complete space to itself and has a global contraction factor q in [0,1).

## Worked check

For T(x)=0.5x+1, the unique fixed point is 2 and the last-step error bound equals the size of the previous change.

## Limits

- Empirical stability over a few steps does not prove contraction; a budget stop is not a convergence certificate.

## Connections

- prerequisite_of (incoming): [[public--m-limits]]
- prerequisite_of (incoming): [[public--m-fixedpoint]]

## Sources

- [The Contraction Mapping Theorem, Hunter and Nachtergaele](https://www.math.ucdavis.edu/~hunter/book/ch3.pdf) — 19-page PDF; screenshot of printed page 59, Theorem 3.2, directly inspected because text extraction is garbled

Evidence links and mathematical analogies do not grant tool permissions.
