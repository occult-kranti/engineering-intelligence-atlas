---
id: "mf-normalized"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Normalized Laplacian

Change variables x=D⁻¹/²y in the unnormalized quadratic form. Degree normalization compensates for different total incident weights. Its spectrum lies in [0,2], linking random-walk mixing with normalized cuts.

$$
\mathcal L=I-D^{-1/2}WD^{-1/2}
$$

## Assumptions

- Undirected nonnegative graph with no isolated vertices, or an explicit isolated-vertex convention.

## Worked check

For a single edge connecting two vertices, ℒ=[[1,−1],[−1,1]], with eigenvalues 0 and 2.

## Limits

- Normalization changes which notions of smoothness and importance are emphasized; it is not universally preferable.

## Connections

- prerequisite_of (incoming): [[public--m-laplacian]]
- prerequisite_of (incoming): [[public--m-spectral]]

## Sources

- [Conductance, the Normalized Laplacian, and Cheeger's Inequality, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect11-18.pdf) — nine-page PDF; definitions, equation 11.2 and two-sided bound inspected

Evidence links and mathematical analogies do not grant tool permissions.
