---
id: "m-regularization"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Regularization and inverse problems

A penalty stabilizes solutions by introducing a modeling preference.

## Connections

- prerequisite_of (incoming): [[public--m-pseudoinverse]]
- related (incoming): [[public--m-conditioning]]
- prerequisite_of (outgoing): [[public--mf-tikhonov]]

## Sources

- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out
- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
