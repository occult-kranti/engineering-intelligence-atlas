---
id: "g-episodic"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Episodic memory

In software, an episode can be an immutable observation or completed action; the biological notion involves richer behavioral and neural phenomena.

## Connections

- prerequisite_of (outgoing): [[public--g-semantic]]

## Sources

- [What Learning Systems do Intelligent Agents Need? Complementary Learning Systems Theory Updated](https://web.stanford.edu/~jlmcc/papers/KumaranHassabisMcClelland16FinalMS.pdf) — abstract-and-author-manuscript-discovery

Evidence links and mathematical analogies do not grant tool permissions.
