---
id: "g-edge"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Typed directed relations

requires, supports, contradicts, derived_from, implements, and analogy have different semantics. Preserve direction and evidence.

## Connections

- prerequisite_of (incoming): [[public--g-node]]
- prerequisite_of (outgoing): [[public--g-backlink]]
- prerequisite_of (outgoing): [[public--gf-adjacency]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
