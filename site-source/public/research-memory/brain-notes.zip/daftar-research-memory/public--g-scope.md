---
id: "g-scope"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Scope-first retrieval

Select authorized observations before computing lexical statistics, graph propagation, and cache keys. The caller owns authentication.

## Connections

- prerequisite_of (outgoing): [[public--g-time]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
