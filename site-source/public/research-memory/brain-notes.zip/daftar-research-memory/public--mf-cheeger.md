---
id: "mf-cheeger"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Cheeger inequality for an undirected weighted graph

Testing the Rayleigh quotient on a centered cut indicator gives the lower relation. Sweeping a second eigenvector and integrating threshold-cut contributions yields a cut with conductance bounded by the square root expression. The two sides connect discrete bottlenecks with continuous energy.

$$
\frac{\lambda_2(\mathcal L)}2\le\phi(G)\le\sqrt{2\lambda_2(\mathcal L)}
$$

## Assumptions

- Finite connected undirected graph with nonnegative weights; conductance uses weighted volume.

## Worked check

A graph connected by one very weak bridge has a low-conductance cut and small λ₂, so mixing across the bridge is slow.

## Limits

- The square-root gap is real; a spectral heuristic is an approximation, not an exact minimum-cut certificate.

## Connections

- prerequisite_of (incoming): [[public--m-normalized]]
- prerequisite_of (incoming): [[public--m-laplacian]]
- prerequisite_of (incoming): [[public--m-spectral]]

## Sources

- [Conductance, the Normalized Laplacian, and Cheeger's Inequality, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect11-18.pdf) — nine-page PDF; definitions, equation 11.2 and two-sided bound inspected

Evidence links and mathematical analogies do not grant tool permissions.
