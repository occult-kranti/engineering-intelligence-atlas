---
id: "m-graph"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Graphs, multigraphs and typed edges

Edge direction and type are part of the model; spatial proximity is not an edge.

## Connections

- prerequisite_of (incoming): [[public--m-sets]]
- prerequisite_of (outgoing): [[public--m-adjacency]]
- prerequisite_of (outgoing): [[public--m-shortest]]
- prerequisite_of (outgoing): [[public--m-ai-unitdistance]]
- prerequisite_of (outgoing): [[public--m-ai-ten]]
- prerequisite_of (outgoing): [[public--m-ai-3sum]]
- prerequisite_of (outgoing): [[public--mf-bellman]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
