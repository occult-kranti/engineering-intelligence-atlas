---
id: "gf-rrf"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Weighted reciprocal rank fusion

Replace incomparable raw scores with reciprocal rank contributions, then sum channels. The implemented weights are 1 for lexical and 0.7 for graph, with c=60.

$$
R(d)=\sum_j\frac{w_j}{c+r_j(d)}
$$

## Assumptions

- Missing items contribute zero.
- Ranks start at one.

## Worked check

An item ranked first in both channels scores 1.7/61≈0.027869; this is a ranking score, not 2.79% confidence.

## Limits

- Weights need held-out evaluation; a dense graph can still introduce irrelevant linked items.

## Connections

- prerequisite_of (incoming): [[public--g-bm25]]
- prerequisite_of (incoming): [[public--g-pagerank]]

## Sources

- [Reciprocal Rank Fusion outperforms Condorcet and individual Rank Learning Methods](https://cormack.uwaterloo.ca/cormack/cormacksigir09-rrf.pdf) — original-paper-selected-sections

Evidence links and mathematical analogies do not grant tool permissions.
