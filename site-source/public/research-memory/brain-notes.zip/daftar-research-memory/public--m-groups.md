---
id: "m-groups"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Groups and symmetry

A group records reversible composition, identity and inverses without assuming commutativity.

## Connections

- prerequisite_of (incoming): [[public--m-sets]]
- prerequisite_of (outgoing): [[public--m-rings]]
- prerequisite_of (outgoing): [[public--m-representations]]
- prerequisite_of (outgoing): [[public--mf-representation]]
- prerequisite_of (outgoing): [[public--mf-galois]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
