---
id: "mf-least"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Least squares normal equations

Expand the quadratic and differentiate: ∇f=2Aᵀ(Ax−b). Stationarity means the residual is orthogonal to every column of A. With full column rank the Hessian 2AᵀA is positive definite, so the stationary point is the unique global minimizer.

$$
\min_x\|Ax-b\|_2^2\Rightarrow A^TAx=A^Tb
$$

## Assumptions

- Real finite matrix; full column rank is needed for a unique unconstrained solution.

## Worked check

Fit one constant x to observations 1,2,6. A is a column of ones and the equation is 3x=9, so x=3.

## Limits

- Computing normal equations squares the condition number. QR or SVD is often numerically preferable.

## Connections

- prerequisite_of (incoming): [[public--m-gradient]]
- prerequisite_of (incoming): [[public--m-leastsquares]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
