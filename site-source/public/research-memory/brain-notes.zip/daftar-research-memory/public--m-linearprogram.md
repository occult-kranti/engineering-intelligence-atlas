---
id: "m-linearprogram"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Linear programming

LP optimality and algorithmic complexity are separate properties.

## Connections

- prerequisite_of (incoming): [[public--m-duality]]
- prerequisite_of (outgoing): [[public--m-ai-oai-newnine]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
