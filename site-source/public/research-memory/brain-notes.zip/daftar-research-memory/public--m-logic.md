---
id: "m-logic"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Propositions and quantifiers

A quantifier fixes the universe and the order in which choices may depend on one another.

## Connections

- prerequisite_of (outgoing): [[public--m-sets]]
- prerequisite_of (outgoing): [[public--m-induction]]
- prerequisite_of (outgoing): [[public--m-ai-universal]]

## Sources

- [Theorem Proving in Lean 4: Axioms and Computation](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/) — chapter inspected

Evidence links and mathematical analogies do not grant tool permissions.
