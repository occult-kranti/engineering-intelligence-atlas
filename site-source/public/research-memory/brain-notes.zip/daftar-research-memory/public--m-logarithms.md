---
id: "m-logarithms"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Exponentials and logarithms

Logarithms turn multiplication into addition only on the selected domain and branch.

## Connections

- prerequisite_of (outgoing): [[public--m-ai-claudeeth]]
- prerequisite_of (outgoing): [[public--mf-entropy]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
