---
id: "mf-jacobian"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Change of variables and volume

A small coordinate box is sent approximately to a parallelepiped whose volume is multiplied by |det Dφ|. Summing these local contributions and taking a limit produces the integral identity.

$$
\int_{\phi(U)}f(x)\,dx=\int_U f(\phi(u))|\det D\phi(u)|\,du
$$

## Assumptions

- φ is a sufficiently regular one-to-one coordinate map except possibly negligible sets.
- Multiplicity must be handled for many-to-one mappings.

## Worked check

In polar coordinates (r,θ)↦(r cosθ,r sinθ), determinant r yields disk area ∫₀²π∫₀ᴿ r dr dθ=πR².

## Limits

- Omitting the Jacobian corrupts densities and probabilities; a singular map cannot be inverted by this theorem.

## Connections

- prerequisite_of (incoming): [[public--m-determinant]]
- prerequisite_of (incoming): [[public--m-chain]]
- prerequisite_of (incoming): [[public--m-integral]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
