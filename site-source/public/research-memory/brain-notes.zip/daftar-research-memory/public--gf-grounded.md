---
id: "gf-grounded"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Grounded Poisson problem

Partition Lu=b into interior and boundary blocks; move the known boundary term to the right. The grounded interior operator is positive definite under the connectivity assumption.

$$
L_{II}u_I=b_I-L_{IB}u_B
$$

## Assumptions

- Every connected component of interior vertices reaches a fixed boundary.
- Boundary values and compatible source units are specified.

## Worked check

For a three-point path with endpoints 1 and 0 and no interior source, 2u_middle=1, so u_middle=0.5.

## Limits

- Without grounding or compatibility constraints, inversion is not unique or may be inconsistent.

## Connections

- prerequisite_of (incoming): [[public--g-dirichlet]]
- prerequisite_of (incoming): [[public--g-grounding]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
