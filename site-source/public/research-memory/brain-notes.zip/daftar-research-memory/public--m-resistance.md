---
id: "m-resistance"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Effective resistance

Resistance measures redundancy of paths under conductance assumptions.

## Connections

- prerequisite_of (incoming): [[public--m-laplacian]]
- related (incoming): [[public--m-inner]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
