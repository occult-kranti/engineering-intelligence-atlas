---
id: "mf-spectral"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Real symmetric spectral decomposition

A continuous Rayleigh quotient reaches an extremum on the unit sphere. Lagrange multipliers give an eigenvector at that extremum. Symmetry leaves its orthogonal complement invariant, so induction produces an orthonormal eigenbasis. Each mode then evolves independently under polynomials in A.

$$
A=Q\Lambda Q^T,\qquad Q^TQ=I
$$

## Assumptions

- A is real and symmetric.

## Worked check

For [[2,−1],[−1,2]], vectors (1,1)/√2 and (1,−1)/√2 have eigenvalues 1 and 3.

## Limits

- General real matrices can have complex eigenvalues or defective eigenspaces; the symmetric theorem cannot be assumed for directed adjacency matrices.

## Connections

- prerequisite_of (incoming): [[public--m-inner]]
- prerequisite_of (incoming): [[public--m-spectral]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
