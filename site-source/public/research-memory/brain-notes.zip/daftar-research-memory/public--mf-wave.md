---
id: "mf-wave"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Wave equation dispersion relation

Differentiate the plane wave twice in time to get −ω²u and apply the Laplacian to get −|k|²u. Matching coefficients gives the dispersion relation. Superposition holds because the equation is linear.

$$
u_{tt}=c^2\Delta u,\quad u=e^{i(k\cdot x-\omega t)}\Rightarrow\omega^2=c^2|k|^2
$$

## Assumptions

- Linear homogeneous isotropic nondispersive medium with constant c.

## Worked check

A one-dimensional mode with wavelength λ has |k|=2π/λ and ordinary frequency f=c/λ.

## Limits

- Material dispersion, nonlinearities and boundaries alter the relation or allowed modes; identical frequency does not imply identical physical channel.

## Connections

- prerequisite_of (incoming): [[public--m-fourier]]
- prerequisite_of (incoming): [[public--m-pde]]
- prerequisite_of (incoming): [[public--m-derivative]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
