---
id: "mf-cauchy"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Cauchy integral formula

Subtract f(z₀) from f(z) so the apparent singularity at z₀ is removable. The contour integral of the resulting holomorphic quotient vanishes. The remaining integral of 1/(z−z₀) is 2πi by one full winding.

$$
f(z_0)=\frac1{2\pi i}\oint_\gamma\frac{f(z)}{z-z_0}\,dz
$$

## Assumptions

- f is holomorphic on a neighborhood of the contour and its interior; z₀ lies inside.

## Worked check

For f(z)=z² and a unit circle centered at zero, the formula returns f(0)=0.

## Limits

- Poles inside the contour add residues; real differentiability alone is not sufficient.

## Connections

- prerequisite_of (incoming): [[public--m-complexanalysis]]
- prerequisite_of (incoming): [[public--m-integral]]
- prerequisite_of (incoming): [[public--m-stokes]]

## Sources

- [Cauchy's Integral Formula and Power and Laurent Series Expansion, Yum-Tong Siu](https://people.math.harvard.edu/~siu/math113/5_cauchy_integral_formula_power_and_laurent_series_expansion.pdf) — nine-page PDF, statement and initial proof inspected

Evidence links and mathematical analogies do not grant tool permissions.
