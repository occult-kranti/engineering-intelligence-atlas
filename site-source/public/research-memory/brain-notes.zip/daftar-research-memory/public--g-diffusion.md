---
id: "g-diffusion"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Heat diffusion on graphs

Matrix exponentials smooth an initial signal according to graph connectivity. Smoothing can erase distinctions that evidence needs.

## Connections

- prerequisite_of (incoming): [[public--g-laplacian]]
- prerequisite_of (outgoing): [[public--g-frequency-bridge]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
