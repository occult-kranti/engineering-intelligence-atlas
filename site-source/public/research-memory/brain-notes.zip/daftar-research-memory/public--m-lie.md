---
id: "m-lie"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Lie groups and Lie algebras

Infinitesimal generators organize local continuous symmetries and gauge theory.

## Connections

- prerequisite_of (incoming): [[public--m-representations]]
- prerequisite_of (outgoing): [[public--m-connection]]
- prerequisite_of (outgoing): [[public--m-ai-ymexistence]]
- prerequisite_of (outgoing): [[public--mf-curvature]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
