---
id: "mf-svd"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Singular value decomposition

The Hermitian positive semidefinite matrix A*A has an orthonormal eigenbasis. For every positive eigenvalue set u_i=Av_i/σ_i; these vectors are orthonormal. Extend the bases to account for left and right nullspaces. This yields rectangular diagonal Σ and the factorization.

$$
A=U\Sigma V^*,\qquad \sigma_i^2=\lambda_i(A^*A)
$$

## Assumptions

- A is a finite real or complex matrix; * is conjugate transpose.

## Worked check

A=diag(3,1) sends a unit circle to an ellipse with semiaxes 3 and 1; an added zero column supplies an invisible input direction.

## Limits

- SVD does not assign semantic meaning to its axes; signs and bases within repeated singular values are not unique.

## Connections

- prerequisite_of (incoming): [[public--m-spectral]]
- prerequisite_of (incoming): [[public--m-rank]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
