---
id: "mf-diffusion"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Heat diffusion on a graph

Diagonalize L and solve each scalar ODE c′_k=−λ_kc_k. Nonnegative eigenvalues ensure all nonconstant modes decay. The zero eigenmode preserves the component-wise mean under the unnormalized model.

$$
\dot x=-Lx,\quad x(t)=e^{-tL}x(0)=\sum_k e^{-t\lambda_k}\langle q_k,x(0)\rangle q_k
$$

## Assumptions

- Finite symmetric Laplacian; time and weights use compatible units.

## Worked check

For one unit edge, the difference x₁−x₂ decays as e⁻²ᵗ while the sum stays constant.

## Limits

- Diffusion smooths contradictions as readily as useful evidence unless edge types and conflict records are preserved.

## Connections

- prerequisite_of (incoming): [[public--m-laplacian]]
- prerequisite_of (incoming): [[public--m-spectral]]
- prerequisite_of (incoming): [[public--m-heat]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
