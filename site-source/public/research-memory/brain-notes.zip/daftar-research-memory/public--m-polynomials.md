---
id: "m-polynomials"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Polynomials and factorization

Polynomial structure permits identities, roots and exact arithmetic independent of floating-point approximations.

## Connections

- prerequisite_of (incoming): [[public--m-equations]]
- prerequisite_of (outgoing): [[public--m-complex]]
- prerequisite_of (outgoing): [[public--mf-quadratic]]
- prerequisite_of (outgoing): [[public--mf-binomial]]
- prerequisite_of (outgoing): [[public--mf-euler]]
- prerequisite_of (outgoing): [[public--mf-elliptic]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
