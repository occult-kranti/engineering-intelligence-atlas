---
id: "m-randomvariable"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Random variables and distributions

A random variable is a measurable function, not a sample or a probability density itself.

## Connections

- prerequisite_of (incoming): [[public--m-probability]]
- prerequisite_of (outgoing): [[public--m-bayes]]
- prerequisite_of (outgoing): [[public--m-covariance]]
- prerequisite_of (outgoing): [[public--mf-bayes]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
