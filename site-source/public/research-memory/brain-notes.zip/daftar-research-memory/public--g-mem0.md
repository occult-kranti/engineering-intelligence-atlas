---
id: "g-mem0"
domain: "memory"
status: "representative-frontier"
scope: "public"
tags: [daftar, research-memory]
---

# Mem0 consolidation

Study selective memory extraction with revision and benchmark controls; product claims require exact configurations.

## Connections

- related (incoming): [[public--g-time]]

## Sources

- [Mem0: Building Production-Ready AI Agents with Scalable Long-Term Memory](https://arxiv.org/abs/2504.19413) — abstract

Evidence links and mathematical analogies do not grant tool permissions.
