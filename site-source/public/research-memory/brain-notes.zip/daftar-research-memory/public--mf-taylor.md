---
id: "mf-taylor"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Taylor theorem with an explicit remainder

Repeated integration of the derivative, or the mean-value theorem applied to the error, isolates the next derivative. If its magnitude is bounded by M, the error is at most M|h|^(n+1)/(n+1)!. The bound, not just the polynomial, determines a safe approximation region.

$$
f(x+h)=\sum_{k=0}^{n}\frac{f^{(k)}(x)}{k!}h^k+\frac{f^{(n+1)}(\xi)}{(n+1)!}h^{n+1}
$$

## Assumptions

- Sufficient differentiability on the interval and continuity assumptions for the Lagrange remainder.

## Worked check

For exp(h) at zero with |h|≤0.1, 1+h+h²/2 has error at most exp(0.1)|h|³/6.

## Limits

- Smoothness alone does not guarantee equality to an infinite Taylor series; some smooth functions are not analytic.

## Connections

- prerequisite_of (incoming): [[public--m-derivative]]
- prerequisite_of (incoming): [[public--m-integral]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
