---
id: "mf-heatkernel"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Heat equation spectral solution

A spatial Fourier transform turns Δ into multiplication by −|k|². Each mode obeys an exponential-decay ODE. High-frequency modes decay faster, explaining smoothing and the instability of naively multiplying noisy late data by e^(κ|k|²t) to reverse time.

$$
\partial_tu=\kappa\Delta u,\quad\hat u(k,t)=e^{-\kappa|k|^2t}\hat u(k,0)
$$

## Assumptions

- Constant κ>0; whole-space or compatible Fourier basis boundary model.

## Worked check

On a periodic interval, initial sin(3x) evolves as e^(−9κt)sin(3x).

## Limits

- A forward heat semigroup is dissipative; numerical reversal is not a physical memory restoration mechanism.

## Connections

- prerequisite_of (incoming): [[public--m-fourier]]
- prerequisite_of (incoming): [[public--m-pde]]
- prerequisite_of (incoming): [[public--m-operators]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
