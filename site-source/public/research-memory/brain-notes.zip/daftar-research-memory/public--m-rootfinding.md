---
id: "m-rootfinding"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Root finding and Newton iteration

Newton is locally powerful but can diverge or converge to an unintended root.

## Connections

- prerequisite_of (incoming): [[public--m-taylor]]
- prerequisite_of (outgoing): [[public--m-fixedpoint]]
- prerequisite_of (outgoing): [[public--mf-newton]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
