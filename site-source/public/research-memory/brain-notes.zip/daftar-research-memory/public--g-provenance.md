---
id: "g-provenance"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Evidence provenance

Keep source URL, exact version, date, section, access depth, and claim relationship separate from a summary.

## Connections

- prerequisite_of (incoming): [[public--g-identity]]
- prerequisite_of (outgoing): [[public--g-status]]
- prerequisite_of (outgoing): [[public--g-hash]]
- prerequisite_of (outgoing): [[public--g-repos]]
- related (outgoing): [[public--g-reviews]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
