---
id: "g-walk"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Random walk transition

Normalize outgoing nonnegative weights. A vertex with no outgoing weight needs an explicit dangling-node rule.

## Connections

- prerequisite_of (incoming): [[public--g-adjacency]]
- prerequisite_of (outgoing): [[public--g-pagerank]]
- prerequisite_of (outgoing): [[public--gf-transition]]
- prerequisite_of (outgoing): [[public--gf-ppr]]

## Sources

- [The PageRank Citation Ranking: Bringing Order to the Web](https://ilpubs.stanford.edu/422/) — original-report-discovery

Evidence links and mathematical analogies do not grant tool permissions.
