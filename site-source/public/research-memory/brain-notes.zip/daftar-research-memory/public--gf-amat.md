---
id: "gf-amat"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Two-level average memory access time

Expand a decision tree: every request pays T1, m1 of requests pay T2, and m1m2 pay T3.

$$
T_{\rm avg}=T_1+m_1(T_2+m_2T_3)
$$

## Assumptions

- Each lower-tier cost is incurred only after an upper-tier miss.
- Use incremental costs, not complete inclusive timings.

## Worked check

T1=1, T2=10, T3=100, m1=0.1, m2=0.2 yield 4 time units.

## Limits

- Correlated workloads and overlapping asynchronous fetches require a different timing model.

## Connections

- prerequisite_of (incoming): [[public--g-cache]]
- prerequisite_of (incoming): [[public--g-memgpt]]

## Sources

- [Efficient stack distance computation for priority replacement policies](https://research.ibm.com/publications/efficient-stack-distance-computation-for-priority-replacement-policies) — author-institution-abstract

Evidence links and mathematical analogies do not grant tool permissions.
