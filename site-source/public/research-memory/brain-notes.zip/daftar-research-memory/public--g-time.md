---
id: "g-time"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Bitemporal evidence

Separate when a fact applied from when it was recorded. Corrections append evidence rather than silently rewriting history.

## Connections

- prerequisite_of (incoming): [[public--g-scope]]
- prerequisite_of (outgoing): [[public--g-interval]]
- prerequisite_of (outgoing): [[public--g-temporal-eval]]
- prerequisite_of (outgoing): [[public--g-graphiti]]
- related (outgoing): [[public--g-mem0]]
- prerequisite_of (outgoing): [[public--gf-ttl-probability]]

## Sources

- [Zep: A Temporal Knowledge Graph Architecture for Agent Memory](https://arxiv.org/html/2501.13956v1) — selected-methods

Evidence links and mathematical analogies do not grant tool permissions.
