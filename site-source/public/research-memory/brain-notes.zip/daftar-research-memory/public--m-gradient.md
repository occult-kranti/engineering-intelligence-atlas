---
id: "m-gradient"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Gradient, divergence and curl

These operators depend on geometry and encode local change, flux and circulation.

## Connections

- prerequisite_of (incoming): [[public--m-chain]]
- prerequisite_of (outgoing): [[public--m-variation]]
- prerequisite_of (outgoing): [[public--m-optimization]]
- prerequisite_of (outgoing): [[public--m-ai-euler]]
- prerequisite_of (outgoing): [[public--mf-least]]
- prerequisite_of (outgoing): [[public--mf-div]]
- prerequisite_of (outgoing): [[public--mf-gradient]]
- prerequisite_of (outgoing): [[public--mf-kkt]]
- prerequisite_of (outgoing): [[public--mf-laplacebeltrami]]
- prerequisite_of (outgoing): [[public--mf-elliptic]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
