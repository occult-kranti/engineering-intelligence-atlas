---
id: "gf-latency"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Expected local cache latency

Condition total expectation on the two disjoint cases. If miss cost is measured after lookup instead, add the lookup cost separately.

$$
\mathbb E[T]=hT_{\rm hit}+(1-h)T_{\rm miss}
$$

## Assumptions

- Hit and miss latencies include the same measurement boundaries.
- Workload hit fraction is representative.

## Worked check

With h=0.8, a 2 ms hit and a 40 ms complete miss, E[T]=9.6 ms.

## Limits

- Mean latency does not describe p95 or concurrent queueing. These numbers are an example, not a measured product result.

## Connections

- prerequisite_of (incoming): [[public--g-cache]]
- prerequisite_of (incoming): [[public--g-cost]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
