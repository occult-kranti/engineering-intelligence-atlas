---
id: "g-grounding"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Grounding and boundary conditions

Pin boundary values or impose a compatible gauge before inverting a singular Laplacian. Uniqueness depends on connectedness and boundary placement.

## Connections

- prerequisite_of (incoming): [[public--g-dirichlet]]
- prerequisite_of (outgoing): [[public--gf-grounded]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
