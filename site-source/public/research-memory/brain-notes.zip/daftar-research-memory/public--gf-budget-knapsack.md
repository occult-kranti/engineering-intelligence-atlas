---
id: "gf-budget-knapsack"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Evidence selection under a byte budget

A constrained subset problem formalizes why not every retrieved item fits. The implementation greedily tries ranked packets and checks actual UTF-8 bytes.

$$
\max_{z_i\in\{0,1\}}\sum_i u_i z_i\quad\text{s.t.}\quad\sum_i b_i z_i\le B
$$

## Assumptions

- Utilities and sizes are specified.
- Independent additive utility is an approximation.

## Worked check

With sizes 6 and 5 and budget 5, only the second item fits, regardless of the first item's better rank.

## Limits

- Greedy rank order does not solve general knapsack optimally; correlated evidence requires nonadditive utility.

## Connections

- prerequisite_of (incoming): [[public--g-budget]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
