---
id: "m-mutual"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Mutual information

Information shared statistically is not the same as a causal mechanism.

## Connections

- prerequisite_of (incoming): [[public--m-kl]]

## Sources

- [Entropy, Relative Entropy, and Mutual Information, Tsachy Weissman](https://web.stanford.edu/class/ee376a/files/lecture_3.pdf) — five-page PDF; definitions and nonnegativity argument inspected

Evidence links and mathematical analogies do not grant tool permissions.
