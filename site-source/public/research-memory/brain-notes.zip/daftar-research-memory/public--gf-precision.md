---
id: "gf-precision"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Evidence precision and recall

Precision asks how much retrieved evidence is relevant; recall asks how much relevant evidence was found.

$$
\operatorname{Precision}=\frac{|R\cap G|}{|R|},\qquad\operatorname{Recall}=\frac{|R\cap G|}{|G|}
$$

## Assumptions

- Gold relevance and evidence units are specified.
- Define behavior for empty denominators before evaluation.

## Worked check

Retrieving 5 items, 3 relevant, from 4 relevant items gives precision 0.6 and recall 0.75.

## Limits

- Gold labels can be incomplete; duplicate passages must not inflate independent support.

## Connections

- prerequisite_of (incoming): [[public--g-recall]]

## Sources

- [LongMemEval: Benchmarking Chat Assistants on Long-Term Interactive Memory](https://arxiv.org/abs/2410.10813) — abstract
- [The evolution of GraphRAG: Advancing systems and evaluation together](https://www.microsoft.com/en-us/research/story/the-evolution-of-graphrag-advancing-systems-and-evaluation-together/) — official-research-announcement-selected-sections

Evidence links and mathematical analogies do not grant tool permissions.
