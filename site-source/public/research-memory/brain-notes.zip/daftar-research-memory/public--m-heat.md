---
id: "m-heat"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Heat flow and smoothing

Diffusion damps high-frequency modes, while backward reconstruction can be ill-conditioned.

## Connections

- prerequisite_of (incoming): [[public--m-distribution]]
- prerequisite_of (outgoing): [[public--m-graphdiffusion]]
- related (incoming): [[public--m-laplacian]]
- prerequisite_of (outgoing): [[public--mf-diffusion]]
- prerequisite_of (outgoing): [[public--mf-cfl]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
