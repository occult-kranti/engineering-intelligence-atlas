---
id: "g-interval"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Temporal validity intervals

An observation is active when valid_from ≤ query_time < valid_until. Boundaries affect both graph edges and cached answers.

## Connections

- prerequisite_of (incoming): [[public--g-time]]
- prerequisite_of (outgoing): [[public--g-invalidate]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
