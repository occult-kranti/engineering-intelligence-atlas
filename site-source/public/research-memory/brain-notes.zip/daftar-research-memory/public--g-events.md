---
id: "g-events"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Event and decision ledger

Record actual work, receipts, failures, owners, and next actions. An event is evidence of an operation, not a substitute for its artifact.

## Connections

- prerequisite_of (incoming): [[public--g-snapshot]]
- prerequisite_of (outgoing): [[public--g-checkpoint]]
- prerequisite_of (outgoing): [[public--g-idempotency]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
