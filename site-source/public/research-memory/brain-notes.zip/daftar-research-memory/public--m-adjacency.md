---
id: "m-adjacency"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Adjacency and walk counts

Matrix powers count walks with multiplicity, including repeats.

## Connections

- prerequisite_of (incoming): [[public--m-graph]]
- prerequisite_of (outgoing): [[public--m-incidence]]
- prerequisite_of (outgoing): [[public--mf-markov]]
- prerequisite_of (outgoing): [[public--mf-walks]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
