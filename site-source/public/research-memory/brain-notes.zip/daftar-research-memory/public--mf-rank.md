---
id: "mf-rank"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Rank–nullity and lost directions

Choose a basis of the nullspace and extend it to a basis of the domain. The images of the additional vectors form a basis of the image. Therefore every input direction is either accounted for by an independent observable direction or contributes to the kernel dimension.

$$
\operatorname{rank}A+\dim\ker A=n,\qquad A:\mathbb R^n\to\mathbb R^m
$$

## Assumptions

- A is a finite-dimensional linear map.

## Worked check

A=[1 0] maps R² to R. Its rank is 1 and nullspace is {(0,t)}. Its sole returned singular value is positive, yet recovery of the second coordinate is impossible.

## Limits

- A rectangular SVD can list only positive returned singular values while omitting nullspace directions on the larger side.

## Connections

- prerequisite_of (incoming): [[public--m-vectors]]
- prerequisite_of (incoming): [[public--m-basis]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
