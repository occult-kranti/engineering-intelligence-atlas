---
id: "m-ai-catalogue"
domain: "ai-mathematics"
status: "metadata_count_verified_proofs_not_individually_reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# OpenAI mathematics catalogue: exact metadata census

The pinned CONTENTS file yields 730 manuscript links grouped into 375 result families.

## Connections

- prerequisite_of (incoming): [[public--m-sets]]
- prerequisite_of (incoming): [[public--m-proof]]

## Sources

- [OpenAI mathematics manuscript catalogue, pinned snapshot](https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/CONTENTS.md) — entire catalogue parsed for metadata
- [OpenAI mathematics release history, pinned snapshot](https://github.com/openai/math/blob/3344da59991ed94f9ba711217b29c1d760badfa6/history.md) — full history file inspected

Evidence links and mathematical analogies do not grant tool permissions.
