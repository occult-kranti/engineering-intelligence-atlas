---
id: "mf-permanent"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Permanent versus determinant

Both expressions sum one selected entry from each row and column. The determinant includes cancellation by permutation sign, enabling elimination-based algorithms. The permanent removes that sign and measures weighted perfect matchings of a bipartite graph.

$$
\operatorname{per}(A)=\sum_{\sigma\in S_n}\prod_i a_{i,\sigma(i)},\qquad\det(A)=\sum_{\sigma\in S_n}\operatorname{sgn}(\sigma)\prod_i a_{i,\sigma(i)}
$$

## Assumptions

- For complexity claims state the arithmetic field and the circuit model.

## Worked check

For a 2×2 matrix, permanent is ad+bc while determinant is ad−bc. In characteristic 2 these coincide.

## Limits

- An arithmetic VP/VNP separation does not automatically imply Boolean P≠NP; characteristic 2 is a material exception for permanent bounds.

## Connections

- prerequisite_of (incoming): [[public--m-determinant]]
- prerequisite_of (incoming): [[public--m-combinatorics]]
- prerequisite_of (incoming): [[public--m-complexity]]

## Sources

- [VP ≠ VNP over every field: statement and research artifact](https://github.com/anthropics/formal-math/tree/11b6c7e3c927df2658f513b6b68ea7f8929c62c5/vp-vnp) — README and Statement.lean inspected

Evidence links and mathematical analogies do not grant tool permissions.
