---
id: "mf-elliptic"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Short Weierstrass curve and nonsingularity

A singular point must make both partial derivatives of y²−x³−ax−b vanish. Eliminating x and y yields 4a³+27b²=0. Excluding this condition gives a nonsingular cubic with a well-defined geometric group structure after choosing the point at infinity.

$$
y^2=x^3+ax+b,\qquad\Delta=-16(4a^3+27b^2)\ne0
$$

## Assumptions

- Field characteristic is neither 2 nor 3 for this normal form.
- Include the point at infinity for the projective elliptic curve and group law.

## Worked check

y²=x³−x has Δ=64, so it is nonsingular in characteristic 0.

## Limits

- A curve equation is not a solution to the full Birch–Swinnerton-Dyer conjecture; arithmetic ranks require additional tools.

## Connections

- prerequisite_of (incoming): [[public--m-polynomials]]
- prerequisite_of (incoming): [[public--m-fields]]
- prerequisite_of (incoming): [[public--m-gradient]]

## Sources

- [Elliptic Curves, J. S. Milne, first edition](https://www.jmilne.org/math/Books/ectext6.pdf) — book PDF and author edition/errata page inspected

Evidence links and mathematical analogies do not grant tool permissions.
