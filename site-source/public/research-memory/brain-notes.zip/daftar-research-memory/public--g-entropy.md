---
id: "g-entropy"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Information entropy

Quantify uncertainty of a specified probability distribution. Entropy is not a substitute for epistemic quality or semantic understanding.

## Connections

- prerequisite_of (outgoing): [[public--g-compression]]
- prerequisite_of (outgoing): [[public--gf-entropy]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
