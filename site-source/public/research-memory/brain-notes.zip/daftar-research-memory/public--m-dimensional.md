---
id: "m-dimensional"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Dimensions and nondimensionalization

Every additive term must share dimensions; a nondimensional variable is a ratio to a declared scale.

## Connections


## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
