---
id: "m-incidence"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Incidence matrices and conservation

A signed incidence matrix expresses how edge flows enter and leave vertices.

## Connections

- prerequisite_of (incoming): [[public--m-adjacency]]
- prerequisite_of (outgoing): [[public--m-laplacian]]
- prerequisite_of (outgoing): [[public--mf-lap]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
