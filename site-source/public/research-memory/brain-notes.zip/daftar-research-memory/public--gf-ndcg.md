---
id: "gf-ndcg"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Discounted cumulative gain

Higher-ranked relevant items contribute more. Divide by the best available ordering to normalize the score.

$$
\operatorname{DCG}@k=\sum_{i=1}^k\frac{2^{rel_i}-1}{\log_2(i+1)},\qquad\operatorname{nDCG}@k=\operatorname{DCG}@k/\operatorname{IDCG}@k
$$

## Assumptions

- Nonnegative relevance grades.
- Define the all-zero relevance case.

## Worked check

For binary relevance (1,0,1), DCG@3=1+0+1/2=1.5.

## Limits

- Metric choice does not certify answer correctness or source trustworthiness.

## Connections

- prerequisite_of (incoming): [[public--g-ndcg]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
