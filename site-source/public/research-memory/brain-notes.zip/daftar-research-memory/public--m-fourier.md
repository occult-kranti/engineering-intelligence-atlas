---
id: "m-fourier"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Fourier transforms and distributions

Global frequency coordinates require a convention and a function or distribution class.

## Connections

- prerequisite_of (incoming): [[public--m-complex]]
- prerequisite_of (outgoing): [[public--m-distribution]]
- prerequisite_of (outgoing): [[public--m-ai-smoothing]]
- prerequisite_of (outgoing): [[public--m-ai-kakeya]]
- prerequisite_of (outgoing): [[public--mf-cfl]]
- prerequisite_of (outgoing): [[public--mf-heatkernel]]
- prerequisite_of (outgoing): [[public--mf-wave]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
