---
id: "g-provider-cache"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Provider prompt cache

Model-service prefix reuse is different from knowledge retrieval and local result caching; actual provider telemetry is required.

## Connections

- prerequisite_of (incoming): [[public--g-cache]]
- prerequisite_of (outgoing): [[public--g-cost]]

## Sources

- [OpenAI API documentation: Prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching) — official-indexed-documentation-and-local-sdk-field-inspection

Evidence links and mathematical analogies do not grant tool permissions.
