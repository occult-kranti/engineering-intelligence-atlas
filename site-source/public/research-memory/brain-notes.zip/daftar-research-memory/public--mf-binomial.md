---
id: "mf-binomial"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Finite binomial theorem

Expand the product of n copies of a+b. To obtain a term with k factors b, choose k of the n positions; there are binomial(n,k) choices. Commutation lets these products share one coefficient. This finite counting argument does not establish convergence of a generalized infinite binomial series.

$$
(a+b)^n=\sum_{k=0}^{n}\binom nk a^{n-k}b^k
$$

## Assumptions

- n is a nonnegative integer.
- a and b commute.

## Worked check

For n=3 the coefficients 1,3,3,1 give (a+b)³=a³+3a²b+3ab²+b³.

## Limits

- For noncommuting matrices AB and BA differ; the scalar formula cannot be substituted blindly.

## Connections

- prerequisite_of (incoming): [[public--m-induction]]
- prerequisite_of (incoming): [[public--m-polynomials]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
