---
id: "gf-ppr"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Personalized PageRank

At a fixed point, collect terms in p. Invertibility follows because the spectral radius of αPᵀ is below one. The Neumann series sums walks of every length with geometric damping.

$$
p_{t+1}=\alpha P^Tp_t+(1-\alpha)s,\qquad p_*=(1-\alpha)(I-\alpha P^T)^{-1}s
$$

## Assumptions

- 0≤α<1.
- P is row-stochastic after dangling-node handling.
- s is nonnegative and sums to one.

## Worked check

For two alternating vertices, seed (1,0), and α=0.85, p=(1/1.85,0.85/1.85)≈(0.54054,0.45946).

## Limits

- Stationary mass measures graph affinity. It is not probability that a scientific claim is correct.

## Connections

- prerequisite_of (incoming): [[public--g-walk]]

## Sources

- [HippoRAG: Neurobiologically Inspired Long-Term Memory for Large Language Models](https://arxiv.org/abs/2405.14831) — abstract-and-project-description
- [The PageRank Citation Ranking: Bringing Order to the Web](https://ilpubs.stanford.edu/422/) — original-report-discovery

Evidence links and mathematical analogies do not grant tool permissions.
