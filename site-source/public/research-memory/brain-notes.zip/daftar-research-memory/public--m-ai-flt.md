---
id: "m-ai-flt"
domain: "ai-mathematics"
status: "formalization_artifact_and_reported_second_kernel_check_read"
scope: "public"
tags: [daftar, research-memory]
---

# Fermat’s Last Theorem: large Lean formalization

For natural n≥3 and positive natural a,b,c, a^n+b^n≠c^n.

## Connections

- prerequisite_of (incoming): [[public--m-elliptic]]
- prerequisite_of (incoming): [[public--m-modular]]
- prerequisite_of (incoming): [[public--m-types]]
- prerequisite_of (incoming): [[public--m-axioms]]

## Sources

- [Formalizing Fermat's Last Theorem](https://www.anthropic.com/research/formalizing-fermats-last-theorem) — dated announcement and human expert attribution inspected
- [Fermat's Last Theorem in Lean 4](https://github.com/anthropics/fermats-last-theorem/tree/6e837e75355538c7f80bab5b956861e86c4eacc2) — README, theorem text and verification description inspected

Evidence links and mathematical analogies do not grant tool permissions.
