---
id: "oai-family-149"
domain: "ai-mathematics"
status: "catalogued-not-individually-reviewed"
scope: "public"
tags: [daftar, research-memory]
---

# Classwise permanence for weakly reversible mass-action systems

Publisher catalogue family with 2 released manuscript entries. The grouping and titles are metadata, not independent verification of the mathematical claims.

## Connections

- member_of (incoming): [[public--oai-paper-0283]]
- member_of (incoming): [[public--oai-paper-0284]]

## Sources

- [OpenAI mathematics catalogue: pinned metadata snapshot](https://github.com/openai/math/tree/3344da59991ed94f9ba711217b29c1d760badfa6) — catalogue-metadata; manuscripts-not-individually-reviewed

Evidence links and mathematical analogies do not grant tool permissions.
