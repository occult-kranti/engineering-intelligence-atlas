---
id: "m-duality"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Lagrange duality and KKT conditions

Dual variables can certify bounds, with constraint qualifications needed for equality of optima.

## Connections

- prerequisite_of (incoming): [[public--m-gradientdescent]]
- prerequisite_of (outgoing): [[public--m-linearprogram]]
- prerequisite_of (outgoing): [[public--mf-kkt]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected
- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
