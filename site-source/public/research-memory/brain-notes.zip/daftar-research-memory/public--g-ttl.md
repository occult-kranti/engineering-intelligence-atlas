---
id: "g-ttl"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Time-to-live

TTL limits reuse duration but cannot by itself detect a changed source or revoked scope. Version and validity checks are still required.

## Connections

- prerequisite_of (incoming): [[public--g-fifo]]
- prerequisite_of (outgoing): [[public--gf-ttl-probability]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
