---
id: "m-ai-rh"
domain: "ai-mathematics"
status: "strong_independent_formal_verification_evidence"
scope: "public"
tags: [daftar, research-memory]
---

# Riemann Hypothesis: November formal proof and independent checks

The released formal proof is certified to match Mathlib’s RiemannHypothesis proposition.

## Connections

- prerequisite_of (incoming): [[public--m-zeta]]
- prerequisite_of (incoming): [[public--m-types]]
- prerequisite_of (incoming): [[public--m-axioms]]

## Sources

- [Alpöge's Riemann Hypothesis announcement](https://alpo.ge/remark.pdf) — four-page PDF inspected
- [Lean verification of the Riemann Hypothesis](https://leanprover-community.github.io/blog/posts/riemann-hypothesis/) — full statement inspected
- [RH Lean proof: verification files, Andrew Sutherland](https://math.mit.edu/~drew/grh/) — summary, theorem/axiom checklist and dated checker status inspected
- [Clay Mathematics Institute: Riemann Hypothesis](https://www.claymath.org/millennium/riemann-hypothesis/) — current label inspected

Evidence links and mathematical analogies do not grant tool permissions.
