---
id: "mf-hoeffding"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Hoeffding bound for bounded independent samples

Bound the moment-generating function of each centered bounded variable, multiply the bounds using independence, and apply the exponential Markov inequality. Optimizing the exponential parameter gives the upper tail; repeat for the lower tail and add them.

$$
P(|\bar X-E\bar X|\ge\epsilon)\le2e^{-2N\epsilon^2/(b-a)^2}
$$

## Assumptions

- Samples are independent and each lies in [a,b].

## Worked check

For N=1000 Bernoulli observations, ε=0.1 gives a two-sided bound 2e⁻²⁰, before any multiple-comparison adjustment.

## Limits

- Adaptive sampling, duplicated sources and temporal dependence invalidate the independent-sample plug-in bound.

## Connections

- prerequisite_of (incoming): [[public--m-probability]]
- prerequisite_of (incoming): [[public--m-concentration]]

## Sources

- [Concentration inequalities, Cosma Shalizi](https://www.stat.cmu.edu/~cshalizi/sml/21/lectures/06/lecture-06.html) — Hoeffding assumptions and bound inspected

Evidence links and mathematical analogies do not grant tool permissions.
