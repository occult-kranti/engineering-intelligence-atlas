---
id: "g-dag"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Prerequisite DAG

A learning plan uses only prerequisite relations. General knowledge graphs may cycle even when the execution plan must not.

## Connections

- prerequisite_of (incoming): [[public--g-bfs]]
- prerequisite_of (outgoing): [[public--g-cycle]]
- prerequisite_of (outgoing): [[public--gf-topological]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
