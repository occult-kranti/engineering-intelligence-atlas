---
id: "mf-euler"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Complex exponential and phase

Separate the absolutely convergent power series for exp(iθ) into even and odd powers. The even part is cosine and the odd part is i times sine. Multiplication of exponentials then yields angle-addition rules, showing why complex multiplication represents rotations.

$$
e^{i\theta}=\cos\theta+i\sin\theta
$$

## Assumptions

- θ is real for the unit-circle interpretation.

## Worked check

At θ=π/2, the value is i. Multiplication by i maps the point 1 to i, a quarter turn.

## Limits

- A physical frequency in hertz must enter θ as 2πft; confusing cycles with radians changes results by 2π.

## Connections

- prerequisite_of (incoming): [[public--m-complex]]
- prerequisite_of (incoming): [[public--m-polynomials]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
