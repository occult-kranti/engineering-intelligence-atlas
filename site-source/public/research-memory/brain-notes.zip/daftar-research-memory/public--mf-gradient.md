---
id: "mf-gradient"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Gradient descent descent bound

The smoothness inequality is f(y)≤f(x)+∇f(x)ᵀ(y−x)+(L/2)||y−x||². Substitute y=x−η∇f(x) and collect the linear and quadratic terms. Convexity is not needed for this one-step decrease, but it matters for global optimality guarantees.

$$
x^+=x-\eta\nabla f(x),\quad f(x^+)\le f(x)-\eta(1-L\eta/2)\|\nabla f(x)\|^2
$$

## Assumptions

- f has L-Lipschitz gradient on the relevant region.
- 0<η<2/L makes the displayed guaranteed decrease positive.

## Worked check

For f(x)=x²/2, L=1 and η=1, one step takes any x to zero.

## Limits

- In nonconvex optimization a small gradient can indicate a saddle or poor local optimum; noisy gradients require another analysis.

## Connections

- prerequisite_of (incoming): [[public--m-gradient]]
- prerequisite_of (incoming): [[public--m-optimization]]

## Sources

- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
