---
id: "m-axioms"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Axiom and dependency audit

A proved proposition remains conditional on its actual axioms and dependency statements.

## Connections

- prerequisite_of (incoming): [[public--m-types]]
- prerequisite_of (outgoing): [[public--m-ai-flt]]
- prerequisite_of (outgoing): [[public--m-ai-rh]]

## Sources

- [Theorem Proving in Lean 4: Axioms and Computation](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/) — chapter inspected

Evidence links and mathematical analogies do not grant tool permissions.
