---
id: "m-laplacebeltrami"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Laplace–Beltrami operator

The Laplacian changes with the metric and volume element.

## Connections

- related (incoming): [[public--m-metric]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected
- [Proof of the geometric Langlands conjecture I: construction of the functor](https://arxiv.org/abs/2405.03599v3) — abstract and version history inspected

Evidence links and mathematical analogies do not grant tool permissions.
