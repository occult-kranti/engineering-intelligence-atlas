---
id: "mf-sobolev"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Integer Sobolev norm

The norm controls both a function and its derivatives in mean square. A Cauchy sequence in this norm converges with its weak derivatives, giving a Hilbert space useful for existence proofs and variational methods.

$$
\|u\|_{H^s(\Omega)}^2=\sum_{|\alpha|\le s}\|D^\alpha u\|_{L^2(\Omega)}^2
$$

## Assumptions

- s is an integer here; weak derivatives through order s are square integrable.
- For dimensional physical variables introduce reference length scales before adding differently dimensioned derivative norms.

## Worked check

A smooth compactly supported function belongs to every finite-order Hˢ. A jump function in one dimension has a delta derivative and generally is not H¹.

## Limits

- Hˢ regularity is not pointwise Cˢ regularity; embeddings require dimension-dependent thresholds and domain assumptions.

## Connections

- prerequisite_of (incoming): [[public--m-measure]]
- prerequisite_of (incoming): [[public--m-functional]]
- prerequisite_of (incoming): [[public--m-weak]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
