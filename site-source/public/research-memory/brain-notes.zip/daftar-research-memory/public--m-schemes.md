---
id: "m-schemes"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Schemes and sheaves

Local rings and gluing preserve algebraic structure that point sets alone lose.

## Connections

- prerequisite_of (incoming): [[public--m-commutative]]
- prerequisite_of (outgoing): [[public--m-langlands]]
- related (incoming): [[public--m-category]]
- prerequisite_of (outgoing): [[public--m-ai-withdrawals]]
- prerequisite_of (outgoing): [[public--m-ai-langlands]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [NIST DLMF 25.2: Definition and Expansions of the Riemann zeta function](https://dlmf.nist.gov/25.2) — definition and convergence domain inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
