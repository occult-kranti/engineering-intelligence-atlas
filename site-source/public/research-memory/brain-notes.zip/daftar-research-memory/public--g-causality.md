---
id: "g-causality"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Association versus causation

Graph adjacency is not a causal inference. Intervention, design assumptions, and competing explanations determine causal claims.

## Connections

- related (incoming): [[public--g-status]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
