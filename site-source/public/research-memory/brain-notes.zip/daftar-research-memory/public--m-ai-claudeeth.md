---
id: "m-ai-claudeeth"
domain: "ai-mathematics"
status: "artifact_statement_read_independent_acceptance_not_established"
scope: "public"
tags: [daftar, research-memory]
---

# Claude ETH refutation artifact

A deterministic counting 3-SAT algorithm is claimed with time 2^{O(n log log n / sqrt(log n))}.

## Connections

- prerequisite_of (incoming): [[public--m-complexity]]
- prerequisite_of (incoming): [[public--m-logarithms]]

## Sources

- [A 2^o(n) Time Algorithm for 3-SAT](https://github.com/anthropics/formal-math/tree/11b6c7e3c927df2658f513b6b68ea7f8929c62c5/eth) — README, machine model and theorem-entry descriptions inspected

Evidence links and mathematical analogies do not grant tool permissions.
