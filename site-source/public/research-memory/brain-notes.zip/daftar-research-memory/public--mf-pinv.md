---
id: "mf-pinv"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Moore–Penrose pseudoinverse

Rotate b into the U basis. Each nonzero singular coordinate is independently minimized by division by σ_i; zero input coordinates cannot affect the residual. Setting undetermined coordinates to zero selects the minimum-norm member of all least-squares minimizers.

$$
A^+=V\Sigma^+U^*,\quad x_*=A^+b
$$

## Assumptions

- The norm is Euclidean.
- A numerical singular-value cutoff must be declared.

## Worked check

For A=[1 0], b=3, the pseudoinverse returns (3,0). Every (3,t) gives the same observations; t=0 is a selection convention.

## Limits

- Tiny singular values amplify noise. Truncation changes the inverse problem by adding a modeling choice.

## Connections

- prerequisite_of (incoming): [[public--m-svd]]
- prerequisite_of (incoming): [[public--m-pseudoinverse]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
