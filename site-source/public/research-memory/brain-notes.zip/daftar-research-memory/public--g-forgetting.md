---
id: "g-forgetting"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Forgetting and retention

A decaying retrieval priority is a software policy. It must not delete durable evidence or imitate a universal human forgetting law.

## Connections

- prerequisite_of (outgoing): [[public--gf-retention]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
