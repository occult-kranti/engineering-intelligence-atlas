---
id: "m-probability"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Probability spaces and events

Probabilities are conditional on a chosen experiment and model, not inherent truth scores.

## Connections

- prerequisite_of (outgoing): [[public--m-randomvariable]]
- prerequisite_of (outgoing): [[public--m-markov]]
- related (incoming): [[public--m-measure]]
- prerequisite_of (outgoing): [[public--mf-bayes]]
- prerequisite_of (outgoing): [[public--mf-cov]]
- prerequisite_of (outgoing): [[public--mf-hoeffding]]
- prerequisite_of (outgoing): [[public--mf-entropy]]
- prerequisite_of (outgoing): [[public--mf-kl]]
- prerequisite_of (outgoing): [[public--mf-markov]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
