---
id: "gf-laplacian"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Combinatorial Laplacian

Row i acts on x by summing w_ij(x_i-x_j); a constant signal produces zero differences.

$$
L=D-A,\qquad L\mathbf 1=0
$$

## Assumptions

- Undirected graph with nonnegative weights.

## Worked check

For the three-vertex path, L=[[1,-1,0],[-1,2,-1],[0,-1,1]], with eigenvalues 0,1,3.

## Limits

- L is singular on each connected component. A directed version needs a separately stated convention.

## Connections

- prerequisite_of (incoming): [[public--g-adjacency]]
- prerequisite_of (incoming): [[public--g-degree]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
