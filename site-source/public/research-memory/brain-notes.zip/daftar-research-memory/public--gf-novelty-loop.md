---
id: "gf-novelty-loop"
domain: "memory"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Measured improvement in a fixed loop

Evaluate both revisions on the same criterion, then subtract. This distinguishes observed progress from activity counts.

$$
\Delta U_k=U(\text{system}_{k+1};D)-U(\text{system}_{k};D)
$$

## Assumptions

- Hold evaluation data and judging procedure fixed within a comparison.
- Track resource cost and regressions separately.

## Worked check

Recall increasing from 0.60 to 0.65 is a five-percentage-point change on that evaluation; it is not proof of universal improvement.

## Limits

- Repeated tuning on the same cases can overfit; retain held-out questions and report uncertainty.

## Connections

- prerequisite_of (incoming): [[public--g-baseline]]
- prerequisite_of (incoming): [[public--g-loop]]

## Sources

- [The evolution of GraphRAG: Advancing systems and evaluation together](https://www.microsoft.com/en-us/research/story/the-evolution-of-graphrag-advancing-systems-and-evaluation-together/) — official-research-announcement-selected-sections

Evidence links and mathematical analogies do not grant tool permissions.
