---
id: "g-cosine"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Cosine similarity

Compare vector directions after accounting for nonzero norms. Different embedding models create different geometries.

## Connections

- prerequisite_of (incoming): [[public--g-embedding]]
- prerequisite_of (outgoing): [[public--g-rrf]]

## Sources

- [From RAG to Memory: Non-Parametric Continual Learning for Large Language Models](https://arxiv.org/html/2502.14802v2) — selected-methods-and-limitations

Evidence links and mathematical analogies do not grant tool permissions.
