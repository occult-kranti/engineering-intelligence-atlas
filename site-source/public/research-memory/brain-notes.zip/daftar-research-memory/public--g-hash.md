---
id: "g-hash"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Content addressing

Hash permitted source bytes or a canonical structured snapshot; a digest proves byte identity and does not prove truth.

## Connections

- prerequisite_of (incoming): [[public--g-provenance]]
- prerequisite_of (outgoing): [[public--g-snapshot]]
- prerequisite_of (outgoing): [[public--gf-cache-key]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
