---
id: "g-status"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Claim status and uncertainty

Established theorem, approximation, measured result, preprint claim, disputed result, and open question must not share one undifferentiated confidence flag.

## Connections

- prerequisite_of (incoming): [[public--g-provenance]]
- prerequisite_of (outgoing): [[public--g-questions]]
- related (outgoing): [[public--g-causality]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
