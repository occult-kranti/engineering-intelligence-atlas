---
id: "mf-weakpoisson"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Weak Poisson formulation

Multiply the PDE by v and integrate. Integration by parts moves one derivative from u to v; the boundary term vanishes because the trace of v is zero. This lowers the smoothness required of u and produces the finite-element stiffness matrix after choosing a basis.

$$
-\Delta u=f,\ u|_{\partial\Omega}=0\quad\Rightarrow\quad\int_\Omega\nabla u\cdot\nabla v=\int_\Omega fv\ \ \forall v\in H_0^1(\Omega)
$$

## Assumptions

- Domain and source permit a weak solution; homogeneous Dirichlet data.
- The gradient bilinear form is coercive on H₀¹ under a Poincaré inequality.

## Worked check

On (0,1), f=2 gives u=x(1−x). Direct differentiation yields −u″=2, and u vanishes at both endpoints.

## Limits

- Changing to pure Neumann conditions introduces a constant nullspace and a source compatibility condition.

## Connections

- prerequisite_of (incoming): [[public--m-sobolev]]
- prerequisite_of (incoming): [[public--m-divergence]]
- prerequisite_of (incoming): [[public--m-fem]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
