# Daftar research memory

This portable Markdown backup accompanies Donna Brain. The internal application uses its own typed graph and native company records; it needs no external note application. All notes are public research. Relations retain their types and directions. Formula assumptions and source reading depth travel with the note. Catalogue papers are metadata entries, not reviewed proofs.

Snapshot: 3b8237b5e3a033dc9bfa148507ec2d6203c7806228b524afada3a2c47299df1b
