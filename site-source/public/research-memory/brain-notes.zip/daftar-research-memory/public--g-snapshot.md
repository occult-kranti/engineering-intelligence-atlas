---
id: "g-snapshot"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Immutable snapshots

Write a content-addressed graph snapshot and then update its scope pointer. Keep original source identity with every derived artifact.

## Connections

- prerequisite_of (incoming): [[public--g-hash]]
- prerequisite_of (outgoing): [[public--g-events]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
