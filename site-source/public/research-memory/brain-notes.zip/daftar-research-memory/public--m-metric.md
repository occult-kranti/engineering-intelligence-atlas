---
id: "m-metric"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Riemannian and Lorentzian metrics

A metric measures lengths or intervals and controls index raising and lowering.

## Connections

- prerequisite_of (incoming): [[public--m-tangent]]
- prerequisite_of (outgoing): [[public--m-connection]]
- related (outgoing): [[public--m-laplacebeltrami]]
- prerequisite_of (outgoing): [[public--m-ai-kakeya]]
- prerequisite_of (outgoing): [[public--mf-laplacebeltrami]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
