---
id: "mf-fourier"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Fourier transform and Plancherel convention

Complex exponentials act as generalized orthogonal modes. The inverse under this convention contains 1/(2π); consistency of the pair forces the same factor in the energy identity. Substituting a Gaussian provides an explicit check of normalization.

$$
\hat f(\omega)=\int_\mathbb R f(t)e^{-i\omega t}dt,\quad\int|f|^2dt=\frac1{2\pi}\int|\hat f|^2d\omega
$$

## Assumptions

- Use L¹∩L² for a classical integral; extend to L² in the norm sense.

## Worked check

For f(t)=exp(−t²/2), fhat(ω)=√(2π)exp(−ω²/2), and both sides equal √π.

## Limits

- Frequency in cycles per second uses a different exponent and normalization. A finite window causes leakage and finite resolution.
- Hunter uses an alternative 2π normalization; converting to the notebook's unnormalized forward transform moves the factor 1/(2π) into its one-dimensional Plancherel identity.

## Connections

- prerequisite_of (incoming): [[public--m-complex]]
- prerequisite_of (incoming): [[public--m-integral]]
- prerequisite_of (incoming): [[public--m-functional]]

## Sources

- [Notes on Partial Differential Equations, John K. Hunter](https://www.math.ucdavis.edu/~hunter/pdes/pde_notes.pdf) — 242-page PDF contents and relevant section map inspected

Evidence links and mathematical analogies do not grant tool permissions.
