---
id: "g-recall"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Recall and precision

Count supported relevant evidence, not just generated answer fluency. Explicitly define the denominator and judging procedure.

## Connections

- prerequisite_of (incoming): [[public--g-baseline]]
- prerequisite_of (outgoing): [[public--g-ndcg]]
- prerequisite_of (outgoing): [[public--gf-precision]]

## Sources

- [The evolution of GraphRAG: Advancing systems and evaluation together](https://www.microsoft.com/en-us/research/story/the-evolution-of-graphrag-advancing-systems-and-evaluation-together/) — official-research-announcement-selected-sections

Evidence links and mathematical analogies do not grant tool permissions.
