---
id: "m-natural"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Natural transformations

Naturality requires a commuting relation for every relevant morphism.

## Connections

- prerequisite_of (incoming): [[public--m-functor]]
- prerequisite_of (outgoing): [[public--m-universal]]
- prerequisite_of (outgoing): [[public--mf-yoneda]]

## Sources

- [Basic Category Theory, Tom Leinster, version 2](https://arxiv.org/abs/1612.09375v2) — abstract, edition history and scope inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
