---
id: "m-tensor"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Tensors and multilinear maps

Tensor rank, matrix rank and the number of stored entries describe different properties.

## Connections

- prerequisite_of (outgoing): [[public--m-complexity]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
