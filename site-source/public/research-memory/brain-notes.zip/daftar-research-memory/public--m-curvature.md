---
id: "m-curvature"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Curvature and holonomy

Curvature measures failure of local transport around infinitesimal loops to commute.

## Connections

- prerequisite_of (incoming): [[public--m-connection]]
- related (incoming): [[public--m-stokes]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
