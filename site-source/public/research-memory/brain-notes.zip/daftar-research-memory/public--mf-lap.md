---
id: "mf-lap"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Graph Laplacian energy

Expand xᵀDx−xᵀWx and group the symmetric i,j terms. Each pair becomes w_ij(x_i−x_j)². Every summand is nonnegative, and constant signals have zero energy. For a connected graph these are exactly the nullspace directions.

$$
L=D-W=B^T C B,\quad x^TLx=\sum_{\{i,j\}}w_{ij}(x_i-x_j)^2
$$

## Assumptions

- Undirected graph with nonnegative weights; sum counts each undirected edge once.

## Worked check

For a three-vertex unit-weight path and x=(1,0,0), the energy is (1−0)²+(0−0)²=1.

## Limits

- Signed or directed relations require different operators; mixing contradicts and supports edges as positive diffusion weights erases meaning.

## Connections

- prerequisite_of (incoming): [[public--m-incidence]]
- prerequisite_of (incoming): [[public--m-inner]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
