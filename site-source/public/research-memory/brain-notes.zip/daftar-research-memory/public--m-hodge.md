---
id: "m-hodge"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Hodge theory

On suitable manifolds harmonic representatives connect PDEs with topological classes.

## Connections

- prerequisite_of (incoming): [[public--m-cohomology]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
