---
id: "g-temporal-eval"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Temporal update tests

Test future facts, expiry boundaries, corrections, and historical queries rather than only static fact lookup.

## Connections

- prerequisite_of (incoming): [[public--g-time]]
- prerequisite_of (outgoing): [[public--g-abstain]]

## Sources

- [LongMemEval: Benchmarking Chat Assistants on Long-Term Interactive Memory](https://arxiv.org/abs/2410.10813) — abstract

Evidence links and mathematical analogies do not grant tool permissions.
