---
id: "m-chain"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Chain rule and automatic differentiation

Derivative information propagates through function composition; branch behavior matters.

## Connections

- prerequisite_of (incoming): [[public--m-derivative]]
- prerequisite_of (outgoing): [[public--m-gradient]]
- prerequisite_of (outgoing): [[public--mf-jacobian]]
- prerequisite_of (outgoing): [[public--mf-eulerlagrange]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
