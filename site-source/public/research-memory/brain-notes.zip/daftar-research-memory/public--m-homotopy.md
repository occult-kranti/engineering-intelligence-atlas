---
id: "m-homotopy"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Homotopy and fundamental group

Continuous loop deformation is stronger than mere connectivity in a drawing.

## Connections

- prerequisite_of (incoming): [[public--m-topology]]
- prerequisite_of (outgoing): [[public--m-simplicial]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
