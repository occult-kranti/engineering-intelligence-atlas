---
id: "g-cycle"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Cycle detection

Kahn's algorithm reports a failed topological ordering; its remaining vertices can include descendants of cycles.

## Connections

- prerequisite_of (incoming): [[public--g-dag]]
- prerequisite_of (outgoing): [[public--g-loop]]
- prerequisite_of (outgoing): [[public--gf-topological]]

## Sources

- [Daftar graph-memory implementation and executed tests](https://github.com/occult-kranti/engineering-intelligence-atlas/tree/main/projects/research-memory-atlas) — locally-executed-source

Evidence links and mathematical analogies do not grant tool permissions.
