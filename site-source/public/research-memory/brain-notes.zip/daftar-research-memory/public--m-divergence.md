---
id: "m-divergence"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Divergence theorem

Boundary flux equals integrated interior divergence under regularity and orientation conditions.

## Connections

- prerequisite_of (incoming): [[public--m-jacobian]]
- prerequisite_of (outgoing): [[public--m-weak]]
- prerequisite_of (outgoing): [[public--mf-weakpoisson]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
