---
id: "m-bayes"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Bayesian conditioning

Updating needs likelihoods and a denominator that can be nonzero; repeated evidence may be dependent.

## Connections

- prerequisite_of (incoming): [[public--m-randomvariable]]
- prerequisite_of (outgoing): [[public--m-entropy]]
- related (outgoing): [[public--m-causal]]
- prerequisite_of (outgoing): [[public--mf-mi]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
