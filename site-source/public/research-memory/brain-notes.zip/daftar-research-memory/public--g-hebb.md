---
id: "g-hebb"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Hebbian associations

Coactivation can strengthen a model connection, but cooccurrence alone is not evidence of cause, agreement, or truth.

## Connections

- prerequisite_of (outgoing): [[public--g-hopfield]]
- prerequisite_of (outgoing): [[public--gf-hebb]]
- prerequisite_of (outgoing): [[public--gf-hopfield-energy]]

## Sources

- [Neural networks and physical systems with emergent collective computational abilities](https://pmc.ncbi.nlm.nih.gov/articles/PMC346238/) — abstract-and-original-paper-discovery

Evidence links and mathematical analogies do not grant tool permissions.
