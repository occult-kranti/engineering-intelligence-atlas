---
id: "g-degree"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Degree and hub effects

A high-degree node can dominate navigation even when it is generic. Source references and analogy links need deliberate treatment.

## Connections

- prerequisite_of (incoming): [[public--g-adjacency]]
- prerequisite_of (outgoing): [[public--g-laplacian]]
- prerequisite_of (outgoing): [[public--gf-laplacian]]

## Sources

- [From Local to Global: A Graph RAG Approach to Query-Focused Summarization](https://arxiv.org/abs/2404.16130) — abstract-and-official-publication

Evidence links and mathematical analogies do not grant tool permissions.
