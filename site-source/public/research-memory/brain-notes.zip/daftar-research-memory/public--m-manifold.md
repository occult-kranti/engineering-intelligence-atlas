---
id: "m-manifold"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Manifolds and charts

A manifold is locally Euclidean; one chart rarely describes its entire topology.

## Connections

- prerequisite_of (incoming): [[public--m-euclidean]]
- prerequisite_of (outgoing): [[public--m-tangent]]
- prerequisite_of (outgoing): [[public--mf-curvature]]

## Sources

- [General Relativity, chapter 3: Differential Geometry, David Tong](https://davidtong.org/pdfs/teaching/general-relativity/gr3.pdf) — 51-page chapter structure and geometry definitions inspected

Evidence links and mathematical analogies do not grant tool permissions.
