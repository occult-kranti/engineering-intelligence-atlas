---
id: "m-scc"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Strongly connected components

Collapsing directed feedback components produces a DAG without pretending the loops disappeared.

## Connections

- prerequisite_of (incoming): [[public--m-dag]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
