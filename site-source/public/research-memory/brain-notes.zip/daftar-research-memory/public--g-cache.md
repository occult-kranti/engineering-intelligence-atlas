---
id: "g-cache"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Result cache

Reuse a derived result only when its query, snapshot, scope policy, algorithm, and time-dependent eligibility still match.

## Connections

- prerequisite_of (incoming): [[public--g-invalidate]]
- prerequisite_of (incoming): [[public--g-memo]]
- prerequisite_of (outgoing): [[public--g-lru]]
- prerequisite_of (outgoing): [[public--g-provider-cache]]
- related (outgoing): [[public--g-memgpt]]
- related (outgoing): [[public--g-kv]]
- prerequisite_of (outgoing): [[public--gf-latency]]
- prerequisite_of (outgoing): [[public--gf-amat]]

## Sources

- [Python documentation: functools](https://docs.python.org/3/library/functools.html) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
