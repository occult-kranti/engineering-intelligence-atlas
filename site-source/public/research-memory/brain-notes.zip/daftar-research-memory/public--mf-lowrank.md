---
id: "mf-lowrank"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Optimal truncated SVD error

Orthogonality of singular components makes squared error add across discarded modes. The min-max characterization of singular values shows no rank-k matrix can remove more of this error under the same norm.

$$
A_k=\sum_{i=1}^k\sigma_i u_iv_i^*,\quad\|A-A_k\|_F^2=\sum_{i>k}\sigma_i^2
$$

## Assumptions

- Singular values ordered nonincreasingly; the objective is unweighted Frobenius norm.

## Worked check

For diag(5,2,1), the best rank 1 Frobenius error is √(4+1)=√5.

## Limits

- Frobenius-optimal compression need not preserve rare but important events, permissions, exact facts or downstream decisions.

## Connections

- prerequisite_of (incoming): [[public--m-svd]]
- prerequisite_of (incoming): [[public--m-pca]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
