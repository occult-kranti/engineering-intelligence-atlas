---
id: "g-magnetism-bridge"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Spin models and associative networks

Some associative models resemble spin Hamiltonians mathematically; a software weight is not a measured magnetic coupling.

## Connections

- analogy (incoming): [[public--g-hopfield]]
- analogy (outgoing): [[public--p-ising]]

## Sources

- [Neural networks and physical systems with emergent collective computational abilities](https://pmc.ncbi.nlm.nih.gov/articles/PMC346238/) — abstract-and-original-paper-discovery

Evidence links and mathematical analogies do not grant tool permissions.
