---
id: "m-ai-3sum"
domain: "ai-mathematics"
status: "primary_paper_scope_and_formal_limitations_read"
scope: "public"
tags: [daftar, research-memory]
---

# Truly subquadratic 3SUM and subcubic APSP

The paper states bounded-integer 3SUM in O(n^1.9992) and APSP in O(n^2.9995), rounded exponents.

## Connections

- prerequisite_of (incoming): [[public--m-graph]]
- prerequisite_of (incoming): [[public--m-complexity]]

## Sources

- [Truly Subquadratic 3SUM and Truly Subcubic APSP via Triangles in Sparse Lopsided Graphs](https://arxiv.org/abs/2610.06783v1) — abstract and theorem scope inspected
- [Anthropic formal-math repository, pinned snapshot](https://github.com/anthropics/formal-math/tree/11b6c7e3c927df2658f513b6b68ea7f8929c62c5) — README and 3SUM/APSP, ETH, VP/VNP project notes inspected

Evidence links and mathematical analogies do not grant tool permissions.
