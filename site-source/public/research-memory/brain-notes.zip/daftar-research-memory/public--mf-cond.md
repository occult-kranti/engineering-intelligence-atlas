---
id: "mf-cond"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Relative error and matrix condition number

Since δx=A⁻¹δb, ||δx||≤||A⁻¹||||δb||. Also ||b||=||Ax||≤||A||||x||. Combining the two inequalities yields the relative bound and κ=||A||||A⁻¹||.

$$
\kappa_2(A)=\frac{\sigma_{\max}}{\sigma_{\min}},\quad \frac{\|\delta x\|}{\|x\|}\le\kappa_2(A)\frac{\|\delta b\|}{\|b\|}
$$

## Assumptions

- A is fixed and invertible; only b is perturbed.
- The bound is worst-case and uses compatible Euclidean norms.
- b and x are nonzero, so relative error ratios are defined.

## Worked check

diag(1,10⁻⁶) has condition number 10⁶; noise in its second output can be amplified a millionfold.

## Limits

- Perturbations in A require an additional denominator and a smallness condition; the displayed formula does not cover them.

## Connections

- prerequisite_of (incoming): [[public--m-svd]]
- prerequisite_of (incoming): [[public--m-conditioning]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
