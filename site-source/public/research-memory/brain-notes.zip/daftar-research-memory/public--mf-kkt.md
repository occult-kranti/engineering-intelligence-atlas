---
id: "mf-kkt"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# KKT optimality conditions

Form the Lagrangian f+Σλ_i g_i+νᵀ(Ax−b). At a saddle point, stationarity in x and complementary slackness ensure that inactive constraints exert no dual force. Feasibility then connects the primal optimum with a dual certificate.

$$
\nabla f(x)+\sum_i\lambda_i\nabla g_i(x)+A^T\nu=0,\quad \lambda_i g_i(x)=0
$$

## Assumptions

- For this gradient form, f and each g_i are differentiable; nonsmooth problems require subgradient conditions. Include primal feasibility, λ_i≥0 and complementary slackness.
- Convexity and a constraint qualification such as Slater's condition give the standard necessity/sufficiency setting.

## Worked check

Minimize x² subject to x≥1. Write g=1−x; optimum x=1 has stationarity 2x−λ=0, so λ=2.

## Limits

- For nonconvex problems KKT conditions can hold at nonglobal points; without a constraint qualification necessity can fail.

## Connections

- prerequisite_of (incoming): [[public--m-gradient]]
- prerequisite_of (incoming): [[public--m-duality]]

## Sources

- [Convex Optimization, Stephen Boyd and Lieven Vandenberghe](https://web.stanford.edu/~boyd/cvxbook/) — author page inspected; full PDF request timed out

Evidence links and mathematical analogies do not grant tool permissions.
