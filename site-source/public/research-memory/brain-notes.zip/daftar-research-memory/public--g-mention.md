---
id: "g-mention"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Unlinked mentions

A matching name offers a link candidate. Resolve entity identity and meaning before treating it as a relation.

## Connections

- related (outgoing): [[public--g-identity]]

## Sources

- [Obsidian Help: Backlinks](https://obsidian.md/help/plugins/backlinks) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
