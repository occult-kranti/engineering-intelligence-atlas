---
id: "m-svd"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Singular value decomposition

SVD separates input directions, gains and output directions for rectangular matrices.

## Connections

- prerequisite_of (incoming): [[public--m-spectral]]
- prerequisite_of (outgoing): [[public--m-pca]]
- prerequisite_of (outgoing): [[public--mf-pinv]]
- prerequisite_of (outgoing): [[public--mf-pca]]
- prerequisite_of (outgoing): [[public--mf-cond]]
- prerequisite_of (outgoing): [[public--mf-tikhonov]]
- prerequisite_of (outgoing): [[public--mf-lowrank]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
