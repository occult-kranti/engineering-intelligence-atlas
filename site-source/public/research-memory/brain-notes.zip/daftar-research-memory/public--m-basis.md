---
id: "m-basis"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Basis and dimension

A basis gives unique finite coordinate expansions; dimension counts independent directions.

## Connections

- prerequisite_of (incoming): [[public--m-vectors]]
- prerequisite_of (outgoing): [[public--m-rank]]
- prerequisite_of (outgoing): [[public--mf-rank]]
- prerequisite_of (outgoing): [[public--mf-det]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
