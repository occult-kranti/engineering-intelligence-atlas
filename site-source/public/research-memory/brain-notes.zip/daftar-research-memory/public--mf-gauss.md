---
id: "mf-gauss"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Multivariate Gaussian density

Transform a standard normal z by x=μ+Lz where LLᵀ=Σ. The quadratic form becomes ||z||² and the change-of-variables determinant contributes |det L|⁻¹=det(Σ)⁻¹/².

$$
p(x)=\frac{e^{-\frac12(x-\mu)^T\Sigma^{-1}(x-\mu)}}{(2\pi)^{d/2}\det(\Sigma)^{1/2}}
$$

## Assumptions

- Σ is symmetric positive definite; singular Gaussians require a lower-dimensional measure.

## Worked check

With μ=0 and Σ=I, the coordinates are independent standard normals and the density factors.

## Limits

- A Gaussian is a model assumption; observed covariance does not establish Gaussian tails or independence.

## Connections

- prerequisite_of (incoming): [[public--m-covariance]]
- prerequisite_of (incoming): [[public--m-jacobian]]
- prerequisite_of (incoming): [[public--m-determinant]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
