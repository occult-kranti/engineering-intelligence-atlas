---
id: "g-wal"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Write-ahead logs

A transactional database can record changes before checkpointing state; its durability depends on the configured implementation.

## Connections

- prerequisite_of (incoming): [[public--g-sqlite]]

## Sources

- [SQLite write-ahead logging](https://sqlite.org/wal.html) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
