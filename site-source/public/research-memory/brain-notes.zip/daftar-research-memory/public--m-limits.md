---
id: "m-limits"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Limits and continuity

A limit describes controlled approach; sampled agreement does not establish continuity.

## Connections

- prerequisite_of (outgoing): [[public--m-derivative]]
- prerequisite_of (outgoing): [[public--mf-derivative]]
- prerequisite_of (outgoing): [[public--mf-ftc]]
- prerequisite_of (outgoing): [[public--mf-contraction]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
