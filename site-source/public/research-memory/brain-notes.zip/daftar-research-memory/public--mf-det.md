---
id: "mf-det"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Two-dimensional determinant and inverse

The signed area of the parallelogram spanned by the columns is ad−bc. Multiplying A by the proposed adjugate gives (ad−bc)I; division is legal exactly when the determinant is nonzero. This direct derivation shows both invertibility and volume scaling.

$$
\det A=ad-bc,\quad A^{-1}=\frac1{ad-bc}\begin{pmatrix}d&-b\\-c&a\end{pmatrix}
$$

## Assumptions

- ad−bc≠0 for the inverse.

## Worked check

For A=[[2,1],[1,1]], det A=1 and inverse [[1,−1],[−1,2]]. Their product is the identity.

## Limits

- A nonzero determinant can coexist with severe ill-conditioning; determinant magnitude alone is a poor stability test.

## Connections

- prerequisite_of (incoming): [[public--m-basis]]
- prerequisite_of (incoming): [[public--m-determinant]]

## Sources

- [Linear Algebra, Gilbert Strang, MIT 18.06SC](https://ocw.mit.edu/courses/18-06sc-linear-algebra-fall-2011/) — course index and SVD lesson inspected

Evidence links and mathematical analogies do not grant tool permissions.
