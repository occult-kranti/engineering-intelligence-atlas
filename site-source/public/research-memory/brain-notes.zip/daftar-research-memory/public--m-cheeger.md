---
id: "m-cheeger"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Conductance and spectral gaps

A small bottleneck limits mixing and connects combinatorial cuts to eigenvalues.

## Connections

- prerequisite_of (incoming): [[public--m-markov]]

## Sources

- [Essential spectral theory and graph drawing, Daniel Spielman](https://www.cs.yale.edu/homes/spielman/561/lect02-18.pdf) — eight-page PDF inspected

Evidence links and mathematical analogies do not grant tool permissions.
