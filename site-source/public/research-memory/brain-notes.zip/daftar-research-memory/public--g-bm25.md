---
id: "g-bm25"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# BM25 lexical ranking

Combine term saturation, document length normalization, and corpus frequency into an interpretable lexical baseline.

## Connections

- prerequisite_of (incoming): [[public--g-idf]]
- prerequisite_of (outgoing): [[public--g-rrf]]
- prerequisite_of (outgoing): [[public--gf-rrf]]

## Sources

- [The Probabilistic Relevance Framework: BM25 and Beyond](https://doi.org/10.1561/1500000019) — publisher-metadata-and-abstract

Evidence links and mathematical analogies do not grant tool permissions.
