---
id: "g-memgpt"
domain: "memory"
status: "representative-frontier"
scope: "public"
tags: [daftar, research-memory]
---

# MemGPT memory tiers

Treat active context as a scarce resource and durable evidence as an external store with explicit read/write operations.

## Connections

- related (incoming): [[public--g-cache]]
- prerequisite_of (outgoing): [[public--gf-amat]]

## Sources

- [MemGPT: Towards LLMs as Operating Systems](https://arxiv.org/abs/2310.08560) — indexed-abstract

Evidence links and mathematical analogies do not grant tool permissions.
