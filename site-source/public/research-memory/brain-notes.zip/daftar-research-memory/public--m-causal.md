---
id: "m-causal"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Causal models and interventions

Association graphs do not establish intervention effects without identification assumptions.

## Connections

- related (incoming): [[public--m-bayes]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
