---
id: "m-covariance"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Covariance and correlation

Zero covariance alone does not imply independence.

## Connections

- prerequisite_of (incoming): [[public--m-randomvariable]]
- prerequisite_of (outgoing): [[public--m-gaussian]]
- prerequisite_of (outgoing): [[public--mf-pca]]
- prerequisite_of (outgoing): [[public--mf-gauss]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
