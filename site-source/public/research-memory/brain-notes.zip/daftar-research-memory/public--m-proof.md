---
id: "m-proof"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Proof obligations and counterexamples

A theorem combines hypotheses, conclusion and a derivation; a single admissible counterexample defeats a universal claim.

## Connections

- prerequisite_of (incoming): [[public--m-induction]]
- prerequisite_of (outgoing): [[public--m-types]]
- prerequisite_of (outgoing): [[public--m-ai-universal]]
- prerequisite_of (outgoing): [[public--m-ai-imo]]
- prerequisite_of (outgoing): [[public--m-ai-ten]]
- prerequisite_of (outgoing): [[public--m-ai-ns-translation]]
- prerequisite_of (outgoing): [[public--m-ai-catalogue]]
- prerequisite_of (outgoing): [[public--m-ai-withdrawals]]

## Sources

- [Theorem Proving in Lean 4: Axioms and Computation](https://lean-lang.org/theorem_proving_in_lean4/Axioms-and-Computation/) — chapter inspected

Evidence links and mathematical analogies do not grant tool permissions.
