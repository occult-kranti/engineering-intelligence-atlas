---
id: "mf-zeta"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Zeta Dirichlet series and Euler product

Expand each prime factor as a geometric series. Unique factorization identifies every finite prime-power product with exactly one positive integer. Absolute convergence justifies regrouping and taking the infinite product limit.

$$
\zeta(s)=\sum_{n=1}^\infty n^{-s}=\prod_{p\ \mathrm{prime}}(1-p^{-s})^{-1},\quad\Re s>1
$$

## Assumptions

- Absolute convergence for Re(s)>1.
- Values elsewhere use analytic continuation, not this convergent series.

## Worked check

At s=2, ζ(2)=π²/6; partial sums approach it from below.

## Limits

- Substituting s=−1 into the divergent series is invalid; analytic continuation does not make ordinary summation of positive integers negative.

## Connections

- prerequisite_of (incoming): [[public--m-primes]]
- prerequisite_of (incoming): [[public--m-complexanalysis]]
- prerequisite_of (incoming): [[public--m-integral]]

## Sources

- [NIST DLMF 25.2: Definition and Expansions of the Riemann zeta function](https://dlmf.nist.gov/25.2) — definition and convergence domain inspected

Evidence links and mathematical analogies do not grant tool permissions.
