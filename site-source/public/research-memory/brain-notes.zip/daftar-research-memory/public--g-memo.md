---
id: "g-memo"
domain: "memory"
status: "established-method"
scope: "public"
tags: [daftar, research-memory]
---

# Memoization

A cache is sound only when its key represents all output-relevant dependencies. Hidden mutable inputs break argument-only memoization.

## Connections

- prerequisite_of (outgoing): [[public--g-cache]]

## Sources

- [Python documentation: functools](https://docs.python.org/3/library/functools.html) — official-documentation

Evidence links and mathematical analogies do not grant tool permissions.
