---
id: "m-variation"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Calculus of variations

Stationarity of a functional produces equations plus boundary conditions, not automatically a minimum.

## Connections

- prerequisite_of (incoming): [[public--m-gradient]]
- prerequisite_of (outgoing): [[public--m-pde]]
- related (outgoing): [[public--m-geodesic]]
- prerequisite_of (outgoing): [[public--mf-eulerlagrange]]

## Sources

- [Calculus, Gilbert Strang: MIT OpenCourseWare edition](https://ocw.mit.edu/courses/res-18-001-calculus-fall-2023/pages/open-textbook/) — course and chapter index inspected

Evidence links and mathematical analogies do not grant tool permissions.
