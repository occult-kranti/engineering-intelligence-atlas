---
id: "m-representations"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Linear representations

A representation turns group composition into matrix multiplication.

## Connections

- prerequisite_of (incoming): [[public--m-groups]]
- prerequisite_of (outgoing): [[public--m-lie]]
- prerequisite_of (outgoing): [[public--m-ai-grh]]
- prerequisite_of (outgoing): [[public--m-ai-langlands]]

## Sources

- [Fields and Galois Theory, J. S. Milne, version 5.10](https://www.jmilne.org/math/CourseNotes/ft.html) — version and scope page inspected
- [The Stacks Project](https://stacks.math.columbia.edu/) — index, scope and version indicators inspected

Evidence links and mathematical analogies do not grant tool permissions.
