---
id: "m-markov"
domain: "mathematics"
status: "established"
scope: "public"
tags: [daftar, research-memory]
---

# Markov chains and stationarity

The Markov property discards history only after choosing a sufficient state.

## Connections

- prerequisite_of (incoming): [[public--m-probability]]
- prerequisite_of (outgoing): [[public--m-cheeger]]
- prerequisite_of (outgoing): [[public--mf-pagerank]]

## Sources

- [MIT 18.05: Introduction to Probability and Statistics](https://ocw.mit.edu/courses/18-05-introduction-to-probability-and-statistics-spring-2022/) — course scope and readings index inspected

Evidence links and mathematical analogies do not grant tool permissions.
