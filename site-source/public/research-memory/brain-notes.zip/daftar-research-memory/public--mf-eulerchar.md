---
id: "mf-eulerchar"
domain: "mathematics"
status: "formula-with-stated-assumptions"
scope: "public"
tags: [daftar, research-memory]
---

# Euler characteristic of a finite complex

Apply rank–nullity to every boundary matrix. The image-rank terms cancel pairwise in the alternating sum, leaving equality between cell counts and homology dimensions. This is a compact check on a chain-complex implementation.

$$
\chi=\sum_k(-1)^kc_k=\sum_k(-1)^k\beta_k
$$

## Assumptions

- Finite cell or simplicial complex; Betti numbers use a fixed coefficient field.

## Worked check

A tetrahedron surface has V−E+F=4−6+4=2, matching β₀=1, β₁=0, β₂=1.

## Limits

- Euler characteristic loses information: spaces with the same value can have different topology.

## Connections

- prerequisite_of (incoming): [[public--m-homology]]
- prerequisite_of (incoming): [[public--m-rank]]

## Sources

- [Algebraic Topology, Allen Hatcher](https://pi.math.cornell.edu/~hatcher/AT/ATpage.html) — author page and chapter organization inspected

Evidence links and mathematical analogies do not grant tool permissions.
